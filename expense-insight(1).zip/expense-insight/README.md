# Expense Insight

An offline-first Progressive Web App that turns bank SMS alerts into a categorized, chartable expense ledger — built for the Indian banking SMS ecosystem (HDFC, SBI, ICICI, Axis, Kotak, Canara, Indian Bank, Federal Bank, IDFC First, Yes Bank, Union Bank, Bank of Baroda, PNB).

Everything runs on-device. There is no backend and no account system: transactions live in IndexedDB in your browser, full stop.

## Quick start

```bash
npm install
npm run dev        # http://localhost:5173
```

```bash
npm test            # vitest — 79 tests across 9 suites
npm run typecheck    # tsc -b --noEmit
npm run build        # production build -> dist/
npm run preview      # serve the production build locally
```

To try it with realistic data immediately: open the app, go to **More → Import & export**, and tap **Load sample data**. That generates ~3 months of varied, seeded (deterministic) transactions across all 13 banks, including a couple of intentional duplicates and a few monthly subscriptions, so the dashboard, charts, budgets, and insights all have something to show.

## The one thing to know before anything else

**A website or PWA cannot read your phone's SMS inbox.** This isn't a limitation of this build — it's a hard sandboxing rule enforced by both Android and iOS for every browser and every PWA, full stop. No amount of engineering inside a web app changes that. (A *native* Android app can request the `READ_SMS` permission; a PWA fundamentally cannot.)

So "importing SMS" here means one of:
- **Paste** — copy messages out of your Messages app and paste them in (one per line, or blank-line separated)
- **Upload an XML file** exported by an Android SMS-backup app (tested against the "SMS Backup & Restore" format)
- **Load sample data** to explore the app without real data

If a truly automatic pipeline is a hard requirement, the realistic path is a small companion Android app (or Tasker/automation shortcut) that forwards new SMS to a file this PWA can pick up, or a native wrapper (Capacitor/Cordova) that requests `READ_SMS` directly — see "Extension points" below.

## What's fully built and working

**Parsing & data pipeline**
- Regex-based extraction engine covering all 13 banks' SMS formats from the spec (amount, type, payment method, merchant, account, reference number, balance, UPI ID, date)
- DLT sender-ID cleanup (`AD-HDFCBK-S` → HDFC Bank) with a body-text fallback when the sender ID is unrecognized
- A generic heuristic fallback for unrecognized formats, with a guard against misreading OTP codes as transaction amounts (see "A bug I caught while testing" below)
- Merchant normalization (`AMAZON PAY` / `Amazon India` / `AMAZON.IN` → `Amazon`) via an alias table
- Keyword-based categorization into 18 categories, with user-defined keyword rules (Settings) checked first
- Two-stage duplicate detection: exact-hash fast path (indexed) for re-sent/re-imported messages, plus a fuzzy same-day/bank/amount scorer (0–100) that routes ambiguous cases to an in-app review queue instead of guessing silently

**Analytics & insights**
- Dashboard: today/week/month spend, average daily spend, largest transaction, most-visited merchant, remaining budget, transaction count
- All 6 chart types: category pie, daily line, monthly bar, top-merchants bar, cashflow area (debit vs credit), and a GitHub-style daily spending heatmap
- Rule-based insight generator: category month-over-month change, frequent merchants, highest-spend weekday, time-of-day pattern, merchant spend trend, month-over-month total, subscription total
- Recurring-payment detection (interval-based for any merchant, plus a known-subscription list that flags on the first occurrence)
- Budgets: per-category or overall monthly limits, with month-end spend prediction based on current pace

**Everything else in the spec**
- PWA: installable, offline-capable (Workbox precaching), app manifest with maskable icons
- PIN lock (SHA-256 hashed, never stored in plaintext)
- Import: SMS (paste/XML), plus re-import of previously exported CSV/JSON
- Export: CSV, JSON, Excel (SheetJS), PDF report (jsPDF)
- Manual transaction entry/edit/delete
- Custom category rules, dark/light/system theme, virtualized transaction list (react-window) for smooth scrolling at scale

**Tests:** 79 tests across 9 suites (Vitest), covering the parser against every bank format in the spec, merchant normalization, category detection (including user-rule precedence), duplicate scoring, analytics math, insight generation (with exact expected percentages/weekdays), recurring detection, and budget status calculations.

## What's intentionally stubbed, with a documented path forward

The spec's section on future features (QR receipt scanning, OCR, voice entry, investment/EMI tracking, family sharing, a net-worth dashboard, an AI financial advisor) was marked by the original request as forward-looking, not part of this build — so none of that is here.

A few things inside the "current" scope are real, working, but deliberately limited rather than faked:

- **AI-assisted parsing fallback.** `src/engine/smsParser.ts` exports an `AiExtractionProvider` interface and a `setAiExtractionProvider()` hook. Right now it's wired to a heuristic (regex-based) fallback, *not* a real LLM call — because this is a static client-side app with no backend, and any API key placed in browser code is visible to anyone who opens dev tools. To add real AI-assisted parsing, stand up a small backend proxy that holds the key server-side, and implement `AiExtractionProvider.extract()` against it.
- **Biometric unlock.** The PIN lock is fully implemented (hashed, real gate on app access). Fingerprint/Face unlock needs the device's native biometric APIs, which a plain web app can't reach — that requires a native wrapper such as Capacitor. `src/components/common/PinLockScreen.tsx` is the natural place to add a WebAuthn/biometric check alongside the PIN.
- **At-rest database encryption.** Transactions are stored in IndexedDB unencrypted (same as most browser-storage apps). If that's a hard requirement, look at Dexie's encryption addon or move to a native wrapper with OS-level keystore access.
- **Native automatic SMS reading.** Covered above — needs a native app, not a PWA.

## A bug I caught while testing

Worth calling out because it's the kind of thing that's easy to miss: my first pass at the "unrecognized format" fallback parser matched *any* number in a message as a possible amount. That's fine for something like "Your account was debited 340 for a purchase" — but it also meant an OTP message like "Your OTP is 445566" would get read as a ₹445,566 transaction. Writing the parser test suite surfaced this before it shipped. The fix (in `smsParser.ts`): the fallback now refuses to run on anything matching an OTP/verification-code pattern, and otherwise requires an explicit debit/credit keyword, a recognized payment method, or account/bank language before it will trust a bare number as an amount.

## Architecture

```
src/
  types/         Shared TS interfaces (Transaction, Budget, Insight, ...)
  db/            Dexie (IndexedDB) schema + sample-data generator
  engine/        Pure parsing/matching logic: bank ID, categorization,
                 merchant normalization, duplicate scoring, SMS parser
  services/      Orchestration: import pipeline, analytics, insights,
                 recurring detection, budgets, export, import
  store/         Zustand stores (UI state, filters, settings)
  hooks/         Dexie live-query hooks for reactive UI data
  theme/         MUI theme (see "Design" below)
  components/    Presentational + interactive UI, grouped by feature
  pages/         Route-level screens
  router/        React Router config (lazy-loaded routes)
  tests/         Vitest suites (mirrors engine/services)
```

Stack: React 18 + TypeScript + Vite, MUI v5, Dexie + dexie-react-hooks, Recharts, Zustand, date-fns, react-window, vite-plugin-pwa.

Two dependencies mentioned in earlier planning were dropped to reduce risk without losing functionality: `@mui/x-date-pickers` (replaced with a native `datetime-local` input) and `uuid` (replaced with `crypto.randomUUID`, which is universally available in the target browsers).

## Design

The visual language is a "ledger / passbook" aesthetic rather than a generic fintech-blue template: ink navy and warm paper backgrounds, a temple-gold accent, muted teal-green for credits and a muted rust for debits (instead of pure green/red), Fraunces serif for headlines and large numbers, glass-panel cards with a thin gold hairline. See `src/theme/theme.ts`.

## Known trade-offs

- `ImportExportPage`'s lazy chunk is large (~720 KB / ~240 KB gzipped) because `xlsx` and `jspdf` are bundled with it. It only loads when someone visits that page — not on first load — but if you want it smaller, dynamically `import()` those two libraries only when the Excel/PDF export buttons are actually clicked, rather than at the top of `exportService.ts`.
- The duplicate-review flow assumes a person is present to resolve ambiguous matches; there's no "always auto-skip" batch setting yet if you'd rather never be asked.

## Deployment

It's a static site — any static host works.

```bash
npm run build
```

- **Vercel:** `vercel.json` (SPA rewrite) is included; deploy the repo as-is.
- **Netlify:** `public/_redirects` is included for the same reason.
- **Anything else:** serve `dist/` and route all paths to `index.html` for the SPA fallback.

## Privacy

No analytics, no telemetry, no server. Every transaction, budget, and setting lives in this browser's IndexedDB. "Clear all data" in Settings deletes it permanently — export a backup first if you want to keep a copy.
