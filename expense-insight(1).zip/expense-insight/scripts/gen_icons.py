from PIL import Image, ImageDraw


def lerp(a, b, t):
    return int(a + (b - a) * t)


def make_background(size, rounded, radius_ratio=0.22):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    px = img.load()
    top = (27, 30, 43)      # #1B1E2B
    bottom = (18, 20, 28)   # #12141C
    for y in range(size):
        t = y / size
        r = lerp(top[0], bottom[0], t)
        g = lerp(top[1], bottom[1], t)
        b = lerp(top[2], bottom[2], t)
        for x in range(size):
            px[x, y] = (r, g, b, 255)

    if rounded:
        mask = Image.new("L", (size, size), 0)
        mdraw = ImageDraw.Draw(mask)
        mdraw.rounded_rectangle([0, 0, size - 1, size - 1], radius=int(size * radius_ratio), fill=255)
        img.putalpha(mask)
    return img


def draw_bars(img, size, safe_scale=1.0):
    draw = ImageDraw.Draw(img)
    gold = (201, 154, 62, 255)
    gold_light = (228, 181, 99, 255)
    bar_w = size * 0.12 * safe_scale
    gap = size * 0.06 * safe_scale
    baseline = size * 0.72
    heights = [0.24, 0.40, 0.58]
    colors = [gold, gold_light, gold]
    total_w = bar_w * 3 + gap * 2
    x = (size - total_w) / 2
    for h, c in zip(heights, colors):
        bh = size * h * safe_scale
        draw.rounded_rectangle(
            [x, baseline - bh, x + bar_w, baseline],
            radius=bar_w * 0.25,
            fill=c,
        )
        x += bar_w + gap
    return img


def build_icon(size, path, rounded=True, safe_scale=1.0):
    img = make_background(size, rounded)
    img = draw_bars(img, size, safe_scale)
    img.save(path)


if __name__ == "__main__":
    out = "/home/claude/expense-insight/public/icons"
    build_icon(192, f"{out}/icon-192.png", rounded=True)
    build_icon(512, f"{out}/icon-512.png", rounded=True)
    build_icon(512, f"{out}/icon-maskable-512.png", rounded=False, safe_scale=0.72)
    print("icons written")
