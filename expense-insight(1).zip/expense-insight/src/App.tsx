import { useEffect, useMemo } from 'react';
import { ThemeProvider, CssBaseline, Box, CircularProgress } from '@mui/material';
import { RouterProvider } from 'react-router-dom';
import { router } from '@/router/router';
import { darkTheme, lightTheme } from '@/theme/theme';
import { useUiStore } from '@/store/uiStore';
import { useSettingsStore } from '@/store/settingsStore';
import PinLockScreen from '@/components/common/PinLockScreen';

export default function App() {
  const themeMode = useUiStore((s) => s.themeMode);
  const unlocked = useUiStore((s) => s.unlocked);
  const hydrated = useSettingsStore((s) => s.hydrated);
  const hydrate = useSettingsStore((s) => s.hydrate);
  const pinEnabled = useSettingsStore((s) => s.pinEnabled);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const prefersDark = typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDark = themeMode === 'dark' || (themeMode === 'system' && prefersDark);
  const theme = useMemo(() => (isDark ? darkTheme : lightTheme), [isDark]);

  if (!hydrated) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box sx={{ height: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {pinEnabled && !unlocked ? <PinLockScreen /> : <RouterProvider router={router} />}
    </ThemeProvider>
  );
}
