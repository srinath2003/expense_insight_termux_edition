import { Box, IconButton, LinearProgress, Stack, Typography } from '@mui/material';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import type { BudgetStatus } from '@/types';
import { formatCurrency } from '@/utils/format';
import { tokens } from '@/theme/theme';
import GlassCard from '@/components/common/GlassCard';

interface Props {
  status: BudgetStatus;
  onDelete: () => void;
}

export default function BudgetCard({ status, onDelete }: Props) {
  const { budget, spent, remaining, predictedMonthEnd, percentUsed, isOverBudget, isPredictedOverBudget } = status;
  const barColor = isOverBudget ? tokens.negative : isPredictedOverBudget ? tokens.goldLight : tokens.positive;

  return (
    <GlassCard>
      <Stack spacing={1}>
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
            {budget.category}
          </Typography>
          <IconButton size="small" onClick={onDelete} aria-label={`Delete ${budget.category} budget`}>
            <DeleteOutlineRoundedIcon fontSize="small" />
          </IconButton>
        </Stack>

        <LinearProgress
          variant="determinate"
          value={Math.min(percentUsed, 100)}
          sx={{
            height: 8,
            borderRadius: 4,
            bgcolor: 'action.hover',
            '& .MuiLinearProgress-bar': { bgcolor: barColor, borderRadius: 4 }
          }}
        />

        <Stack direction="row" justifyContent="space-between">
          <Typography variant="body2" color="text.secondary">
            {formatCurrency(spent)} of {formatCurrency(budget.monthlyLimit)}
          </Typography>
          <Typography variant="body2" sx={{ fontWeight: 600, color: remaining < 0 ? tokens.negative : 'text.primary' }}>
            {remaining >= 0 ? `${formatCurrency(remaining)} left` : `${formatCurrency(-remaining)} over`}
          </Typography>
        </Stack>

        <Box>
          <Typography variant="caption" color="text.secondary">
            Predicted month-end: {formatCurrency(predictedMonthEnd)}
            {isPredictedOverBudget && !isOverBudget ? ' — on track to go over' : ''}
          </Typography>
        </Box>
      </Stack>
    </GlassCard>
  );
}
