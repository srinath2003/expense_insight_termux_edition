import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { formatCurrency } from '@/utils/format';
import { tokens } from '@/theme/theme';

interface Props {
  data: Array<{ date: string; debit: number; credit: number }>;
}

export default function CashflowAreaChart({ data }: Props) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="debitGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={tokens.negative} stopOpacity={0.4} />
            <stop offset="100%" stopColor={tokens.negative} stopOpacity={0} />
          </linearGradient>
          <linearGradient id="creditGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={tokens.positive} stopOpacity={0.4} />
            <stop offset="100%" stopColor={tokens.positive} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" opacity={0.15} vertical={false} />
        <XAxis dataKey="date" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
        <YAxis tick={{ fontSize: 11 }} width={44} tickFormatter={(v) => `₹${v}`} />
        <Tooltip formatter={(value: number) => formatCurrency(value)} />
        <Legend />
        <Area type="monotone" dataKey="credit" name="Credit" stroke={tokens.positive} fill="url(#creditGradient)" />
        <Area type="monotone" dataKey="debit" name="Debit" stroke={tokens.negative} fill="url(#debitGradient)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
