import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Box, Typography } from '@mui/material';
import { formatCurrency } from '@/utils/format';

const PALETTE = ['#C99A3E', '#2F9E6E', '#C2542C', '#5B7FBD', '#9C6ADE', '#D9A441', '#4FA3A0', '#B95C8A', '#7C8A9E'];

interface Props {
  data: Array<{ name: string; value: number }>;
}

export default function CategoryPieChart({ data }: Props) {
  if (data.length === 0) {
    return (
      <Box sx={{ py: 6, textAlign: 'center' }}>
        <Typography color="text.secondary">No spending yet for this period.</Typography>
      </Box>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={60} outerRadius={95} paddingAngle={2}>
          {data.map((entry, index) => (
            <Cell key={entry.name} fill={PALETTE[index % PALETTE.length]} />
          ))}
        </Pie>
        <Tooltip formatter={(value: number) => formatCurrency(value)} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
}
