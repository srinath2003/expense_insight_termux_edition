import { Box, Stack, Tooltip, Typography } from '@mui/material';
import { getDay } from 'date-fns';
import { tokens } from '@/theme/theme';
import { formatCurrency } from '@/utils/format';
import type { HeatmapDay } from '@/services/analyticsService';

interface Props {
  data: HeatmapDay[];
}

function intensity(amount: number, max: number): number {
  if (max <= 0 || amount <= 0) return 0;
  const ratio = amount / max;
  if (ratio > 0.75) return 4;
  if (ratio > 0.5) return 3;
  if (ratio > 0.25) return 2;
  return 1;
}

const SHADES = ['transparent', `${tokens.gold}33`, `${tokens.gold}66`, `${tokens.gold}99`, tokens.gold];

export default function SpendingHeatmap({ data }: Props) {
  if (data.length === 0) {
    return (
      <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
        No spending recorded yet.
      </Typography>
    );
  }

  const max = Math.max(...data.map((d) => d.amount));
  // Pad the front so the first column starts on Sunday, like a GitHub-style grid.
  const firstDow = getDay(new Date(data[0].date));
  const padded: Array<HeatmapDay | null> = [...Array(firstDow).fill(null), ...data];
  const weeks: Array<Array<HeatmapDay | null>> = [];
  for (let i = 0; i < padded.length; i += 7) {
    weeks.push(padded.slice(i, i + 7));
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', gap: 0.6, overflowX: 'auto', pb: 1 }}>
        {weeks.map((week, wi) => (
          <Stack key={wi} spacing={0.6}>
            {week.map((day, di) =>
              day ? (
                <Tooltip key={di} title={`${day.date}: ${formatCurrency(day.amount)}`} arrow>
                  <Box
                    sx={{
                      width: 13,
                      height: 13,
                      borderRadius: '3px',
                      bgcolor: SHADES[intensity(day.amount, max)],
                      border: '1px solid',
                      borderColor: 'divider'
                    }}
                  />
                </Tooltip>
              ) : (
                <Box key={di} sx={{ width: 13, height: 13 }} />
              )
            )}
          </Stack>
        ))}
      </Box>
      <Stack direction="row" spacing={0.5} alignItems="center" justifyContent="flex-end">
        <Typography variant="caption" color="text.secondary">
          Less
        </Typography>
        {SHADES.map((shade, i) => (
          <Box
            key={i}
            sx={{ width: 11, height: 11, borderRadius: '2px', bgcolor: shade, border: '1px solid', borderColor: 'divider' }}
          />
        ))}
        <Typography variant="caption" color="text.secondary">
          More
        </Typography>
      </Stack>
    </Box>
  );
}
