import { Paper, useTheme, type PaperProps } from '@mui/material';
import { glassSurfaceSx } from '@/theme/theme';

/** The app's signature card surface: soft glass with a thin gold top hairline. */
export default function GlassCard({ sx, children, ...rest }: PaperProps) {
  const theme = useTheme();
  return (
    <Paper
      elevation={0}
      sx={{
        borderRadius: 4,
        p: 2.5,
        ...glassSurfaceSx(theme.palette.mode === 'dark'),
        ...sx
      }}
      {...rest}
    >
      {children}
    </Paper>
  );
}
