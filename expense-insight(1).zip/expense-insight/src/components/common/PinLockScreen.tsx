import { useState } from 'react';
import { Box, Button, Stack, TextField, Typography, Alert } from '@mui/material';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import { useSettingsStore, hashPin } from '@/store/settingsStore';
import { useUiStore } from '@/store/uiStore';
import { tokens } from '@/theme/theme';

export default function PinLockScreen() {
  const pinHash = useSettingsStore((s) => s.pinHash);
  const setUnlocked = useUiStore((s) => s.setUnlocked);
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  async function handleUnlock() {
    const attemptHash = await hashPin(pin);
    if (attemptHash === pinHash) {
      setUnlocked(true);
    } else {
      setError(true);
      setPin('');
    }
  }

  return (
    <Box
      sx={{
        position: 'fixed',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'background.default',
        p: 3,
        zIndex: 2000
      }}
    >
      <Stack spacing={3} alignItems="center" sx={{ width: '100%', maxWidth: 320 }}>
        <Box
          sx={{
            width: 56,
            height: 56,
            borderRadius: '16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            bgcolor: `${tokens.gold}22`,
            color: tokens.gold
          }}
        >
          <LockRoundedIcon />
        </Box>
        <Typography variant="h5" sx={{ fontWeight: 700 }}>
          Enter your PIN
        </Typography>
        <Typography variant="body2" color="text.secondary" textAlign="center">
          Your data stays on this device. Unlock to view your expenses.
        </Typography>
        <TextField
          type="password"
          inputMode="numeric"
          value={pin}
          onChange={(e) => {
            setError(false);
            setPin(e.target.value.replace(/\D/g, '').slice(0, 8));
          }}
          onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
          placeholder="••••"
          fullWidth
          autoFocus
          inputProps={{ style: { textAlign: 'center', letterSpacing: '0.5em', fontSize: '1.5rem' } }}
        />
        {error && (
          <Alert severity="error" sx={{ width: '100%' }}>
            That PIN didn't match. Try again.
          </Alert>
        )}
        <Button variant="contained" fullWidth size="large" onClick={handleUnlock} disabled={pin.length < 4}>
          Unlock
        </Button>
      </Stack>
    </Box>
  );
}
