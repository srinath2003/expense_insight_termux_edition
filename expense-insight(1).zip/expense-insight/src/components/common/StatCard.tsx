import { Box, Stack, Typography } from '@mui/material';
import type { SvgIconComponent } from '@mui/icons-material';
import GlassCard from './GlassCard';
import { tokens } from '@/theme/theme';

interface StatCardProps {
  label: string;
  value: string;
  icon: SvgIconComponent;
  caption?: string;
  tone?: 'neutral' | 'positive' | 'negative';
}

export default function StatCard({ label, value, icon: Icon, caption, tone = 'neutral' }: StatCardProps) {
  const color = tone === 'positive' ? tokens.positive : tone === 'negative' ? tokens.negative : tokens.gold;

  return (
    <GlassCard sx={{ height: '100%' }}>
      <Stack spacing={1}>
        <Stack direction="row" alignItems="center" justifyContent="space-between">
          <Typography variant="body2" color="text.secondary">
            {label}
          </Typography>
          <Box
            sx={{
              width: 32,
              height: 32,
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              bgcolor: `${color}22`,
              color
            }}
          >
            <Icon fontSize="small" />
          </Box>
        </Stack>
        <Typography variant="h5" className="tabular-nums" sx={{ fontWeight: 700 }}>
          {value}
        </Typography>
        {caption && (
          <Typography variant="caption" color="text.secondary">
            {caption}
          </Typography>
        )}
      </Stack>
    </GlassCard>
  );
}
