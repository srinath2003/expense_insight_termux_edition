import { Box, Stack, Typography } from '@mui/material';
import TrendingUpRoundedIcon from '@mui/icons-material/TrendingUpRounded';
import TrendingDownRoundedIcon from '@mui/icons-material/TrendingDownRounded';
import LightbulbRoundedIcon from '@mui/icons-material/LightbulbRounded';
import type { Insight } from '@/types';
import { tokens } from '@/theme/theme';
import GlassCard from '@/components/common/GlassCard';

const ICONS = {
  positive: TrendingDownRoundedIcon,
  warning: TrendingUpRoundedIcon,
  info: LightbulbRoundedIcon
};

export default function InsightCard({ insight }: { insight: Insight }) {
  const Icon = ICONS[insight.severity];
  const color = insight.severity === 'positive' ? tokens.positive : insight.severity === 'warning' ? tokens.negative : tokens.gold;

  return (
    <GlassCard sx={{ p: 2 }}>
      <Stack direction="row" spacing={1.5} alignItems="flex-start">
        <Box
          sx={{
            width: 32,
            height: 32,
            flexShrink: 0,
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            bgcolor: `${color}22`,
            color
          }}
        >
          <Icon fontSize="small" />
        </Box>
        <Box>
          <Typography variant="body2" sx={{ fontWeight: 700 }}>
            {insight.title}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {insight.description}
          </Typography>
        </Box>
      </Stack>
    </GlassCard>
  );
}
