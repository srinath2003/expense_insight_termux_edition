import { Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import { AppBar, Toolbar, Typography, IconButton, Box, Fab, CircularProgress } from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import DarkModeRoundedIcon from '@mui/icons-material/DarkModeRounded';
import LightModeRoundedIcon from '@mui/icons-material/LightModeRounded';
import BottomNav from './BottomNav';
import { useUiStore } from '@/store/uiStore';
import TransactionForm from '@/components/transactions/TransactionForm';

export default function AppShell() {
  const themeMode = useUiStore((s) => s.themeMode);
  const setThemeMode = useUiStore((s) => s.setThemeMode);
  const addTransactionOpen = useUiStore((s) => s.addTransactionOpen);
  const setAddTransactionOpen = useUiStore((s) => s.setAddTransactionOpen);

  const effectiveDark =
    themeMode === 'dark' ||
    (themeMode === 'system' && typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches);

  return (
    <Box sx={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column' }}>
      <AppBar position="sticky" color="transparent">
        <Toolbar sx={{ pt: 'env(safe-area-inset-top)' }}>
          <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 700 }}>
            Expense Insight
          </Typography>
          <IconButton onClick={() => setThemeMode(effectiveDark ? 'light' : 'dark')} aria-label="Toggle theme">
            {effectiveDark ? <LightModeRoundedIcon /> : <DarkModeRoundedIcon />}
          </IconButton>
        </Toolbar>
      </AppBar>

      <Box component="main" sx={{ flex: 1, px: 2, pt: 2, pb: 12, maxWidth: 720, mx: 'auto', width: '100%' }}>
        <Suspense
          fallback={
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
              <CircularProgress />
            </Box>
          }
        >
          <Outlet />
        </Suspense>
      </Box>

      <Fab
        color="primary"
        aria-label="Add transaction"
        onClick={() => setAddTransactionOpen(true)}
        sx={{ position: 'fixed', bottom: 76, right: 20, zIndex: 1200 }}
      >
        <AddRoundedIcon />
      </Fab>

      <TransactionForm open={addTransactionOpen} onClose={() => setAddTransactionOpen(false)} />

      <BottomNav />
    </Box>
  );
}
