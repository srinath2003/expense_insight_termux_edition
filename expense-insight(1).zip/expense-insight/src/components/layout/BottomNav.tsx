import { useLocation, useNavigate } from 'react-router-dom';
import { Paper, BottomNavigation, BottomNavigationAction } from '@mui/material';
import SpaceDashboardRoundedIcon from '@mui/icons-material/SpaceDashboardRounded';
import ReceiptLongRoundedIcon from '@mui/icons-material/ReceiptLongRounded';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import SavingsRoundedIcon from '@mui/icons-material/SavingsRounded';
import MoreHorizRoundedIcon from '@mui/icons-material/MoreHorizRounded';

const TABS = [
  { path: '/', label: 'Dashboard', icon: SpaceDashboardRoundedIcon },
  { path: '/transactions', label: 'Transactions', icon: ReceiptLongRoundedIcon },
  { path: '/analytics', label: 'Analytics', icon: InsightsRoundedIcon },
  { path: '/budgets', label: 'Budgets', icon: SavingsRoundedIcon },
  { path: '/more', label: 'More', icon: MoreHorizRoundedIcon }
];

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const current = TABS.find((t) => t.path === location.pathname)?.path ?? false;

  return (
    <Paper
      elevation={0}
      sx={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 1100,
        borderTop: '1px solid',
        borderColor: 'divider'
      }}
    >
      <BottomNavigation
        value={current}
        onChange={(_, value) => navigate(value)}
        sx={{ bgcolor: 'transparent', pb: 'env(safe-area-inset-bottom)' }}
      >
        {TABS.map((tab) => (
          <BottomNavigationAction key={tab.path} label={tab.label} value={tab.path} icon={<tab.icon />} />
        ))}
      </BottomNavigation>
    </Paper>
  );
}
