import { useState } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, Stack, Typography, Chip, Box, LinearProgress } from '@mui/material';
import type { ReviewItem } from '@/services/smsImportService';
import { resolveReviewItem } from '@/services/smsImportService';
import { formatCurrency, formatDateTime } from '@/utils/format';

interface Props {
  items: ReviewItem[];
  onDone: () => void;
}

export default function DuplicateReviewDialog({ items, onDone }: Props) {
  const [index, setIndex] = useState(0);
  const [busy, setBusy] = useState(false);

  if (items.length === 0) return null;
  const item = items[index];
  const isLast = index === items.length - 1;

  async function decide(keep: boolean) {
    setBusy(true);
    try {
      await resolveReviewItem(item, keep);
      if (isLast) onDone();
      else setIndex((i) => i + 1);
    } finally {
      setBusy(false);
    }
  }

  async function decideAll(keep: boolean) {
    setBusy(true);
    try {
      for (let i = index; i < items.length; i++) {
        await resolveReviewItem(items[i], keep);
      }
      onDone();
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open fullWidth maxWidth="xs">
      <DialogTitle>
        Possible duplicate ({index + 1} of {items.length})
      </DialogTitle>
      {busy && <LinearProgress />}
      <DialogContent>
        <Stack spacing={2}>
          <Typography variant="body2" color="text.secondary">
            This new message looks {item.score}% similar to a transaction already on record. Is it a new
            transaction, or the bank re-sending the same alert?
          </Typography>

          <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: 'action.hover' }}>
            <Typography variant="caption" color="text.secondary">
              New message
            </Typography>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              {item.candidate.normalizedMerchant} — {formatCurrency(item.candidate.amount)}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {formatDateTime(item.candidate.date)} · {item.candidate.bank}
            </Typography>
          </Box>

          {item.matchedTransaction && (
            <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: 'action.hover' }}>
              <Typography variant="caption" color="text.secondary">
                Already on record
              </Typography>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {item.matchedTransaction.normalizedMerchant} — {formatCurrency(item.matchedTransaction.amount)}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {formatDateTime(item.matchedTransaction.date)} · {item.matchedTransaction.bank}
              </Typography>
            </Box>
          )}

          <Chip label={`${item.score}% similarity`} size="small" sx={{ alignSelf: 'flex-start' }} />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2, flexWrap: 'wrap' }}>
        <Button onClick={() => decideAll(false)} disabled={busy} sx={{ mr: 'auto' }} size="small">
          Skip all remaining
        </Button>
        <Button onClick={() => decide(false)} disabled={busy}>
          Skip (duplicate)
        </Button>
        <Button variant="contained" onClick={() => decide(true)} disabled={busy}>
          Keep (new)
        </Button>
      </DialogActions>
    </Dialog>
  );
}
