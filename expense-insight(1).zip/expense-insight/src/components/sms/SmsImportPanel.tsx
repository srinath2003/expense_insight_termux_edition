import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Chip,
  Divider,
  FormControlLabel,
  Stack,
  Switch,
  TextField,
  Typography,
  LinearProgress
} from '@mui/material';
import UploadFileRoundedIcon from '@mui/icons-material/UploadFileRounded';
import DataObjectRoundedIcon from '@mui/icons-material/DataObjectRounded';
import SyncRoundedIcon from '@mui/icons-material/SyncRounded';
import PhoneAndroidRoundedIcon from '@mui/icons-material/PhoneAndroidRounded';
import { importSmsBatch, type ImportSummary } from '@/services/smsImportService';
import { parsePastedSms, parseSmsBackupXml } from '@/services/importService';
import { generateSampleSms } from '@/db/seedData';
import { acknowledgeBridgeMessages, fetchBridgeMessages, getBridgePort, setBridgePort } from '@/services/bridgeSyncService';
import DuplicateReviewDialog from './DuplicateReviewDialog';
import GlassCard from '@/components/common/GlassCard';

const AUTO_SYNC_INTERVAL_MS = 15000;

export default function SmsImportPanel() {
  const [pastedText, setPastedText] = useState('');
  const [busy, setBusy] = useState(false);
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [portInput, setPortInput] = useState(String(getBridgePort()));
  const [bridgeStatus, setBridgeStatus] = useState<{ kind: 'idle' | 'ok' | 'error'; message?: string }>({ kind: 'idle' });
  const [autoSync, setAutoSync] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<Date | null>(null);

  async function runImport(messages: Awaited<ReturnType<typeof parsePastedSms>>) {
    setBusy(true);
    setSummary(null);
    try {
      const result = await importSmsBatch(messages);
      setSummary(result);
      return result;
    } finally {
      setBusy(false);
    }
  }

  async function handlePasteImport() {
    if (!pastedText.trim()) return;
    await runImport(parsePastedSms(pastedText));
    setPastedText('');
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const messages = await parseSmsBackupXml(file);
    await runImport(messages);
  }

  async function handleLoadSampleData() {
    await runImport(generateSampleSms(3));
  }

  async function handleSyncNow(silent = false) {
    const port = parseInt(portInput, 10) || getBridgePort();
    setBridgePort(port);
    if (!silent) setBridgeStatus({ kind: 'idle' });

    const fetched = await fetchBridgeMessages(port);
    if (!fetched.ok) {
      setBridgeStatus({ kind: 'error', message: fetched.error });
      return;
    }

    if (fetched.messages.length === 0) {
      setBridgeStatus({ kind: 'ok', message: 'Up to date — no new messages on the phone.' });
      setLastSyncedAt(new Date());
      return;
    }

    const result = await runImport(fetched.messages);
    await acknowledgeBridgeMessages(port);
    setLastSyncedAt(new Date());
    setBridgeStatus({
      kind: 'ok',
      message: `Synced ${result.inserted} new transaction${result.inserted === 1 ? '' : 's'} from your phone.`
    });
  }

  useEffect(() => {
    if (!autoSync) return;
    const id = window.setInterval(() => {
      handleSyncNow(true);
    }, AUTO_SYNC_INTERVAL_MS);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoSync, portInput]);

  const reviewQueue = summary?.needsReview ?? [];

  return (
    <Stack spacing={2}>
      <GlassCard>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
          <PhoneAndroidRoundedIcon fontSize="small" color="primary" />
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
            Sync from this phone (offline)
          </Typography>
          <Chip label="No internet used" size="small" variant="outlined" sx={{ ml: 'auto' }} />
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
          If you've set up the Termux bridge (see <code>termux/SETUP.md</code> in the project), this pulls new SMS
          straight from your phone's inbox over <code>127.0.0.1</code> — nothing leaves the device. Requires the
          bridge server to be running in Termux.
        </Typography>

        <Stack direction="row" spacing={1} sx={{ mb: 1.5 }}>
          <TextField
            label="Bridge port"
            size="small"
            value={portInput}
            onChange={(e) => setPortInput(e.target.value.replace(/\D/g, ''))}
            sx={{ width: 140 }}
          />
          <Button
            startIcon={<SyncRoundedIcon />}
            variant="contained"
            onClick={() => handleSyncNow(false)}
            disabled={busy || !portInput}
          >
            Sync now
          </Button>
        </Stack>

        <FormControlLabel
          control={<Switch checked={autoSync} onChange={(e) => setAutoSync(e.target.checked)} />}
          label="Auto-sync every 15s while this page is open"
        />

        {bridgeStatus.kind !== 'idle' && (
          <Alert severity={bridgeStatus.kind === 'ok' ? 'success' : 'warning'} sx={{ mt: 1.5 }}>
            {bridgeStatus.message}
          </Alert>
        )}
        {lastSyncedAt && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
            Last synced {lastSyncedAt.toLocaleTimeString()}
          </Typography>
        )}
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Paste SMS messages
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
          Copy one or more bank SMS from your Messages app and paste them below — one per line, or with a blank
          line between messages.
        </Typography>
        <TextField
          multiline
          minRows={4}
          fullWidth
          placeholder="HDFC: Rs.250 spent on your HDFC Bank Credit Card at AMAZON on 25-06-2026."
          value={pastedText}
          onChange={(e) => setPastedText(e.target.value)}
        />
        <Button sx={{ mt: 1.5 }} variant="contained" onClick={handlePasteImport} disabled={busy || !pastedText.trim()}>
          Parse & import
        </Button>
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Import a file
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
          Upload an XML export from an SMS backup app (e.g. "SMS Backup & Restore" on Android).
        </Typography>
        <input ref={fileInputRef} type="file" accept=".xml" hidden onChange={handleFileUpload} />
        <Button startIcon={<UploadFileRoundedIcon />} variant="outlined" onClick={() => fileInputRef.current?.click()} disabled={busy}>
          Upload SMS backup XML
        </Button>
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Just exploring?
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
          Load a few months of realistic sample transactions across all 13 supported banks, so you can see the
          dashboard, charts, budgets, and insights in action.
        </Typography>
        <Button startIcon={<DataObjectRoundedIcon />} variant="outlined" onClick={handleLoadSampleData} disabled={busy}>
          Load sample data
        </Button>
      </GlassCard>

      {busy && <LinearProgress />}

      {summary && (
        <Alert severity={summary.failed > 0 ? 'warning' : 'success'}>
          <Stack spacing={0.25}>
            <Typography variant="body2">
              Imported {summary.inserted} of {summary.total} messages.
            </Typography>
            {summary.autoSkippedDuplicates > 0 && (
              <Typography variant="body2">Skipped {summary.autoSkippedDuplicates} exact duplicates.</Typography>
            )}
            {summary.failed > 0 && (
              <Typography variant="body2">Couldn't parse {summary.failed} message(s) — see Settings → SMS log.</Typography>
            )}
          </Stack>
        </Alert>
      )}

      {reviewQueue.length > 0 && (
        <DuplicateReviewDialog items={reviewQueue} onDone={() => setSummary((s) => (s ? { ...s, needsReview: [] } : s))} />
      )}

      <Divider />
      <Box>
        <Typography variant="caption" color="text.secondary">
          Note: a browser can't read your phone's SMS inbox on its own (true for every website and PWA, on Android
          and iOS). The "Sync from this phone" option above works around that using a small local script — everything
          else here (paste, file upload) works without any extra setup.
        </Typography>
      </Box>
    </Stack>
  );
}
