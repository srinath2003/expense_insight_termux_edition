import { Box, Checkbox, Chip, ListItemText, MenuItem, Select, Stack, type SelectChangeEvent } from '@mui/material';
import { CATEGORIES, type PaymentMethod } from '@/types';
import { useFilterStore, type DatePreset } from '@/store/filterStore';
import { useAllBanks } from '@/hooks/useDexieData';

const DATE_PRESETS: Array<{ value: DatePreset; label: string }> = [
  { value: 'today', label: 'Today' },
  { value: 'yesterday', label: 'Yesterday' },
  { value: 'thisWeek', label: 'This Week' },
  { value: 'thisMonth', label: 'This Month' },
  { value: 'lastMonth', label: 'Last Month' },
  { value: 'all', label: 'All Time' }
];

const PAYMENT_METHODS: PaymentMethod[] = [
  'UPI',
  'Debit Card',
  'Credit Card',
  'Net Banking',
  'ATM',
  'Cash',
  'IMPS',
  'NEFT',
  'RTGS',
  'Other'
];

export default function TransactionFilters() {
  const {
    datePreset,
    setDatePreset,
    categories,
    banks,
    paymentMethods,
    toggleCategory,
    toggleBank,
    togglePaymentMethod
  } = useFilterStore();
  const allBanks = useAllBanks() ?? [];

  function handleMultiChange<T extends string>(event: SelectChangeEvent<T[]>, toggle: (value: T) => void, current: T[]) {
    const next = event.target.value as unknown as T[];
    const added = next.find((v) => !current.includes(v));
    const removed = current.find((v) => !next.includes(v));
    if (added) toggle(added);
    if (removed) toggle(removed);
  }

  return (
    <Stack spacing={1.5}>
      <Box sx={{ display: 'flex', gap: 1, overflowX: 'auto', pb: 0.5 }}>
        {DATE_PRESETS.map((preset) => (
          <Chip
            key={preset.value}
            label={preset.label}
            onClick={() => setDatePreset(preset.value)}
            color={datePreset === preset.value ? 'primary' : 'default'}
            variant={datePreset === preset.value ? 'filled' : 'outlined'}
            size="small"
          />
        ))}
      </Box>

      <Stack direction="row" spacing={1} sx={{ overflowX: 'auto', pb: 0.5 }}>
        <Select
          multiple
          displayEmpty
          size="small"
          value={categories}
          onChange={(e) => handleMultiChange(e, toggleCategory, categories)}
          renderValue={(selected) => (selected.length ? `Category (${selected.length})` : 'Category')}
          sx={{ minWidth: 140 }}
        >
          {CATEGORIES.map((c) => (
            <MenuItem key={c} value={c}>
              <Checkbox checked={categories.includes(c)} size="small" />
              <ListItemText primary={c} />
            </MenuItem>
          ))}
        </Select>

        <Select
          multiple
          displayEmpty
          size="small"
          value={banks}
          onChange={(e) => handleMultiChange(e, toggleBank, banks)}
          renderValue={(selected) => (selected.length ? `Bank (${selected.length})` : 'Bank')}
          sx={{ minWidth: 120 }}
        >
          {allBanks.map((b) => (
            <MenuItem key={b} value={b}>
              <Checkbox checked={banks.includes(b)} size="small" />
              <ListItemText primary={b} />
            </MenuItem>
          ))}
        </Select>

        <Select
          multiple
          displayEmpty
          size="small"
          value={paymentMethods}
          onChange={(e) => handleMultiChange(e, togglePaymentMethod, paymentMethods)}
          renderValue={(selected) => (selected.length ? `Payment (${selected.length})` : 'Payment')}
          sx={{ minWidth: 130 }}
        >
          {PAYMENT_METHODS.map((m) => (
            <MenuItem key={m} value={m}>
              <Checkbox checked={paymentMethods.includes(m)} size="small" />
              <ListItemText primary={m} />
            </MenuItem>
          ))}
        </Select>
      </Stack>
    </Stack>
  );
}
