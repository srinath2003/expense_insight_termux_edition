import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Stack,
  TextField,
  MenuItem,
  ToggleButton,
  ToggleButtonGroup
} from '@mui/material';
import { db } from '@/db/db';
import { CATEGORIES, type Category, type PaymentMethod, type Transaction, type TransactionType } from '@/types';
import { normalizeMerchant } from '@/engine/merchantNormalizer';
import { computeTransactionHash } from '@/engine/duplicateDetector';
import { insertTransaction } from '@/services/smsImportService';

const PAYMENT_METHODS: PaymentMethod[] = [
  'UPI',
  'Cash',
  'Debit Card',
  'Credit Card',
  'Net Banking',
  'ATM',
  'IMPS',
  'NEFT',
  'RTGS',
  'Other'
];

const BANKS = [
  'HDFC Bank',
  'State Bank of India',
  'ICICI Bank',
  'Axis Bank',
  'Kotak Mahindra Bank',
  'Canara Bank',
  'Indian Bank',
  'Federal Bank',
  'IDFC First Bank',
  'Yes Bank',
  'Union Bank of India',
  'Bank of Baroda',
  'Punjab National Bank',
  'Cash / Other'
];

function toLocalInputValue(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

interface Props {
  open: boolean;
  onClose: () => void;
  existing?: Transaction;
}

export default function TransactionForm({ open, onClose, existing }: Props) {
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<TransactionType>('debit');
  const [merchant, setMerchant] = useState('');
  const [category, setCategory] = useState<Category>('Others');
  const [bank, setBank] = useState('Cash / Other');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [dateTime, setDateTime] = useState(toLocalInputValue(new Date().toISOString()));
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (existing) {
      setAmount(String(existing.amount));
      setType(existing.type);
      setMerchant(existing.merchant);
      setCategory(existing.category);
      setBank(existing.bank);
      setPaymentMethod(existing.paymentMethod);
      setDateTime(toLocalInputValue(existing.date));
      setNotes(existing.narration);
    } else if (open) {
      setAmount('');
      setType('debit');
      setMerchant('');
      setCategory('Others');
      setBank('Cash / Other');
      setPaymentMethod('Cash');
      setDateTime(toLocalInputValue(new Date().toISOString()));
      setNotes('');
    }
  }, [existing, open]);

  const isValid = parseFloat(amount) > 0 && merchant.trim().length > 0;

  async function handleSave() {
    if (!isValid) return;
    setSaving(true);
    try {
      const isoDate = new Date(dateTime).toISOString();
      const normalizedMerchant = normalizeMerchant(merchant);
      const narration = notes.trim() || `${type === 'debit' ? 'Paid to' : 'Received from'} ${merchant}`;

      if (existing?.id) {
        await db.transactions.update(existing.id, {
          amount: parseFloat(amount),
          type,
          merchant,
          normalizedMerchant,
          category,
          categoryManuallySet: true,
          bank,
          paymentMethod,
          date: isoDate,
          narration
        });
      } else {
        const core = {
          amount: parseFloat(amount),
          currency: 'INR',
          bank,
          type,
          merchant,
          normalizedMerchant,
          paymentMethod,
          date: isoDate,
          narration,
          category,
          categoryManuallySet: true,
          confidence: 100,
          isManual: true
        };
        const hash = await computeTransactionHash(core);
        await insertTransaction({ ...core, hash });
      }
      onClose();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (existing?.id) {
      await db.transactions.delete(existing.id);
      onClose();
    }
  }

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle>{existing ? 'Edit transaction' : 'Add transaction'}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 0.5 }}>
          <ToggleButtonGroup exclusive fullWidth value={type} onChange={(_, v) => v && setType(v)} size="small">
            <ToggleButton value="debit">Spent (debit)</ToggleButton>
            <ToggleButton value="credit">Received (credit)</ToggleButton>
          </ToggleButtonGroup>

          <TextField
            label="Amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            fullWidth
            autoFocus
            inputProps={{ min: 0, step: '0.01' }}
          />
          <TextField label="Merchant / payee" value={merchant} onChange={(e) => setMerchant(e.target.value)} fullWidth />
          <TextField select label="Category" value={category} onChange={(e) => setCategory(e.target.value as Category)} fullWidth>
            {CATEGORIES.map((c) => (
              <MenuItem key={c} value={c}>
                {c}
              </MenuItem>
            ))}
          </TextField>
          <TextField select label="Bank / account" value={bank} onChange={(e) => setBank(e.target.value)} fullWidth>
            {BANKS.map((b) => (
              <MenuItem key={b} value={b}>
                {b}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            select
            label="Payment method"
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
            fullWidth
          >
            {PAYMENT_METHODS.map((m) => (
              <MenuItem key={m} value={m}>
                {m}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            label="Date & time"
            type="datetime-local"
            value={dateTime}
            onChange={(e) => setDateTime(e.target.value)}
            fullWidth
            InputLabelProps={{ shrink: true }}
          />
          <TextField label="Note (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} fullWidth multiline minRows={2} />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        {existing && (
          <Button color="error" onClick={handleDelete} sx={{ mr: 'auto' }}>
            Delete
          </Button>
        )}
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={!isValid || saving}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
}
