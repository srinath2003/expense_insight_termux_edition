import { useEffect, useRef, useState } from 'react';
import { FixedSizeList, type ListChildComponentProps } from 'react-window';
import { Box, Typography } from '@mui/material';
import type { Transaction } from '@/types';
import TransactionRow from './TransactionRow';

const ROW_HEIGHT = 84;

interface Props {
  transactions: Transaction[];
  onSelect: (transaction: Transaction) => void;
  /** Fallback height (px) used before the container has been measured. */
  minHeight?: number;
}

function useMeasuredHeight<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [height, setHeight] = useState(0);

  useEffect(() => {
    if (!ref.current) return;
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) setHeight(entry.contentRect.height);
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return { ref, height };
}

export default function TransactionList({ transactions, onSelect, minHeight = 420 }: Props) {
  const { ref, height } = useMeasuredHeight<HTMLDivElement>();

  if (transactions.length === 0) {
    return (
      <Box sx={{ py: 6, textAlign: 'center' }}>
        <Typography color="text.secondary">No transactions match these filters.</Typography>
      </Box>
    );
  }

  function Row({ index, style }: ListChildComponentProps) {
    const t = transactions[index];
    return <TransactionRow transaction={t} style={style} onClick={() => onSelect(t)} />;
  }

  return (
    <Box ref={ref} sx={{ height: `max(${minHeight}px, calc(100dvh - 320px))`, minHeight }}>
      {height > 0 && (
        <FixedSizeList height={height} width="100%" itemCount={transactions.length} itemSize={ROW_HEIGHT}>
          {Row}
        </FixedSizeList>
      )}
    </Box>
  );
}
