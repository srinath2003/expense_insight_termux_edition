import { Avatar, Box, Chip, Stack, Typography } from '@mui/material';
import type { Transaction } from '@/types';
import { formatCurrency, formatDateTime } from '@/utils/format';
import { tokens } from '@/theme/theme';

interface Props {
  transaction: Transaction;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export default function TransactionRow({ transaction: t, onClick, style }: Props) {
  const isCredit = t.type === 'credit';
  return (
    <Box
      style={style}
      onClick={onClick}
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1.5,
        px: 1,
        py: 1,
        cursor: onClick ? 'pointer' : 'default',
        borderBottom: '1px solid',
        borderColor: 'divider',
        '&:hover': onClick ? { bgcolor: 'action.hover' } : undefined
      }}
    >
      <Avatar sx={{ bgcolor: `${tokens.gold}22`, color: tokens.gold, width: 40, height: 40, fontSize: 14 }}>
        {t.normalizedMerchant.slice(0, 2).toUpperCase()}
      </Avatar>
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography variant="body2" sx={{ fontWeight: 600 }} noWrap>
          {t.normalizedMerchant}
        </Typography>
        <Stack direction="row" spacing={0.5} alignItems="center">
          <Typography variant="caption" color="text.secondary" noWrap>
            {formatDateTime(t.date)} · {t.bank}
          </Typography>
        </Stack>
        <Chip label={t.category} size="small" sx={{ mt: 0.5, height: 20, fontSize: 11 }} />
      </Box>
      <Typography
        variant="body1"
        className="tabular-nums"
        sx={{ fontWeight: 700, color: isCredit ? tokens.positive : tokens.negative, whiteSpace: 'nowrap' }}
      >
        {isCredit ? '+' : '−'}
        {formatCurrency(t.amount, t.currency)}
      </Typography>
    </Box>
  );
}
