import Dexie, { type Table } from 'dexie';
import type {
  Transaction,
  Merchant,
  Budget,
  CategoryRule,
  SettingsRecord,
  SmsLog,
  DuplicateHashEntry
} from '@/types';

/**
 * All application data lives in a single IndexedDB database via Dexie.
 * There is no server and no sync — everything the app knows lives here,
 * on this device (see README "Security & privacy").
 */
export class ExpenseInsightDB extends Dexie {
  transactions!: Table<Transaction, number>;
  merchants!: Table<Merchant, number>;
  budgets!: Table<Budget, number>;
  categoryRules!: Table<CategoryRule, number>;
  settings!: Table<SettingsRecord, number>;
  smsLogs!: Table<SmsLog, number>;
  duplicateHashes!: Table<DuplicateHashEntry, number>;

  constructor() {
    super('ExpenseInsightDB');
    this.version(1).stores({
      // '&hash' = unique index: a hard safety net so an exact-duplicate hash
      // can never be inserted twice, even if a bug slipped past checkDuplicate().
      transactions:
        '++id, date, category, bank, normalizedMerchant, type, paymentMethod, &hash, isRecurring, recurringGroupId',
      merchants: '++id, &normalizedName, category',
      budgets: '++id, month, category, [category+month]',
      categoryRules: '++id, &keyword',
      settings: '++id, &key',
      smsLogs: '++id, date, processed',
      duplicateHashes: '++id, &hash'
    });
  }
}

export const db = new ExpenseInsightDB();
