import type { RawSms } from '@/types';

/**
 * A small, precise set of realistic messages — one clearly-formatted example
 * per bank so the parser/tests have a known-good fixture for every bank in
 * the spec. Dates are recent-relative so they show up in "this month" views
 * when loaded.
 */
export function staticSampleSms(referenceDate: Date = new Date()): RawSms[] {
  const iso = (daysAgo: number, hour = 12) => {
    const d = new Date(referenceDate);
    d.setDate(d.getDate() - daysAgo);
    d.setHours(hour, 30, 0, 0);
    return d.toISOString();
  };

  return [
    { sender: 'HDFCBK', body: 'Rs.250 spent on your HDFC Bank Credit Card at AMAZON on 25-06-2026.', date: iso(2, 14) },
    { sender: 'SBIINB', body: 'INR 580 debited A/C XX1234 via UPI to Swiggy. Ref No 302981123.', date: iso(1, 20) },
    { sender: 'ICICIB', body: 'Rs.1299 spent using Debit Card at Reliance Fresh. Avl Bal Rs.45210.', date: iso(3, 11) },
    { sender: 'AXISBK', body: 'UPI Txn of Rs 230 to Uber successful. Ref 552011987.', date: iso(0, 21) },
    { sender: 'KOTAKB', body: 'INR 899 paid to Flipkart.', date: iso(4, 16) },
    { sender: 'CANBNK', body: 'Rs.120 withdrawn using ATM. Avl Bal Rs.12500.', date: iso(5, 10) },
    {
      sender: 'INDBNK',
      body: 'Rs.450 spent using Debit Card at Zomato Online on 28-06-2026. Avl Bal Rs.8900.',
      date: iso(6, 19)
    },
    {
      sender: 'FEDBNK',
      body: 'INR 1650 debited A/C XX8842 via UPI to Big Bazaar. UPI Ref No 447712233.',
      date: iso(7, 13)
    },
    {
      sender: 'IDFCFB',
      body: 'Rs.99 spent on your IDFC FIRST Bank Credit Card at Netflix on 29-06-2026.',
      date: iso(8, 9)
    },
    { sender: 'YESBNK', body: 'INR 3200 credited to A/C XX5521 towards Salary. Avl Bal Rs.68210.', date: iso(9, 8) },
    { sender: 'UNIONB', body: 'Rs.560 paid to Indian Oil via UPI. Ref 998821004.', date: iso(10, 17) },
    {
      sender: 'BOBIND',
      body: 'INR 2100 debited A/C XX7723 via NEFT to Landlord. Avl Bal Rs.15400.',
      date: iso(11, 15)
    },
    { sender: 'PNBSMS', body: 'Rs.75 spent using UPI to Rapido. Ref 118820091.', date: iso(12, 22) }
  ];
}

const MERCHANT_TEMPLATES: Array<{
  bank: string;
  sender: string;
  merchant: string;
  method: 'UPI' | 'Debit Card' | 'Credit Card' | 'ATM' | 'NEFT';
  amountRange: [number, number];
}> = [
  { bank: 'HDFC', sender: 'HDFCBK', merchant: 'Swiggy', method: 'UPI', amountRange: [150, 650] },
  { bank: 'HDFC', sender: 'HDFCBK', merchant: 'Amazon', method: 'Credit Card', amountRange: [299, 4500] },
  { bank: 'ICICI', sender: 'ICICIB', merchant: 'BigBasket', method: 'Debit Card', amountRange: [400, 2200] },
  { bank: 'ICICI', sender: 'ICICIB', merchant: 'Uber', method: 'UPI', amountRange: [80, 480] },
  { bank: 'SBI', sender: 'SBIINB', merchant: 'Zomato', method: 'UPI', amountRange: [180, 720] },
  { bank: 'SBI', sender: 'SBIINB', merchant: 'HPCL Petrol Pump', method: 'Debit Card', amountRange: [500, 3000] },
  { bank: 'Axis', sender: 'AXISBK', merchant: 'Flipkart', method: 'Credit Card', amountRange: [349, 5200] },
  { bank: 'Axis', sender: 'AXISBK', merchant: 'Apollo Pharmacy', method: 'UPI', amountRange: [90, 950] },
  { bank: 'Kotak', sender: 'KOTAKB', merchant: 'Myntra', method: 'Credit Card', amountRange: [499, 3200] },
  { bank: 'Kotak', sender: 'KOTAKB', merchant: 'BookMyShow', method: 'UPI', amountRange: [250, 900] },
  { bank: 'Canara', sender: 'CANBNK', merchant: 'ATM', method: 'ATM', amountRange: [1000, 5000] },
  { bank: 'Federal Bank', sender: 'FEDBNK', merchant: 'Airtel Prepaid Recharge', method: 'UPI', amountRange: [199, 599] },
  { bank: 'Yes Bank', sender: 'YESBNK', merchant: 'PVR Cinemas', method: 'Credit Card', amountRange: [350, 1200] }
];

const SUBSCRIPTIONS: Array<{ bank: string; sender: string; merchant: string; amount: number }> = [
  { bank: 'HDFC', sender: 'HDFCBK', merchant: 'Netflix', amount: 199 },
  { bank: 'ICICI', sender: 'ICICIB', merchant: 'Spotify', amount: 119 },
  { bank: 'Axis', sender: 'AXISBK', merchant: 'Amazon Prime', amount: 299 }
];

function bodyFor(
  merchant: string,
  amount: number,
  method: 'UPI' | 'Debit Card' | 'Credit Card' | 'ATM' | 'NEFT',
  bank: string,
  ref: number
): string {
  switch (method) {
    case 'UPI':
      return `INR ${amount} debited via UPI to ${merchant}. UPI Ref No ${ref}.`;
    case 'Credit Card':
      return `Rs.${amount} spent on your ${bank} Bank Credit Card at ${merchant}.`;
    case 'Debit Card':
      return `Rs.${amount} spent using Debit Card at ${merchant}. Avl Bal Rs.${(38000 - amount).toFixed(0)}.`;
    case 'ATM':
      return `Rs.${amount} withdrawn using ATM. Avl Bal Rs.${(38000 - amount).toFixed(0)}.`;
    case 'NEFT':
      return `INR ${amount} debited via NEFT to ${merchant}. Ref ${ref}.`;
  }
}

/**
 * Generates a larger, randomized-but-seeded batch of sample SMS spanning
 * several months — enough volume to make charts, insights, budgets, and the
 * virtualized transaction list meaningful. Includes a few intentional
 * duplicates and a monthly subscription pattern so those features have
 * something to detect.
 */
export function generateSampleSms(months = 3, referenceDate: Date = new Date()): RawSms[] {
  let seed = 42;
  const rand = () => {
    // Small deterministic PRNG so demo data is stable across loads.
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };

  const messages: RawSms[] = [...staticSampleSms(referenceDate)];
  const totalDays = months * 30;

  for (let day = 0; day < totalDays; day++) {
    const messagesToday = 1 + Math.floor(rand() * 3);
    for (let i = 0; i < messagesToday; i++) {
      const template = MERCHANT_TEMPLATES[Math.floor(rand() * MERCHANT_TEMPLATES.length)];
      const [min, max] = template.amountRange;
      const amount = Math.round(min + rand() * (max - min));
      const hour = Math.floor(rand() * 24);
      const d = new Date(referenceDate);
      d.setDate(d.getDate() - day);
      d.setHours(hour, Math.floor(rand() * 60), 0, 0);
      const ref = Math.floor(100000000 + rand() * 899999999);

      messages.push({
        sender: template.sender,
        body: bodyFor(template.merchant, amount, template.method, template.bank, ref),
        date: d.toISOString()
      });
    }
  }

  // Monthly subscriptions, roughly 30 days apart.
  for (const sub of SUBSCRIPTIONS) {
    for (let m = 0; m < months; m++) {
      const d = new Date(referenceDate);
      d.setDate(d.getDate() - m * 30 - 3);
      d.setHours(9, 15, 0, 0);
      messages.push({
        sender: sub.sender,
        body: `Rs.${sub.amount} spent on your ${sub.bank} Bank Credit Card at ${sub.merchant}.`,
        date: d.toISOString()
      });
    }
  }

  // A couple of intentional duplicates (bank resending the same alert) to
  // demonstrate duplicate detection when this batch is imported.
  if (messages.length > 5) {
    messages.push({ ...messages[2] });
    messages.push({ ...messages[5], body: messages[5].body }); // exact resend
  }

  // One message in a format the regex pipeline won't recognize, to exercise
  // the heuristic fallback.
  messages.push({
    sender: 'AD-SCBANK',
    body: 'Your account was debited 340 for a purchase at a local store.',
    date: new Date(referenceDate).toISOString()
  });

  return messages;
}
