// Real bank SMS arrive from DLT-registered sender IDs like "AD-HDFCBK-S" or
// "VM-SBIINB". We strip the common prefix/suffix noise, then match against a
// map of known codes. If the sender doesn't match anything (unregistered
// sender, forwarded message, etc.) we fall back to scanning the message body
// for the bank's name.

export const BANK_SENDER_MAP: Record<string, string> = {
  HDFC: 'HDFC Bank',
  HDFCBK: 'HDFC Bank',
  HDFCBN: 'HDFC Bank',
  SBI: 'State Bank of India',
  SBIINB: 'State Bank of India',
  SBIPSG: 'State Bank of India',
  SBICRD: 'State Bank of India',
  ICICI: 'ICICI Bank',
  ICICIB: 'ICICI Bank',
  ICICIT: 'ICICI Bank',
  AXIS: 'Axis Bank',
  AXISBK: 'Axis Bank',
  KOTAK: 'Kotak Mahindra Bank',
  KOTAKB: 'Kotak Mahindra Bank',
  CANBNK: 'Canara Bank',
  CANARA: 'Canara Bank',
  INDBNK: 'Indian Bank',
  INDIANBK: 'Indian Bank',
  FEDBNK: 'Federal Bank',
  FEDERAL: 'Federal Bank',
  IDFCFB: 'IDFC First Bank',
  IDFCBK: 'IDFC First Bank',
  IDFCFIRST: 'IDFC First Bank',
  YESBNK: 'Yes Bank',
  YESBANK: 'Yes Bank',
  UNIONB: 'Union Bank of India',
  UBIIND: 'Union Bank of India',
  UNIONBK: 'Union Bank of India',
  BOB: 'Bank of Baroda',
  BOBIND: 'Bank of Baroda',
  BARODA: 'Bank of Baroda',
  BOBBNK: 'Bank of Baroda',
  PNBSMS: 'Punjab National Bank',
  PUNBNK: 'Punjab National Bank',
  PNB: 'Punjab National Bank'
};

// Body-text fallback: ordered so more specific names are checked first
// (e.g. "IDFC First" before a bare "First").
const BODY_NAME_PATTERNS: Array<[RegExp, string]> = [
  [/hdfc/i, 'HDFC Bank'],
  [/\bsbi\b|state bank of india/i, 'State Bank of India'],
  [/icici/i, 'ICICI Bank'],
  [/\baxis\b/i, 'Axis Bank'],
  [/kotak/i, 'Kotak Mahindra Bank'],
  [/canara/i, 'Canara Bank'],
  [/indian bank/i, 'Indian Bank'],
  [/federal bank/i, 'Federal Bank'],
  [/idfc/i, 'IDFC First Bank'],
  [/yes bank/i, 'Yes Bank'],
  [/union bank/i, 'Union Bank of India'],
  [/bank of baroda|\bbob\b/i, 'Bank of Baroda'],
  [/punjab national bank|\bpnb\b/i, 'Punjab National Bank']
];

function cleanSenderId(sender: string): string {
  return sender
    .trim()
    .toUpperCase()
    .replace(/^[A-Z]{2}-/, '') // strip DLT prefix e.g. "AD-", "VM-", "JD-", "TX-"
    .replace(/-[A-Z]$/, '') // strip trailing "-S" / "-T" suffix
    .replace(/[^A-Z0-9]/g, '');
}

export function identifyBank(sender: string, body: string): string {
  const cleaned = cleanSenderId(sender || '');
  if (BANK_SENDER_MAP[cleaned]) return BANK_SENDER_MAP[cleaned];

  // Some sender IDs embed the code inside extra characters, e.g. "HDFCBK01".
  const partialKey = Object.keys(BANK_SENDER_MAP).find((key) => cleaned.includes(key));
  if (partialKey) return BANK_SENDER_MAP[partialKey];

  for (const [pattern, bankName] of BODY_NAME_PATTERNS) {
    if (pattern.test(body)) return bankName;
  }

  return 'Unknown Bank';
}
