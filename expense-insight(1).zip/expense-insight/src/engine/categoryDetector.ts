import type { Category, PaymentMethod } from '@/types';
import { db } from '@/db/db';

// Checked in order; the first category whose keyword list matches wins.
// Ordered from most specific brand/keyword signal to most generic, so e.g.
// "Reliance Fresh" (Groceries) is caught before a generic Shopping match,
// and subscription apps are caught before the broader Entertainment bucket.
const CATEGORY_KEYWORDS: Array<[Category, string[]]> = [
  [
    'Groceries',
    [
      'bigbasket',
      'blinkit',
      'zepto',
      'grofers',
      'dmart',
      'd-mart',
      'more supermarket',
      'reliance fresh',
      'fresh',
      'grocery',
      'groceries',
      'nature basket',
      'spencer',
      'jiomart'
    ]
  ],
  [
    'Food',
    [
      'swiggy',
      'zomato',
      "domino's",
      'dominos',
      'mcdonald',
      'kfc',
      'pizza',
      'restaurant',
      'cafe',
      'starbucks',
      'burger',
      'eatsure',
      'faasos',
      'box8',
      'biryani',
      'foodpanda'
    ]
  ],
  ['Fuel', ['petrol', 'diesel', 'fuel', 'hpcl', 'iocl', 'bpcl', 'indian oil', 'shell', 'petroleum']],
  [
    'Medical',
    [
      'pharmacy',
      'apollo',
      'medplus',
      'netmeds',
      'pharmeasy',
      '1mg',
      'hospital',
      'clinic',
      'diagnostic',
      'medical',
      'healthcare'
    ]
  ],
  [
    'Subscription',
    [
      'netflix',
      'spotify',
      'prime video',
      'amazon prime',
      'hotstar',
      'jiocinema',
      'apple music',
      'youtube premium',
      'sonyliv',
      'zee5'
    ]
  ],
  ['Entertainment', ['bookmyshow', 'pvr', 'inox', 'cinema', 'multiplex', 'movie']],
  [
    'Shopping',
    [
      'amazon',
      'flipkart',
      'myntra',
      'ajio',
      'nykaa',
      'meesho',
      'tatacliq',
      'shopclues',
      'snapdeal',
      'reliance digital',
      'reliance trends',
      'reliance',
      'mall'
    ]
  ],
  [
    'Travel',
    [
      'uber',
      'ola',
      'rapido',
      'irctc',
      'makemytrip',
      'goibibo',
      'redbus',
      'indigo',
      'spicejet',
      'air india',
      'vistara',
      'yatra',
      'oyo',
      'airbnb',
      'cab',
      'taxi'
    ]
  ],
  [
    'Bills',
    [
      'electricity',
      'bescom',
      'mseb',
      'water bill',
      'gas bill',
      'broadband',
      'act fibernet',
      'power bill',
      'municipal',
      'wifi bill'
    ]
  ],
  [
    'Recharge',
    ['recharge', 'airtel prepaid', 'jio prepaid', 'vi prepaid', 'vodafone', 'dth', 'tatasky', 'tata play', 'd2h']
  ],
  [
    'Investment',
    [
      'zerodha',
      'groww',
      'upstox',
      'coin by zerodha',
      'mutual fund',
      ' sip ',
      'nps',
      'icici direct',
      'angel one',
      'indmoney'
    ]
  ],
  ['Salary', ['salary', 'sal credited', 'payroll']],
  ['Cashback', ['cashback', 'reward points', 'cash back']],
  ['Refund', ['refund', 'reversal', 'reversed']],
  [
    'Education',
    ['school fee', 'college', 'tuition', 'udemy', 'byju', 'unacademy', 'coursera', 'exam fee', 'school']
  ],
  ['Transfer', ['neft', 'imps', 'rtgs', 'transferred to', 'sent to', 'fund transfer']],
  ['ATM', ['atm', 'cash withdrawal', 'withdrawn']]
];

/**
 * Pure keyword-based category detector. Takes a lowercase-agnostic text
 * blob (merchant name + narration works well, since modifiers like "Fresh"
 * or "Digital" often live next to the merchant name, not in isolation) and
 * returns the best-guess category.
 */
export function detectCategory(context: string, paymentMethod?: PaymentMethod): Category {
  const text = context.toLowerCase();

  // An ATM withdrawal is unambiguous regardless of keyword matches.
  if (paymentMethod === 'ATM') return 'ATM';

  for (const [category, keywords] of CATEGORY_KEYWORDS) {
    if (keywords.some((kw) => text.includes(kw))) return category;
  }
  return 'Others';
}

/**
 * DB-aware wrapper: checks the person's own custom keyword rules first
 * (Settings > Categories in the app), then falls back to the built-in
 * detector above.
 */
export async function detectCategoryWithUserRules(
  context: string,
  paymentMethod?: PaymentMethod
): Promise<Category> {
  const text = context.toLowerCase();
  const rules = await db.categoryRules.toArray();
  const matchedRule = rules.find((rule) => text.includes(rule.keyword.toLowerCase()));
  if (matchedRule) return matchedRule.category;
  return detectCategory(context, paymentMethod);
}
