import { db } from '@/db/db';
import type { Transaction } from '@/types';
import { levenshteinSimilarity } from '@/utils/similarity';

export interface DuplicateCheckResult {
  /** Score > 95: near-certain duplicate. Caller should skip insertion silently. */
  isDuplicate: boolean;
  /** A plausible-but-uncertain match exists; ask the person before inserting. */
  needsReview: boolean;
  score: number;
  matchedTransaction?: Transaction;
}

type HashInput = Pick<Transaction, 'bank' | 'amount' | 'date' | 'reference' | 'normalizedMerchant' | 'type'>;

async function sha256Hex(input: string): Promise<string> {
  const enc = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * A transaction's identity fingerprint. Uses the *date* (not time) so that a
 * bank resending the same alert a few seconds apart still hashes the same.
 */
export async function computeTransactionHash(t: HashInput): Promise<string> {
  const raw = [t.bank, t.amount.toFixed(2), t.date.slice(0, 10), t.reference ?? '', t.normalizedMerchant, t.type].join(
    '|'
  );
  return sha256Hex(raw);
}

type HashKeys = 'bank' | 'amount' | 'date' | 'reference' | 'normalizedMerchant' | 'type' | 'time';

/**
 * Checks a candidate transaction against what's already stored.
 *
 * Two-stage approach:
 *  1. Exact hash match (fast, indexed) — this is the common case for a
 *     re-imported or re-forwarded SMS.
 *  2. Fuzzy same-day/same-bank/same-amount comparison, scored 0-100, for
 *     cases where the reference number formats differently between two
 *     copies of "the same" bank alert.
 *
 * The spec's ">95% => skip, otherwise ask" rule is interpreted as: only
 * *plausible* matches (score >= 60) prompt a review. A transaction with no
 * meaningful overlap against anything on record has a score near 0 and is
 * simply inserted — asking about every brand-new transaction would make the
 * import flow unusable at "thousands of SMS" scale.
 */
export async function checkDuplicate(
  candidate: Pick<Transaction, HashKeys> & { hash: string }
): Promise<DuplicateCheckResult> {
  const existingHash = await db.duplicateHashes.where('hash').equals(candidate.hash).first();
  if (existingHash) {
    const matched = await db.transactions.get(existingHash.transactionId);
    return { isDuplicate: true, needsReview: false, score: 100, matchedTransaction: matched };
  }

  const dayKey = candidate.date.slice(0, 10);
  const sameDayAndBank = await db.transactions
    .where('bank')
    .equals(candidate.bank)
    .filter((t) => t.date.slice(0, 10) === dayKey && Math.abs(t.amount - candidate.amount) < 0.01)
    .toArray();

  let best = { score: 0, tx: undefined as Transaction | undefined };
  for (const tx of sameDayAndBank) {
    let score = 40; // amount matched
    score += 20; // bank matched
    score += Math.round(levenshteinSimilarity(tx.normalizedMerchant, candidate.normalizedMerchant) * 20);
    if (tx.date === candidate.date) score += 10;
    if (tx.reference && candidate.reference && tx.reference === candidate.reference) score += 30;
    if (tx.time && candidate.time && tx.time === candidate.time) score += 10;
    score = Math.min(score, 100);
    if (score > best.score) best = { score, tx };
  }

  if (best.score > 95) return { isDuplicate: true, needsReview: false, score: best.score, matchedTransaction: best.tx };
  if (best.score >= 60) return { isDuplicate: false, needsReview: true, score: best.score, matchedTransaction: best.tx };
  return { isDuplicate: false, needsReview: false, score: best.score };
}

/** Records a newly-inserted transaction's hash so future imports can find it via the fast path. */
export async function registerHash(hash: string, transactionId: number): Promise<void> {
  await db.duplicateHashes.put({ hash, transactionId });
}
