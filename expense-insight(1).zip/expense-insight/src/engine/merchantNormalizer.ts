import { toTitleCase } from '@/utils/format';

// Each entry: if the cleaned merchant text *contains* the left-hand token,
// it's normalized to the canonical right-hand name.
const MERCHANT_ALIASES: Array<[string, string]> = [
  ['AMAZON PAY', 'Amazon'],
  ['AMAZON', 'Amazon'],
  ['FLIPKART', 'Flipkart'],
  ['MYNTRA', 'Myntra'],
  ['AJIO', 'Ajio'],
  ['NYKAA', 'Nykaa'],
  ['MEESHO', 'Meesho'],
  ['SWIGGY INSTAMART', 'Swiggy'],
  ['SWIGGY', 'Swiggy'],
  ['ZOMATO', 'Zomato'],
  ['UBER', 'Uber'],
  ['OLA', 'Ola'],
  ['RAPIDO', 'Rapido'],
  ['BIGBASKET', 'BigBasket'],
  ['BLINKIT', 'Blinkit'],
  ['ZEPTO', 'Zepto'],
  ['GROFERS', 'Blinkit'],
  ['JIOMART', 'JioMart'],
  ['RELIANCE FRESH', 'Reliance'],
  ['RELIANCE DIGITAL', 'Reliance'],
  ['RELIANCE TRENDS', 'Reliance'],
  ['RELIANCE', 'Reliance'],
  ['NETFLIX', 'Netflix'],
  ['SPOTIFY', 'Spotify'],
  ['AMAZON PRIME', 'Amazon Prime'],
  ['HOTSTAR', 'Disney+ Hotstar'],
  ['BOOKMYSHOW', 'BookMyShow'],
  ['IRCTC', 'IRCTC'],
  ['MAKEMYTRIP', 'MakeMyTrip'],
  ['AIRTEL', 'Airtel'],
  ['JIO', 'Jio'],
  ['VODAFONE IDEA', 'Vi'],
  [' VI ', 'Vi'],
  ['ZERODHA', 'Zerodha'],
  ['GROWW', 'Groww'],
  ['UPSTOX', 'Upstox'],
  ['APOLLO', 'Apollo Pharmacy'],
  ['MEDPLUS', 'MedPlus'],
  ['1MG', 'Tata 1mg'],
  ['STARBUCKS', 'Starbucks'],
  ["DOMINO'S", "Domino's Pizza"],
  ['DOMINOS', "Domino's Pizza"]
];

function cleanRaw(raw: string): string {
  return raw
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9&.'\- ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Collapses noisy raw merchant strings (as they appear in bank SMS) down to
 * a single canonical display name, e.g. "AMAZON PAY", "Amazon India" and
 * "AMAZON.IN" all become "Amazon".
 */
export function normalizeMerchant(raw: string): string {
  if (!raw || !raw.trim()) return 'Unknown Merchant';
  const cleaned = ` ${cleanRaw(raw)} `;

  for (const [token, canonical] of MERCHANT_ALIASES) {
    if (cleaned.includes(` ${token} `) || cleaned.includes(token)) {
      return canonical;
    }
  }

  return toTitleCase(cleaned.trim());
}
