import type { ParsedSmsResult, PaymentMethod, RawSms, Transaction, TransactionType } from '@/types';
import { identifyBank } from './bankPatterns';
import { detectCategoryWithUserRules } from './categoryDetector';
import { normalizeMerchant } from './merchantNormalizer';
import { computeTransactionHash } from './duplicateDetector';

const AMOUNT_RE = /(?:rs\.?|inr|₹)\s*[:.]?\s*([\d,]+(?:\.\d{1,2})?)/i;
const DEBIT_KEYWORDS_RE = /\b(debited|spent|paid|withdrawn|purchase|txn of|debit)\b/i;
const CREDIT_KEYWORDS_RE = /\b(credited|received|deposited|refunded|refund of|cashback of|salary credited)\b/i;

const CREDIT_CARD_RE = /credit card/i;
const DEBIT_CARD_RE = /debit card/i;
const UPI_METHOD_RE = /\bupi\b/i;
const ATM_METHOD_RE = /\batm\b/i;
const NETBANKING_RE = /net\s*banking/i;
const IMPS_RE = /\bimps\b/i;
const NEFT_RE = /\bneft\b/i;
const RTGS_RE = /\brtgs\b/i;

const ACCOUNT_RE = /A\/C\s*(?:no\.?)?\s*([Xx*]{0,}\d{2,6})/i;
const REF_RE = /(?:ref(?:erence)?\.?\s*(?:no\.?)?|txn\s*id\.?|UPI\s*Ref\.?\s*(?:No\.?)?)[:\s]*([A-Za-z0-9]{4,})/i;
const BAL_RE = /(?:avl\s*bal(?:ance)?|available\s*bal(?:ance)?|\bbal)[:\s]*(?:rs\.?|inr|₹)?\s*([\d,]+(?:\.\d{1,2})?)/i;
const UPI_ID_RE = /\b([a-zA-Z0-9.\-_]{2,}@[a-zA-Z]{2,})\b/;
const DATE_RE = /\b(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})\b/;
const MERCHANT_RE =
  /(?:\bat\b|\bto\b|\bin\b)\s+([A-Z][A-Za-z0-9&.'\-\s]{1,40}?)(?=\s+(?:on|successful|dt|via|A\/c|avl|ref|bal)\b|[.,]|$)/i;

export function extractAmount(body: string): number | null {
  const m = body.match(AMOUNT_RE);
  if (!m) return null;
  const num = parseFloat(m[1].replace(/,/g, ''));
  return Number.isFinite(num) ? num : null;
}

export function extractType(body: string): { type: TransactionType; explicit: boolean } {
  if (CREDIT_KEYWORDS_RE.test(body)) return { type: 'credit', explicit: true };
  if (DEBIT_KEYWORDS_RE.test(body)) return { type: 'debit', explicit: true };
  return { type: 'debit', explicit: false }; // most bank SMS alerts are spends
}

export function extractPaymentMethod(body: string): PaymentMethod {
  if (CREDIT_CARD_RE.test(body)) return 'Credit Card';
  if (DEBIT_CARD_RE.test(body)) return 'Debit Card';
  if (UPI_METHOD_RE.test(body)) return 'UPI';
  if (ATM_METHOD_RE.test(body)) return 'ATM';
  if (NETBANKING_RE.test(body)) return 'Net Banking';
  if (IMPS_RE.test(body)) return 'IMPS';
  if (NEFT_RE.test(body)) return 'NEFT';
  if (RTGS_RE.test(body)) return 'RTGS';
  return 'Other';
}

export function extractMerchant(body: string): string | null {
  const m = body.match(MERCHANT_RE);
  if (!m) return null;
  return m[1].trim().replace(/\s{2,}/g, ' ');
}

function buildIsoDate(body: string, fallbackIso: string): string {
  const m = body.match(DATE_RE);
  const fallback = new Date(fallbackIso);
  const timePart = Number.isNaN(fallback.getTime())
    ? { h: 0, m: 0, s: 0 }
    : { h: fallback.getUTCHours(), m: fallback.getUTCMinutes(), s: fallback.getUTCSeconds() };

  if (!m) return fallbackIso;

  const dd = m[1];
  const mm = m[2];
  const yy = m[3];
  let year = parseInt(yy, 10);
  if (year < 100) year += 2000;
  const day = parseInt(dd, 10);
  const month = parseInt(mm, 10);
  if (month < 1 || month > 12 || day < 1 || day > 31) return fallbackIso;

  // Body dates rarely carry a time, so we borrow the SMS's own received time
  // (bank alerts land within seconds of the transaction).
  const composed = new Date(Date.UTC(year, month - 1, day, timePart.h, timePart.m, timePart.s));
  return composed.toISOString();
}

interface ExtractedFields {
  amount: number;
  type: TransactionType;
  typeExplicit: boolean;
  paymentMethod: PaymentMethod;
  bank: string;
  bankExplicit: boolean;
  merchant: string;
  merchantExplicit: boolean;
  account?: string;
  reference?: string;
  balance?: number;
  upiId?: string;
  date: string;
  dateExplicit: boolean;
}

function runRegexPipeline(raw: RawSms): ExtractedFields | null {
  const body = raw.body;
  const amount = extractAmount(body);
  if (amount === null) return null;

  const { type, explicit: typeExplicit } = extractType(body);
  const paymentMethod = extractPaymentMethod(body);

  const bank = identifyBank(raw.sender, body);
  const bankExplicit = bank !== 'Unknown Bank';

  let merchant = extractMerchant(body);
  let merchantExplicit = merchant !== null;
  if (!merchant && paymentMethod === 'ATM') {
    merchant = 'ATM Withdrawal';
    merchantExplicit = true;
  }
  if (!merchant) merchant = 'Unknown Merchant';

  const account = body.match(ACCOUNT_RE)?.[1];
  const reference = body.match(REF_RE)?.[1];
  const balanceMatch = body.match(BAL_RE)?.[1];
  const balance = balanceMatch ? parseFloat(balanceMatch.replace(/,/g, '')) : undefined;
  const upiId = body.match(UPI_ID_RE)?.[1];

  const dateExplicit = DATE_RE.test(body);
  const date = buildIsoDate(body, raw.date);

  return {
    amount,
    type,
    typeExplicit,
    paymentMethod,
    bank,
    bankExplicit,
    merchant,
    merchantExplicit,
    account,
    reference,
    balance,
    upiId,
    date,
    dateExplicit
  };
}

function computeConfidence(f: ExtractedFields): number {
  let score = 30; // amount was found, or we wouldn't be here
  if (f.typeExplicit) score += 15;
  if (f.bankExplicit) score += 15;
  if (f.merchantExplicit) score += 20;
  if (f.paymentMethod !== 'Other') score += 10;
  if (f.reference) score += 5;
  if (f.dateExplicit) score += 5;
  return Math.min(score, 100);
}

// --- Pluggable fallback for message formats the regex pipeline can't read ---

export interface AiExtractionProvider {
  extract(sms: RawSms): Promise<Partial<ExtractedFields> | null>;
}

const OTP_RE = /\botp\b|one[\s-]?time\s+password|verification\s+code/i;

/**
 * Best-effort generic fallback: looks for *any* currency-shaped number and a
 * generic spend/receive verb, without assuming a particular bank's template.
 * This keeps totally unrecognized formats from being silently dropped.
 *
 * A real AI-based fallback (e.g. calling an LLM to read an odd SMS format)
 * is intentionally NOT wired up here: this is a static, offline PWA with no
 * backend, so any API key placed in client code would be exposed to anyone
 * who opens dev tools. To add one safely, implement AiExtractionProvider
 * against your own backend proxy (which holds the key server-side) and pass
 * it to setAiExtractionProvider below.
 */
export class HeuristicFallbackExtractor implements AiExtractionProvider {
  async extract(sms: RawSms): Promise<Partial<ExtractedFields> | null> {
    const body = sms.body;

    // An OTP/verification SMS is full of digits but is never a transaction —
    // reading its code as an "amount" would fabricate a phantom expense.
    if (OTP_RE.test(body)) return null;

    const { type, explicit: typeExplicit } = extractType(body);
    const paymentMethod = extractPaymentMethod(body);
    // Require some explicit transactional signal before trusting a bare
    // number as an amount — otherwise any SMS containing digits (phone
    // numbers, dates, order IDs) could be misread as a transaction.
    const hasTransactionalSignal = typeExplicit || paymentMethod !== 'Other' || /\ba\/c\b|account|bank/i.test(body);
    if (!hasTransactionalSignal) return null;

    const genericAmountRe = /([\d,]+(?:\.\d{1,2})?)/;
    const m = body.match(genericAmountRe);
    if (!m) return null;
    const amount = parseFloat(m[1].replace(/,/g, ''));
    if (!Number.isFinite(amount) || amount <= 0) return null;

    const bank = identifyBank(sms.sender, body);
    const merchant = extractMerchant(body);
    return {
      amount,
      type,
      typeExplicit,
      paymentMethod,
      bank,
      bankExplicit: bank !== 'Unknown Bank',
      merchant: merchant ?? 'Unknown Merchant',
      merchantExplicit: merchant !== null,
      date: sms.date,
      dateExplicit: false
    };
  }
}

let aiExtractionProvider: AiExtractionProvider = new HeuristicFallbackExtractor();

export function setAiExtractionProvider(provider: AiExtractionProvider): void {
  aiExtractionProvider = provider;
}

/** Parses one raw SMS into a transaction-shaped record, ready to be checked for duplicates and inserted. */
export async function parseSms(raw: RawSms): Promise<ParsedSmsResult> {
  if (!raw.body || !raw.body.trim()) {
    return { success: false, error: 'Empty message.' };
  }

  let fields = runRegexPipeline(raw);
  let confidence: number;

  if (fields) {
    confidence = computeConfidence(fields);
  } else {
    const fallback = await aiExtractionProvider.extract(raw);
    if (!fallback || fallback.amount == null) {
      return { success: false, error: "Couldn't find a transaction amount in this message." };
    }
    fields = {
      amount: fallback.amount,
      type: fallback.type ?? 'debit',
      typeExplicit: fallback.typeExplicit ?? false,
      paymentMethod: fallback.paymentMethod ?? 'Other',
      bank: fallback.bank ?? 'Unknown Bank',
      bankExplicit: fallback.bankExplicit ?? false,
      merchant: fallback.merchant ?? 'Unknown Merchant',
      merchantExplicit: fallback.merchantExplicit ?? false,
      account: fallback.account,
      reference: fallback.reference,
      balance: fallback.balance,
      upiId: fallback.upiId,
      date: fallback.date ?? raw.date,
      dateExplicit: fallback.dateExplicit ?? false
    };
    // Fallback extractions are capped at a modest confidence — they were
    // never matched against a known bank template.
    confidence = Math.min(computeConfidence(fields) - 15, 55);
  }

  const normalizedMerchant = normalizeMerchant(fields.merchant);
  const category = await detectCategoryWithUserRules(`${fields.merchant} ${raw.body}`, fields.paymentMethod);

  const transactionCore = {
    amount: fields.amount,
    currency: 'INR',
    bank: fields.bank,
    account: fields.account,
    type: fields.type,
    merchant: fields.merchant,
    normalizedMerchant,
    paymentMethod: fields.paymentMethod,
    date: fields.date,
    time: fields.date,
    reference: fields.reference,
    upiId: fields.upiId,
    balance: fields.balance,
    narration: raw.body.trim(),
    category,
    confidence,
    rawSms: raw.body
  };

  const hash = await computeTransactionHash(transactionCore);

  return {
    success: true,
    transaction: { ...transactionCore, hash } as Omit<Transaction, 'id' | 'createdAt'>
  };
}
