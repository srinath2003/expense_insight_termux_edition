import { useLiveQuery } from 'dexie-react-hooks';
import { endOfMonth, endOfWeek, startOfMonth, startOfWeek, subDays, subMonths } from 'date-fns';
import { db } from '@/db/db';
import type { Transaction } from '@/types';
import { useFilterStore } from '@/store/filterStore';

export function useNowIso(): string {
  return new Date().toISOString();
}

export function useMonthTransactions(monthOffset = 0): Transaction[] | undefined {
  return useLiveQuery(async () => {
    const base = subMonths(new Date(), monthOffset);
    const start = startOfMonth(base).toISOString();
    const end = endOfMonth(base).toISOString();
    return db.transactions.where('date').between(start, end, true, true).toArray();
  }, [monthOffset]);
}

export function useRecentWindowTransactions(days: number): Transaction[] | undefined {
  return useLiveQuery(async () => {
    const start = subDays(new Date(), days).toISOString();
    const end = new Date().toISOString();
    return db.transactions.where('date').between(start, end, true, true).toArray();
  }, [days]);
}

function rangeForPreset(preset: string, customStart?: string, customEnd?: string): { start: string; end: string } {
  const now = new Date();
  switch (preset) {
    case 'today':
      return { start: `${now.toISOString().slice(0, 10)}T00:00:00.000Z`, end: now.toISOString() };
    case 'yesterday': {
      const y = subDays(now, 1);
      return {
        start: `${y.toISOString().slice(0, 10)}T00:00:00.000Z`,
        end: `${y.toISOString().slice(0, 10)}T23:59:59.999Z`
      };
    }
    case 'thisWeek':
      return { start: startOfWeek(now).toISOString(), end: endOfWeek(now).toISOString() };
    case 'lastMonth': {
      const last = subMonths(now, 1);
      return { start: startOfMonth(last).toISOString(), end: endOfMonth(last).toISOString() };
    }
    case 'custom':
      return { start: customStart ?? startOfMonth(now).toISOString(), end: customEnd ?? now.toISOString() };
    case 'all':
      return { start: '0000-01-01T00:00:00.000Z', end: '9999-12-31T23:59:59.999Z' };
    case 'thisMonth':
    default:
      return { start: startOfMonth(now).toISOString(), end: endOfMonth(now).toISOString() };
  }
}

/** Transactions matching the current search + filter store state, newest first. */
export function useFilteredTransactions(): Transaction[] | undefined {
  const { search, datePreset, customStart, customEnd, categories, banks, paymentMethods } = useFilterStore();

  return useLiveQuery(async () => {
    const { start, end } = rangeForPreset(datePreset, customStart, customEnd);
    const collection = db.transactions.where('date').between(start, end, true, true);
    let results = await collection.toArray();

    if (categories.length > 0) results = results.filter((t) => categories.includes(t.category));
    if (banks.length > 0) results = results.filter((t) => banks.includes(t.bank));
    if (paymentMethods.length > 0) results = results.filter((t) => paymentMethods.includes(t.paymentMethod));
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      results = results.filter(
        (t) =>
          t.normalizedMerchant.toLowerCase().includes(q) ||
          t.merchant.toLowerCase().includes(q) ||
          t.narration.toLowerCase().includes(q) ||
          t.bank.toLowerCase().includes(q) ||
          String(t.amount).includes(q)
      );
    }

    return results.sort((a, b) => (a.date < b.date ? 1 : -1));
  }, [search, datePreset, customStart, customEnd, categories, banks, paymentMethods]);
}

export function useAllBanks(): string[] | undefined {
  return useLiveQuery(async () => {
    const all = await db.transactions.toArray();
    return Array.from(new Set(all.map((t) => t.bank))).sort();
  }, []);
}

export function useAllMerchants() {
  return useLiveQuery(() => db.merchants.orderBy('totalSpent').reverse().toArray(), []);
}
