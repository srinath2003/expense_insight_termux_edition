import { useMemo, useState } from 'react';
import { Chip, Stack, Typography } from '@mui/material';
import { useRecentWindowTransactions } from '@/hooks/useDexieData';
import { cashflowSeries, dailySeries, groupByCategory, heatmapSeries, monthlySeries, topMerchants } from '@/services/analyticsService';
import GlassCard from '@/components/common/GlassCard';
import CategoryPieChart from '@/components/charts/CategoryPieChart';
import DailyLineChart from '@/components/charts/DailyLineChart';
import MonthlyBarChart from '@/components/charts/MonthlyBarChart';
import TopMerchantsBarChart from '@/components/charts/TopMerchantsBarChart';
import CashflowAreaChart from '@/components/charts/CashflowAreaChart';
import SpendingHeatmap from '@/components/charts/SpendingHeatmap';

const RANGE_OPTIONS = [
  { label: '30 days', days: 30 },
  { label: '90 days', days: 90 },
  { label: '180 days', days: 180 }
];

export default function AnalyticsPage() {
  const [days, setDays] = useState(90);
  const transactions = useRecentWindowTransactions(days);
  const now = new Date().toISOString();

  const categoryData = useMemo(() => (transactions ? groupByCategory(transactions) : []), [transactions]);
  const daily = useMemo(() => (transactions ? dailySeries(transactions, Math.min(days, 60), now) : []), [transactions, days, now]);
  const monthly = useMemo(() => (transactions ? monthlySeries(transactions, 6, now) : []), [transactions, now]);
  const merchants = useMemo(() => (transactions ? topMerchants(transactions, 8) : []), [transactions]);
  const cashflow = useMemo(() => (transactions ? cashflowSeries(transactions, Math.min(days, 60), now) : []), [transactions, days, now]);
  const heatmap = useMemo(() => (transactions ? heatmapSeries(transactions, days, now) : []), [transactions, days, now]);

  return (
    <Stack spacing={2.5}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>
        Analytics
      </Typography>

      <Stack direction="row" spacing={1}>
        {RANGE_OPTIONS.map((opt) => (
          <Chip
            key={opt.days}
            label={opt.label}
            onClick={() => setDays(opt.days)}
            color={days === opt.days ? 'primary' : 'default'}
            variant={days === opt.days ? 'filled' : 'outlined'}
            size="small"
          />
        ))}
      </Stack>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Expense by category
        </Typography>
        <CategoryPieChart data={categoryData} />
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Daily expenses
        </Typography>
        <DailyLineChart data={daily} />
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Monthly expenses
        </Typography>
        <MonthlyBarChart data={monthly} />
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Top merchants
        </Typography>
        <TopMerchantsBarChart data={merchants} />
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Cashflow
        </Typography>
        <CashflowAreaChart data={cashflow} />
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Daily spending calendar
        </Typography>
        <SpendingHeatmap data={heatmap} />
      </GlassCard>
    </Stack>
  );
}
