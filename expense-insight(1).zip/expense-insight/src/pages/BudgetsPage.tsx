import { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, MenuItem, Stack, TextField, Typography } from '@mui/material';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import type { Category } from '@/types';
import { useMonthTransactions } from '@/hooks/useDexieData';
import { calculateBudgetStatus, deleteBudget, listBudgetsForMonth, upsertBudget } from '@/services/budgetService';
import BudgetCard from '@/components/budgets/BudgetCard';

const BUDGET_CATEGORIES: Array<Category | 'Overall'> = [
  'Overall',
  'Food',
  'Groceries',
  'Shopping',
  'Travel',
  'Bills',
  'Entertainment',
  'Recharge',
  'Fuel',
  'Medical',
  'Subscription',
  'Education',
  'Others'
];

export default function BudgetsPage() {
  const month = new Date().toISOString().slice(0, 7);
  const budgets = useLiveQuery(() => listBudgetsForMonth(month), [month]);
  const monthTransactions = useMonthTransactions(0);
  const todayIso = new Date().toISOString();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [category, setCategory] = useState<Category | 'Overall'>('Overall');
  const [limit, setLimit] = useState('');

  const statuses = useMemo(() => {
    if (!budgets || !monthTransactions) return [];
    return budgets.map((b) => calculateBudgetStatus(b, monthTransactions, todayIso));
  }, [budgets, monthTransactions, todayIso]);

  async function handleSave() {
    const value = parseFloat(limit);
    if (!Number.isFinite(value) || value <= 0) return;
    await upsertBudget({ category, monthlyLimit: value, month });
    setDialogOpen(false);
    setLimit('');
  }

  return (
    <Stack spacing={2}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Typography variant="h5" sx={{ fontWeight: 700 }}>
          Budgets
        </Typography>
        <Button startIcon={<AddRoundedIcon />} variant="contained" size="small" onClick={() => setDialogOpen(true)}>
          Add
        </Button>
      </Stack>

      {statuses.length === 0 ? (
        <Typography color="text.secondary" sx={{ textAlign: 'center', py: 6 }}>
          No budgets set for this month yet. Tap "Add" to set one — try "Overall" for a total monthly cap.
        </Typography>
      ) : (
        statuses.map((status) => (
          <BudgetCard key={status.budget.id} status={status} onDelete={() => status.budget.id && deleteBudget(status.budget.id)} />
        ))
      )}

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} fullWidth maxWidth="xs">
        <DialogTitle>New budget</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 0.5 }}>
            <TextField select label="Category" value={category} onChange={(e) => setCategory(e.target.value as Category)} fullWidth>
              {BUDGET_CATEGORIES.map((c) => (
                <MenuItem key={c} value={c}>
                  {c}
                </MenuItem>
              ))}
            </TextField>
            <TextField label="Monthly limit" type="number" value={limit} onChange={(e) => setLimit(e.target.value)} fullWidth inputProps={{ min: 0 }} />
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave}>
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
