import { useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Box, Grid, Stack, Typography } from '@mui/material';
import TodayRoundedIcon from '@mui/icons-material/TodayRounded';
import CalendarMonthRoundedIcon from '@mui/icons-material/CalendarMonthRounded';
import DateRangeRoundedIcon from '@mui/icons-material/DateRangeRounded';
import SavingsRoundedIcon from '@mui/icons-material/SavingsRounded';
import TrendingFlatRoundedIcon from '@mui/icons-material/TrendingFlatRounded';
import PaidRoundedIcon from '@mui/icons-material/PaidRounded';
import StoreRoundedIcon from '@mui/icons-material/StoreRounded';
import TagRoundedIcon from '@mui/icons-material/TagRounded';
import { db } from '@/db/db';
import { useMonthTransactions, useRecentWindowTransactions } from '@/hooks/useDexieData';
import { computeDashboardStats, groupByCategory } from '@/services/analyticsService';
import { generateInsights } from '@/services/insightsService';
import { formatCurrency } from '@/utils/format';
import StatCard from '@/components/common/StatCard';
import GlassCard from '@/components/common/GlassCard';
import InsightCard from '@/components/insights/InsightCard';
import CategoryPieChart from '@/components/charts/CategoryPieChart';
import TransactionRow from '@/components/transactions/TransactionRow';
import { startOfWeek } from 'date-fns';

export default function DashboardPage() {
  const currentMonthTx = useMonthTransactions(0);
  const previousMonthTx = useMonthTransactions(1);
  const recentWindowTx = useRecentWindowTransactions(90);
  const currentMonthBudget = useLiveQuery(
    () => db.budgets.where('[category+month]').equals(['Overall', new Date().toISOString().slice(0, 7)]).first(),
    []
  );

  const todayIso = new Date().toISOString();
  const weekStartIso = startOfWeek(new Date()).toISOString();

  const stats = useMemo(() => {
    if (!currentMonthTx) return null;
    return computeDashboardStats(currentMonthTx, todayIso, weekStartIso);
  }, [currentMonthTx, todayIso, weekStartIso]);

  const insights = useMemo(() => {
    if (!currentMonthTx || !previousMonthTx || !recentWindowTx) return [];
    return generateInsights({ currentMonth: currentMonthTx, previousMonth: previousMonthTx, recentWindow: recentWindowTx }).slice(0, 2);
  }, [currentMonthTx, previousMonthTx, recentWindowTx]);

  const categoryData = useMemo(() => (currentMonthTx ? groupByCategory(currentMonthTx) : []), [currentMonthTx]);
  const recent = useMemo(() => (currentMonthTx ?? []).slice(0, 5), [currentMonthTx]);

  if (!stats) {
    return null;
  }

  const remaining = currentMonthBudget ? currentMonthBudget.monthlyLimit - stats.monthSpending : null;

  return (
    <Stack spacing={2.5}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>
        Good to see you
      </Typography>

      <Grid container spacing={1.5}>
        <Grid item xs={6}>
          <StatCard label="Today" value={formatCurrency(stats.todaySpending)} icon={TodayRoundedIcon} />
        </Grid>
        <Grid item xs={6}>
          <StatCard label="This week" value={formatCurrency(stats.weekSpending)} icon={DateRangeRoundedIcon} />
        </Grid>
        <Grid item xs={6}>
          <StatCard label="This month" value={formatCurrency(stats.monthSpending)} icon={CalendarMonthRoundedIcon} />
        </Grid>
        <Grid item xs={6}>
          <StatCard
            label="Remaining budget"
            value={remaining === null ? 'Not set' : formatCurrency(remaining)}
            caption={remaining === null ? 'Set one in Budgets' : undefined}
            tone={remaining !== null && remaining < 0 ? 'negative' : 'neutral'}
            icon={SavingsRoundedIcon}
          />
        </Grid>
        <Grid item xs={6}>
          <StatCard label="Avg. daily spend" value={formatCurrency(stats.averageDailySpending)} icon={TrendingFlatRoundedIcon} />
        </Grid>
        <Grid item xs={6}>
          <StatCard
            label="Largest transaction"
            value={stats.largestTransaction ? formatCurrency(stats.largestTransaction.amount) : '—'}
            caption={stats.largestTransaction?.normalizedMerchant}
            icon={PaidRoundedIcon}
          />
        </Grid>
        <Grid item xs={6}>
          <StatCard
            label="Most visited"
            value={stats.mostVisitedMerchant?.name ?? '—'}
            caption={stats.mostVisitedMerchant ? `${stats.mostVisitedMerchant.count} visits` : undefined}
            icon={StoreRoundedIcon}
          />
        </Grid>
        <Grid item xs={6}>
          <StatCard label="Transactions" value={String(stats.transactionCount)} icon={TagRoundedIcon} />
        </Grid>
      </Grid>

      {insights.length > 0 && (
        <Stack spacing={1.5}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
            Top insights
          </Typography>
          {insights.map((i) => (
            <InsightCard key={i.id} insight={i} />
          ))}
        </Stack>
      )}

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          This month by category
        </Typography>
        <CategoryPieChart data={categoryData} />
      </GlassCard>

      <Box>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Recent transactions
        </Typography>
        <GlassCard sx={{ p: 0 }}>
          {recent.length === 0 ? (
            <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
              No transactions yet — tap + or go to Import to get started.
            </Typography>
          ) : (
            recent.map((t) => <TransactionRow key={t.id} transaction={t} />)
          )}
        </GlassCard>
      </Box>
    </Stack>
  );
}
