import { useRef, useState } from 'react';
import { Button, Divider, Grid, Stack, Typography, Alert } from '@mui/material';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import TableChartRoundedIcon from '@mui/icons-material/TableChartRounded';
import DataObjectRoundedIcon from '@mui/icons-material/DataObjectRounded';
import PictureAsPdfRoundedIcon from '@mui/icons-material/PictureAsPdfRounded';
import { db } from '@/db/db';
import { useMonthTransactions } from '@/hooks/useDexieData';
import SmsImportPanel from '@/components/sms/SmsImportPanel';
import GlassCard from '@/components/common/GlassCard';
import { exportTransactionsCSV, exportTransactionsExcel, exportTransactionsJSON, exportTransactionsPdf } from '@/services/exportService';
import { parseTransactionsCsv, parseTransactionsJson } from '@/services/importService';
import { computeDashboardStats } from '@/services/analyticsService';
import { formatCurrency } from '@/utils/format';
import { insertTransaction } from '@/services/smsImportService';
import { computeTransactionHash } from '@/engine/duplicateDetector';
import { normalizeMerchant } from '@/engine/merchantNormalizer';
import type { Transaction } from '@/types';

export default function ImportExportPage() {
  const monthTransactions = useMonthTransactions(0);
  const [reimportMessage, setReimportMessage] = useState<string | null>(null);
  const csvInputRef = useRef<HTMLInputElement>(null);
  const jsonInputRef = useRef<HTMLInputElement>(null);

  async function handleExport(kind: 'csv' | 'excel' | 'json' | 'pdf') {
    const all = await db.transactions.orderBy('date').reverse().toArray();
    if (kind === 'csv') exportTransactionsCSV(all);
    if (kind === 'excel') exportTransactionsExcel(all);
    if (kind === 'json') exportTransactionsJSON(all);
    if (kind === 'pdf') {
      const stats = computeDashboardStats(monthTransactions ?? [], new Date().toISOString(), new Date().toISOString());
      exportTransactionsPdf(all, [
        { label: 'This month spending', value: formatCurrency(stats.monthSpending) },
        { label: 'Transactions this month', value: String(stats.transactionCount) },
        { label: 'Total transactions on file', value: String(all.length) }
      ]);
    }
  }

  async function reimportRows(rows: Array<Partial<Transaction>>) {
    let count = 0;
    for (const row of rows) {
      if (!row.amount || !row.date) continue;
      const merchant = row.merchant ?? row.normalizedMerchant ?? 'Unknown Merchant';
      const normalizedMerchant = row.normalizedMerchant ?? normalizeMerchant(merchant);
      const core = {
        amount: row.amount,
        currency: row.currency ?? 'INR',
        bank: row.bank ?? 'Unknown Bank',
        type: row.type ?? 'debit',
        merchant,
        normalizedMerchant,
        paymentMethod: row.paymentMethod ?? 'Other',
        date: row.date,
        narration: row.narration ?? '',
        category: row.category ?? 'Others',
        confidence: row.confidence ?? 100,
        reference: row.reference,
        balance: row.balance
      } as Omit<Transaction, 'id' | 'createdAt' | 'hash'>;
      const hash = await computeTransactionHash(core);
      const existing = await db.duplicateHashes.where('hash').equals(hash).first();
      if (existing) continue; // exact duplicate, skip silently
      await insertTransaction({ ...core, hash });
      count += 1;
    }
    setReimportMessage(`Imported ${count} of ${rows.length} rows (duplicates skipped).`);
  }

  return (
    <Stack spacing={3}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>
        Import & export
      </Typography>

      <Stack spacing={1.5}>
        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
          Import SMS
        </Typography>
        <SmsImportPanel />
      </Stack>

      <Divider />

      <Stack spacing={1.5}>
        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
          Re-import previously exported data
        </Typography>
        <input
          ref={csvInputRef}
          type="file"
          accept=".csv"
          hidden
          onChange={async (e) => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (file) await reimportRows(await parseTransactionsCsv(file));
          }}
        />
        <input
          ref={jsonInputRef}
          type="file"
          accept=".json"
          hidden
          onChange={async (e) => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (file) await reimportRows(await parseTransactionsJson(file));
          }}
        />
        <Grid container spacing={1.5}>
          <Grid item xs={6}>
            <Button fullWidth variant="outlined" onClick={() => csvInputRef.current?.click()}>
              Import CSV
            </Button>
          </Grid>
          <Grid item xs={6}>
            <Button fullWidth variant="outlined" onClick={() => jsonInputRef.current?.click()}>
              Import JSON
            </Button>
          </Grid>
        </Grid>
        {reimportMessage && <Alert severity="success">{reimportMessage}</Alert>}
      </Stack>

      <Divider />

      <Stack spacing={1.5}>
        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
          Export your data
        </Typography>
        <GlassCard>
          <Grid container spacing={1.5}>
            <Grid item xs={6}>
              <Button fullWidth variant="outlined" startIcon={<TableChartRoundedIcon />} onClick={() => handleExport('csv')}>
                CSV
              </Button>
            </Grid>
            <Grid item xs={6}>
              <Button fullWidth variant="outlined" startIcon={<DownloadRoundedIcon />} onClick={() => handleExport('excel')}>
                Excel
              </Button>
            </Grid>
            <Grid item xs={6}>
              <Button fullWidth variant="outlined" startIcon={<DataObjectRoundedIcon />} onClick={() => handleExport('json')}>
                JSON
              </Button>
            </Grid>
            <Grid item xs={6}>
              <Button fullWidth variant="outlined" startIcon={<PictureAsPdfRoundedIcon />} onClick={() => handleExport('pdf')}>
                PDF Report
              </Button>
            </Grid>
          </Grid>
        </GlassCard>
      </Stack>
    </Stack>
  );
}
