import { useMemo } from 'react';
import { Stack, Typography } from '@mui/material';
import { useMonthTransactions, useRecentWindowTransactions } from '@/hooks/useDexieData';
import { generateInsights } from '@/services/insightsService';
import { detectRecurring, totalRecurringMonthly } from '@/services/recurringService';
import InsightCard from '@/components/insights/InsightCard';
import GlassCard from '@/components/common/GlassCard';
import { formatCurrency, formatDate } from '@/utils/format';

export default function InsightsPage() {
  const currentMonthTx = useMonthTransactions(0);
  const previousMonthTx = useMonthTransactions(1);
  const recentWindowTx = useRecentWindowTransactions(90);

  const insights = useMemo(() => {
    if (!currentMonthTx || !previousMonthTx || !recentWindowTx) return [];
    return generateInsights({ currentMonth: currentMonthTx, previousMonth: previousMonthTx, recentWindow: recentWindowTx });
  }, [currentMonthTx, previousMonthTx, recentWindowTx]);

  const recurring = useMemo(() => (recentWindowTx ? detectRecurring(recentWindowTx) : []), [recentWindowTx]);
  const recurringTotal = useMemo(() => totalRecurringMonthly(recurring), [recurring]);

  return (
    <Stack spacing={2.5}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>
        Insights
      </Typography>

      {insights.length === 0 ? (
        <Typography color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
          Import a bit more history and insights will start showing up here.
        </Typography>
      ) : (
        <Stack spacing={1.5}>
          {insights.map((i) => (
            <InsightCard key={i.id} insight={i} />
          ))}
        </Stack>
      )}

      <Stack spacing={1.5}>
        <Stack direction="row" justifyContent="space-between" alignItems="baseline">
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
            Recurring payments
          </Typography>
          {recurring.length > 0 && (
            <Typography variant="body2" color="text.secondary">
              ~{formatCurrency(recurringTotal)}/month
            </Typography>
          )}
        </Stack>

        {recurring.length === 0 ? (
          <Typography color="text.secondary" sx={{ textAlign: 'center', py: 2 }}>
            No recurring payments detected yet.
          </Typography>
        ) : (
          recurring.map((r) => (
            <GlassCard key={r.normalizedMerchant} sx={{ py: 1.5 }}>
              <Stack direction="row" justifyContent="space-between" alignItems="center">
                <Stack>
                  <Typography variant="body2" sx={{ fontWeight: 700 }}>
                    {r.normalizedMerchant}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {r.category} · next expected {formatDate(r.nextPredictedDate)}
                  </Typography>
                </Stack>
                <Typography variant="body2" className="tabular-nums" sx={{ fontWeight: 700 }}>
                  {formatCurrency(r.averageAmount)}
                </Typography>
              </Stack>
            </GlassCard>
          ))
        )}
      </Stack>
    </Stack>
  );
}
