import { useNavigate } from 'react-router-dom';
import { List, ListItemButton, ListItemIcon, ListItemText, Stack, Typography } from '@mui/material';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import ImportExportRoundedIcon from '@mui/icons-material/ImportExportRounded';
import SettingsRoundedIcon from '@mui/icons-material/SettingsRounded';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import GlassCard from '@/components/common/GlassCard';

const ITEMS = [
  { path: '/insights', label: 'Insights', description: 'Spending patterns & recurring payments', icon: InsightsRoundedIcon },
  { path: '/import-export', label: 'Import & export', description: 'SMS import, CSV/Excel/JSON/PDF', icon: ImportExportRoundedIcon },
  { path: '/settings', label: 'Settings', description: 'Appearance, PIN lock, categories, data', icon: SettingsRoundedIcon }
];

export default function MorePage() {
  const navigate = useNavigate();

  return (
    <Stack spacing={2}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>
        More
      </Typography>
      <GlassCard sx={{ p: 0 }}>
        <List disablePadding>
          {ITEMS.map((item) => (
            <ListItemButton key={item.path} onClick={() => navigate(item.path)} sx={{ py: 1.5 }}>
              <ListItemIcon>
                <item.icon color="primary" />
              </ListItemIcon>
              <ListItemText primary={item.label} secondary={item.description} />
              <ChevronRightRoundedIcon fontSize="small" color="disabled" />
            </ListItemButton>
          ))}
        </List>
      </GlassCard>
    </Stack>
  );
}
