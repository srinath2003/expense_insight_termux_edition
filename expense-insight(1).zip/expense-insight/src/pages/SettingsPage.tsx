import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  Alert,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemSecondaryAction,
  ListItemText,
  MenuItem,
  Stack,
  Switch,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography
} from '@mui/material';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import { db } from '@/db/db';
import { CATEGORIES, type Category } from '@/types';
import { useUiStore, type ThemeMode } from '@/store/uiStore';
import { hashPin, useSettingsStore } from '@/store/settingsStore';
import { rebuildMerchantStats } from '@/services/merchantService';
import GlassCard from '@/components/common/GlassCard';

export default function SettingsPage() {
  const themeMode = useUiStore((s) => s.themeMode);
  const setThemeMode = useUiStore((s) => s.setThemeMode);
  const pinEnabled = useSettingsStore((s) => s.pinEnabled);
  const updateSettings = useSettingsStore((s) => s.update);
  const categoryRules = useLiveQuery(() => db.categoryRules.toArray(), []) ?? [];
  const transactionCount = useLiveQuery(() => db.transactions.count(), []) ?? 0;

  const [pinDialogOpen, setPinDialogOpen] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [ruleKeyword, setRuleKeyword] = useState('');
  const [ruleCategory, setRuleCategory] = useState<Category>('Others');
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  async function handlePinToggle(enabled: boolean) {
    if (enabled) {
      setPinDialogOpen(true);
    } else {
      await updateSettings({ pinEnabled: false, pinHash: undefined });
    }
  }

  async function handleSetPin() {
    if (pinInput.length < 4) return;
    const pinHash = await hashPin(pinInput);
    await updateSettings({ pinEnabled: true, pinHash });
    setPinDialogOpen(false);
    setPinInput('');
  }

  async function handleAddRule() {
    if (!ruleKeyword.trim()) return;
    await db.categoryRules.add({ keyword: ruleKeyword.trim().toLowerCase(), category: ruleCategory });
    setRuleKeyword('');
  }

  async function handleClearData() {
    await Promise.all([db.transactions.clear(), db.merchants.clear(), db.duplicateHashes.clear(), db.smsLogs.clear()]);
    setClearConfirmOpen(false);
    setStatusMessage('All transaction data has been cleared.');
  }

  async function handleRebuildStats() {
    await rebuildMerchantStats();
    setStatusMessage('Merchant stats rebuilt from your current transactions.');
  }

  return (
    <Stack spacing={3}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>
        Settings
      </Typography>

      {statusMessage && (
        <Alert severity="success" onClose={() => setStatusMessage(null)}>
          {statusMessage}
        </Alert>
      )}

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1.5 }}>
          Appearance
        </Typography>
        <ToggleButtonGroup exclusive fullWidth size="small" value={themeMode} onChange={(_, v: ThemeMode | null) => v && setThemeMode(v)}>
          <ToggleButton value="light">Light</ToggleButton>
          <ToggleButton value="dark">Dark</ToggleButton>
          <ToggleButton value="system">System</ToggleButton>
        </ToggleButtonGroup>
      </GlassCard>

      <GlassCard>
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Stack>
            <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
              PIN lock
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Require a PIN to open the app. Your PIN is hashed and never stored in plain text.
            </Typography>
          </Stack>
          <Switch checked={pinEnabled} onChange={(e) => handlePinToggle(e.target.checked)} />
        </Stack>
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
          Fingerprint/Face unlock isn't wired up in this build — it needs a native wrapper (e.g. Capacitor) to
          reach the device's biometric APIs from a web app. See the README for the extension point.
        </Typography>
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Custom category rules
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
          Add a keyword to always assign a category — checked before the built-in rules.
        </Typography>
        <Stack direction="row" spacing={1} sx={{ mb: 1.5 }}>
          <TextField size="small" placeholder="e.g. my local shop" value={ruleKeyword} onChange={(e) => setRuleKeyword(e.target.value)} fullWidth />
          <TextField select size="small" value={ruleCategory} onChange={(e) => setRuleCategory(e.target.value as Category)} sx={{ minWidth: 130 }}>
            {CATEGORIES.map((c) => (
              <MenuItem key={c} value={c}>
                {c}
              </MenuItem>
            ))}
          </TextField>
          <Button variant="contained" onClick={handleAddRule}>
            Add
          </Button>
        </Stack>
        {categoryRules.length > 0 && (
          <List dense disablePadding>
            {categoryRules.map((rule) => (
              <ListItem key={rule.id} disableGutters>
                <ListItemText primary={rule.keyword} secondary={rule.category} />
                <ListItemSecondaryAction>
                  <IconButton size="small" onClick={() => rule.id && db.categoryRules.delete(rule.id)}>
                    <DeleteOutlineRoundedIcon fontSize="small" />
                  </IconButton>
                </ListItemSecondaryAction>
              </ListItem>
            ))}
          </List>
        )}
      </GlassCard>

      <GlassCard>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
          Data
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
          {transactionCount} transactions stored on this device. Nothing is ever sent to a server.
        </Typography>
        <Stack spacing={1}>
          <Button variant="outlined" onClick={handleRebuildStats}>
            Rebuild merchant stats
          </Button>
          <Button variant="outlined" color="error" onClick={() => setClearConfirmOpen(true)}>
            Clear all data
          </Button>
        </Stack>
      </GlassCard>

      <Divider />
      <Typography variant="caption" color="text.secondary">
        Expense Insight v0.1.0 — everything runs on-device using IndexedDB. See the README for architecture notes
        and the current feature roadmap.
      </Typography>

      <Dialog open={pinDialogOpen} onClose={() => setPinDialogOpen(false)}>
        <DialogTitle>Set a PIN</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            type="password"
            inputMode="numeric"
            label="4-8 digit PIN"
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 8))}
            fullWidth
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setPinDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSetPin} disabled={pinInput.length < 4}>
            Save
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={clearConfirmOpen} onClose={() => setClearConfirmOpen(false)}>
        <DialogTitle>Clear all data?</DialogTitle>
        <DialogContent>
          <Typography variant="body2">
            This permanently deletes every transaction, merchant stat, and SMS log on this device. Budgets and
            settings are kept. This can't be undone — export a backup first if you want to keep a copy.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setClearConfirmOpen(false)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleClearData}>
            Clear data
          </Button>
        </DialogActions>
      </Dialog>
    </Stack>
  );
}
