import { useState } from 'react';
import { InputAdornment, Stack, TextField, Typography } from '@mui/material';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import type { Transaction } from '@/types';
import { useFilteredTransactions } from '@/hooks/useDexieData';
import { useFilterStore } from '@/store/filterStore';
import TransactionFilters from '@/components/transactions/TransactionFilters';
import TransactionList from '@/components/transactions/TransactionList';
import TransactionForm from '@/components/transactions/TransactionForm';
import { formatCurrency } from '@/utils/format';

export default function TransactionsPage() {
  const transactions = useFilteredTransactions();
  const search = useFilterStore((s) => s.search);
  const setSearch = useFilterStore((s) => s.setSearch);
  const [editing, setEditing] = useState<Transaction | null>(null);

  const total = (transactions ?? []).filter((t) => t.type === 'debit').reduce((s, t) => s + t.amount, 0);

  return (
    <Stack spacing={2}>
      <Typography variant="h5" sx={{ fontWeight: 700 }}>
        Transactions
      </Typography>

      <TextField
        placeholder="Search merchant, amount, bank..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        size="small"
        fullWidth
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchRoundedIcon fontSize="small" />
            </InputAdornment>
          )
        }}
      />

      <TransactionFilters />

      <Typography variant="body2" color="text.secondary">
        {(transactions ?? []).length} transactions · {formatCurrency(total)} spent
      </Typography>

      <TransactionList transactions={transactions ?? []} onSelect={setEditing} />

      <TransactionForm open={!!editing} onClose={() => setEditing(null)} existing={editing ?? undefined} />
    </Stack>
  );
}
