import { lazy } from 'react';
import { createBrowserRouter } from 'react-router-dom';
import AppShell from '@/components/layout/AppShell';

const DashboardPage = lazy(() => import('@/pages/DashboardPage'));
const TransactionsPage = lazy(() => import('@/pages/TransactionsPage'));
const AnalyticsPage = lazy(() => import('@/pages/AnalyticsPage'));
const BudgetsPage = lazy(() => import('@/pages/BudgetsPage'));
const InsightsPage = lazy(() => import('@/pages/InsightsPage'));
const ImportExportPage = lazy(() => import('@/pages/ImportExportPage'));
const SettingsPage = lazy(() => import('@/pages/SettingsPage'));
const MorePage = lazy(() => import('@/pages/MorePage'));

export const router = createBrowserRouter([
  {
    path: '/',
    element: <AppShell />,
    children: [
      { index: true, element: <DashboardPage /> },
      { path: 'transactions', element: <TransactionsPage /> },
      { path: 'analytics', element: <AnalyticsPage /> },
      { path: 'budgets', element: <BudgetsPage /> },
      { path: 'insights', element: <InsightsPage /> },
      { path: 'import-export', element: <ImportExportPage /> },
      { path: 'settings', element: <SettingsPage /> },
      { path: 'more', element: <MorePage /> }
    ]
  }
]);
