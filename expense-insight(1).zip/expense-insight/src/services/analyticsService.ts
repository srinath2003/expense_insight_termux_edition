import { differenceInCalendarDays, eachDayOfInterval, format, getDaysInMonth, startOfMonth } from 'date-fns';
import type { Transaction } from '@/types';

const isDebit = (t: Transaction) => t.type === 'debit';

export interface DashboardStats {
  todaySpending: number;
  weekSpending: number;
  monthSpending: number;
  averageDailySpending: number;
  largestTransaction: Transaction | null;
  mostVisitedMerchant: { name: string; count: number } | null;
  transactionCount: number;
}

export function computeDashboardStats(
  monthTransactions: Transaction[],
  todayIso: string,
  weekStartIso: string
): DashboardStats {
  const todayKey = todayIso.slice(0, 10);
  const debits = monthTransactions.filter(isDebit);

  const todaySpending = debits.filter((t) => t.date.slice(0, 10) === todayKey).reduce((s, t) => s + t.amount, 0);
  const weekSpending = debits.filter((t) => t.date >= weekStartIso).reduce((s, t) => s + t.amount, 0);
  const monthSpending = debits.reduce((s, t) => s + t.amount, 0);

  const dayOfMonth = Math.max(1, differenceInCalendarDays(new Date(todayIso), startOfMonth(new Date(todayIso))) + 1);
  const averageDailySpending = monthSpending / dayOfMonth;

  const largestTransaction = debits.reduce<Transaction | null>(
    (max, t) => (!max || t.amount > max.amount ? t : max),
    null
  );

  const visitCounts = new Map<string, number>();
  for (const t of monthTransactions) {
    visitCounts.set(t.normalizedMerchant, (visitCounts.get(t.normalizedMerchant) ?? 0) + 1);
  }
  let mostVisitedMerchant: { name: string; count: number } | null = null;
  for (const [name, count] of visitCounts) {
    if (!mostVisitedMerchant || count > mostVisitedMerchant.count) mostVisitedMerchant = { name, count };
  }

  return {
    todaySpending,
    weekSpending,
    monthSpending,
    averageDailySpending,
    largestTransaction,
    mostVisitedMerchant,
    transactionCount: monthTransactions.length
  };
}

export function groupByCategory(transactions: Transaction[]): Array<{ name: string; value: number }> {
  const totals = new Map<string, number>();
  for (const t of transactions.filter(isDebit)) {
    totals.set(t.category, (totals.get(t.category) ?? 0) + t.amount);
  }
  return Array.from(totals.entries())
    .map(([name, value]) => ({ name, value: Math.round(value) }))
    .sort((a, b) => b.value - a.value);
}

export function dailySeries(
  transactions: Transaction[],
  days: number,
  endIso: string
): Array<{ date: string; amount: number }> {
  const end = new Date(endIso);
  const start = new Date(end);
  start.setDate(start.getDate() - (days - 1));
  const totals = new Map<string, number>();
  for (const t of transactions.filter(isDebit)) {
    const key = t.date.slice(0, 10);
    totals.set(key, (totals.get(key) ?? 0) + t.amount);
  }
  return eachDayOfInterval({ start, end }).map((d) => {
    const key = format(d, 'yyyy-MM-dd');
    return { date: format(d, 'd MMM'), amount: Math.round(totals.get(key) ?? 0) };
  });
}

export function monthlySeries(
  transactions: Transaction[],
  months: number,
  endIso: string
): Array<{ month: string; amount: number }> {
  const end = new Date(endIso);
  const buckets: { key: string; label: string }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(end.getFullYear(), end.getMonth() - i, 1);
    buckets.push({ key: format(d, 'yyyy-MM'), label: format(d, 'MMM yy') });
  }
  const totals = new Map<string, number>();
  for (const t of transactions.filter(isDebit)) {
    const key = t.date.slice(0, 7);
    totals.set(key, (totals.get(key) ?? 0) + t.amount);
  }
  return buckets.map((b) => ({ month: b.label, amount: Math.round(totals.get(b.key) ?? 0) }));
}

export function topMerchants(transactions: Transaction[], limit = 8): Array<{ name: string; amount: number }> {
  const totals = new Map<string, number>();
  for (const t of transactions.filter(isDebit)) {
    totals.set(t.normalizedMerchant, (totals.get(t.normalizedMerchant) ?? 0) + t.amount);
  }
  return Array.from(totals.entries())
    .map(([name, amount]) => ({ name, amount: Math.round(amount) }))
    .sort((a, b) => b.amount - a.amount)
    .slice(0, limit);
}

export function cashflowSeries(
  transactions: Transaction[],
  days: number,
  endIso: string
): Array<{ date: string; debit: number; credit: number }> {
  const end = new Date(endIso);
  const start = new Date(end);
  start.setDate(start.getDate() - (days - 1));
  const debitTotals = new Map<string, number>();
  const creditTotals = new Map<string, number>();
  for (const t of transactions) {
    const key = t.date.slice(0, 10);
    if (t.type === 'debit') debitTotals.set(key, (debitTotals.get(key) ?? 0) + t.amount);
    else creditTotals.set(key, (creditTotals.get(key) ?? 0) + t.amount);
  }
  return eachDayOfInterval({ start, end }).map((d) => {
    const key = format(d, 'yyyy-MM-dd');
    return {
      date: format(d, 'd MMM'),
      debit: Math.round(debitTotals.get(key) ?? 0),
      credit: Math.round(creditTotals.get(key) ?? 0)
    };
  });
}

export interface HeatmapDay {
  date: string;
  amount: number;
}

export function heatmapSeries(transactions: Transaction[], days: number, endIso: string): HeatmapDay[] {
  const end = new Date(endIso);
  const start = new Date(end);
  start.setDate(start.getDate() - (days - 1));
  const totals = new Map<string, number>();
  for (const t of transactions.filter(isDebit)) {
    const key = t.date.slice(0, 10);
    totals.set(key, (totals.get(key) ?? 0) + t.amount);
  }
  return eachDayOfInterval({ start, end }).map((d) => {
    const key = format(d, 'yyyy-MM-dd');
    return { date: key, amount: Math.round(totals.get(key) ?? 0) };
  });
}

export function daysElapsedInMonth(todayIso: string): { elapsed: number; total: number } {
  const today = new Date(todayIso);
  return { elapsed: today.getDate(), total: getDaysInMonth(today) };
}
