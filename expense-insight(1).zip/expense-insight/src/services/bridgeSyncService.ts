import type { RawSms } from '@/types';

/**
 * Talks to the local Termux bridge server (see /termux in the project root)
 * over 127.0.0.1 only — this never touches the internet. The bridge exists
 * because a browser/PWA can never read the device's SMS inbox directly; the
 * bridge is a small script running outside the browser sandbox that can.
 */

const DEFAULT_PORT = 8787;
const STORAGE_KEY = 'expense-insight:bridge-port';

export function getBridgePort(): number {
  const stored = typeof window !== 'undefined' ? window.localStorage.getItem(STORAGE_KEY) : null;
  const parsed = stored ? parseInt(stored, 10) : NaN;
  return Number.isFinite(parsed) && parsed > 0 ? parsed : DEFAULT_PORT;
}

export function setBridgePort(port: number): void {
  if (typeof window !== 'undefined') window.localStorage.setItem(STORAGE_KEY, String(port));
}

function bridgeUrl(path: string, port: number): string {
  return `http://127.0.0.1:${port}${path}`;
}

export interface BridgeFetchResult {
  ok: boolean;
  messages: RawSms[];
  error?: string;
}

/** Fetches whatever new messages the Termux bridge has collected. Does not clear them yet. */
export async function fetchBridgeMessages(port: number = getBridgePort()): Promise<BridgeFetchResult> {
  try {
    const res = await fetch(bridgeUrl('/messages', port), { signal: AbortSignal.timeout(4000) });
    if (!res.ok) {
      return { ok: false, messages: [], error: `Bridge server responded with ${res.status}.` };
    }
    const raw = (await res.json()) as Array<{ sender: string; body: string; date: string }>;
    return { ok: true, messages: raw.map((m) => ({ sender: m.sender, body: m.body, date: m.date })) };
  } catch (err) {
    return {
      ok: false,
      messages: [],
      error:
        err instanceof Error && err.name === 'TimeoutError'
          ? 'No response from the bridge server. Is sms-bridge.sh / bridge-server.js running on this phone?'
          : "Couldn't reach the bridge server on this device. Make sure it's running and the port matches."
    };
  }
}

/** Tells the bridge it can clear its buffer — call this only after a successful import. */
export async function acknowledgeBridgeMessages(port: number = getBridgePort()): Promise<void> {
  try {
    await fetch(bridgeUrl('/ack', port), { method: 'POST', signal: AbortSignal.timeout(4000) });
  } catch {
    // Non-fatal: worst case the same messages get fetched again next sync,
    // and the app's own duplicate detection will simply skip them.
  }
}
