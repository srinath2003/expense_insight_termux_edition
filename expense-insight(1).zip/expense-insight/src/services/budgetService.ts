import { db } from '@/db/db';
import type { Budget, BudgetStatus, Category, Transaction } from '@/types';
import { daysElapsedInMonth } from './analyticsService';

export async function listBudgetsForMonth(month: string): Promise<Budget[]> {
  return db.budgets.where('month').equals(month).toArray();
}

export async function upsertBudget(budget: Budget): Promise<number> {
  const existing = await db.budgets.where('[category+month]').equals([budget.category, budget.month]).first();
  if (existing) {
    await db.budgets.update(existing.id!, { monthlyLimit: budget.monthlyLimit });
    return existing.id!;
  }
  return db.budgets.add(budget);
}

export async function deleteBudget(id: number): Promise<void> {
  await db.budgets.delete(id);
}

export function calculateBudgetStatus(budget: Budget, monthTransactions: Transaction[], todayIso: string): BudgetStatus {
  const relevant =
    budget.category === 'Overall' ? monthTransactions : monthTransactions.filter((t) => t.category === budget.category);

  const spent = relevant.filter((t) => t.type === 'debit').reduce((s, t) => s + t.amount, 0);
  const remaining = budget.monthlyLimit - spent;
  const { elapsed, total } = daysElapsedInMonth(todayIso);
  const predictedMonthEnd = elapsed > 0 ? (spent / elapsed) * total : spent;
  const percentUsed = budget.monthlyLimit > 0 ? (spent / budget.monthlyLimit) * 100 : 0;

  return {
    budget,
    spent,
    remaining,
    predictedMonthEnd,
    percentUsed: Math.min(percentUsed, 999),
    isOverBudget: spent > budget.monthlyLimit,
    isPredictedOverBudget: predictedMonthEnd > budget.monthlyLimit
  };
}

export function suggestedCategories(existingBudgets: Budget[]): Category[] {
  const used = new Set(existingBudgets.map((b) => b.category));
  const all: Array<Category | 'Overall'> = [
    'Overall',
    'Food',
    'Groceries',
    'Shopping',
    'Travel',
    'Bills',
    'Entertainment'
  ] as Array<Category | 'Overall'>;
  return all.filter((c) => !used.has(c)) as Category[];
}
