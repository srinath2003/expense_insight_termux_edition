import Papa from 'papaparse';
import type { Transaction } from '@/types';
import { formatCurrency, formatDate } from '@/utils/format';

// xlsx and jspdf are both large libraries. They're dynamically imported
// inside the functions that need them, so they only ever get downloaded (and
// only ever count toward Import & Export's initial chunk) if someone
// actually taps "Excel" or "PDF Report" — not on every visit to the page.

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function flattenForExport(transactions: Transaction[]) {
  return transactions.map((t) => ({
    Date: t.date,
    Amount: t.amount,
    Type: t.type,
    Category: t.category,
    Merchant: t.normalizedMerchant,
    RawMerchant: t.merchant,
    Bank: t.bank,
    PaymentMethod: t.paymentMethod,
    Reference: t.reference ?? '',
    Balance: t.balance ?? '',
    Narration: t.narration,
    Confidence: t.confidence
  }));
}

export function exportTransactionsCSV(transactions: Transaction[]): void {
  const csv = Papa.unparse(flattenForExport(transactions));
  downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8;' }), `expense-insight-export-${Date.now()}.csv`);
}

export function exportTransactionsJSON(transactions: Transaction[]): void {
  const json = JSON.stringify(transactions, null, 2);
  downloadBlob(new Blob([json], { type: 'application/json' }), `expense-insight-export-${Date.now()}.json`);
}

export async function exportTransactionsExcel(transactions: Transaction[]): Promise<void> {
  const XLSX = await import('xlsx');
  const sheet = XLSX.utils.json_to_sheet(flattenForExport(transactions));
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, 'Transactions');
  XLSX.writeFile(workbook, `expense-insight-export-${Date.now()}.xlsx`);
}

export async function exportTransactionsPdf(
  transactions: Transaction[],
  summary: { label: string; value: string }[]
): Promise<void> {
  const [{ jsPDF }, { default: autoTable }] = await Promise.all([import('jspdf'), import('jspdf-autotable')]);

  const doc = new jsPDF();

  doc.setFontSize(18);
  doc.text('Expense Insight — Report', 14, 18);
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`Generated ${formatDate(new Date().toISOString(), 'd MMM yyyy, h:mm a')}`, 14, 25);

  autoTable(doc, {
    startY: 32,
    head: [['Summary', 'Value']],
    body: summary.map((s) => [s.label, s.value]),
    theme: 'grid',
    headStyles: { fillColor: [30, 32, 44] }
  });

  const afterSummaryY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;

  autoTable(doc, {
    startY: afterSummaryY,
    head: [['Date', 'Merchant', 'Category', 'Type', 'Amount']],
    body: transactions
      .slice(0, 500)
      .map((t) => [formatDate(t.date), t.normalizedMerchant, t.category, t.type, formatCurrency(t.amount)]),
    theme: 'striped',
    headStyles: { fillColor: [30, 32, 44] },
    styles: { fontSize: 8 }
  });

  doc.save(`expense-insight-report-${Date.now()}.pdf`);
}
