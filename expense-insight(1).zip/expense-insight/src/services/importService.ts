import Papa from 'papaparse';
import type { RawSms, Transaction } from '@/types';

/** Parses a previously-exported transactions CSV (see exportService) back into Transaction-shaped rows. */
export async function parseTransactionsCsv(file: File): Promise<Array<Partial<Transaction>>> {
  const text = await file.text();
  const { data } = Papa.parse<Record<string, string>>(text, { header: true, skipEmptyLines: true });
  return data.map((row) => ({
    date: row.Date,
    amount: parseFloat(row.Amount),
    type: (row.Type as Transaction['type']) || 'debit',
    category: (row.Category as Transaction['category']) || 'Others',
    merchant: row.RawMerchant || row.Merchant,
    normalizedMerchant: row.Merchant,
    bank: row.Bank || 'Unknown Bank',
    paymentMethod: (row.PaymentMethod as Transaction['paymentMethod']) || 'Other',
    reference: row.Reference || undefined,
    balance: row.Balance ? parseFloat(row.Balance) : undefined,
    narration: row.Narration || '',
    confidence: row.Confidence ? parseFloat(row.Confidence) : 100,
    currency: 'INR'
  }));
}

/** Parses a previously-exported transactions JSON file. */
export async function parseTransactionsJson(file: File): Promise<Array<Partial<Transaction>>> {
  const text = await file.text();
  const parsed = JSON.parse(text);
  if (!Array.isArray(parsed)) throw new Error('Expected a JSON array of transactions.');
  return parsed;
}

/**
 * Parses the widely-used Android "SMS Backup & Restore" XML export format:
 *   <smses> <sms address="HDFC-BK" body="..." date="1719302400000" /> ... </smses>
 * date is epoch milliseconds in that format.
 */
export async function parseSmsBackupXml(file: File): Promise<RawSms[]> {
  const text = await file.text();
  const doc = new DOMParser().parseFromString(text, 'text/xml');

  const parserError = doc.querySelector('parsererror');
  if (parserError) throw new Error('This file does not look like a valid SMS backup XML export.');

  const nodes = Array.from(doc.querySelectorAll('sms'));
  return nodes.map((node) => {
    const address = node.getAttribute('address') ?? 'Unknown';
    const body = node.getAttribute('body') ?? '';
    const dateAttr = node.getAttribute('date');
    const epochMs = dateAttr ? parseInt(dateAttr, 10) : Date.now();
    const iso = Number.isFinite(epochMs) ? new Date(epochMs).toISOString() : new Date().toISOString();
    return { sender: address, body, date: iso };
  });
}

/** Splits pasted, free-form SMS text (one message per line, or blank-line separated) into RawSms entries. */
export function parsePastedSms(text: string, defaultSender = 'Pasted'): RawSms[] {
  const now = new Date().toISOString();
  return text
    .split(/\n{2,}|\n(?=[A-Z][a-zA-Z0-9 ]{1,15}:)/) // blank-line separated, or "Bank:" prefixed lines
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .map((chunk) => {
      const match = chunk.match(/^([A-Za-z0-9 ]{2,15}):\s*([\s\S]+)$/);
      if (match) return { sender: match[1].trim(), body: match[2].trim(), date: now };
      return { sender: defaultSender, body: chunk, date: now };
    });
}
