import type { Insight, Transaction } from '@/types';
import { formatCurrency } from '@/utils/format';

const isDebit = (t: Transaction) => t.type === 'debit';
const WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function sumByCategory(transactions: Transaction[]): Map<string, number> {
  const totals = new Map<string, number>();
  for (const t of transactions.filter(isDebit)) {
    totals.set(t.category, (totals.get(t.category) ?? 0) + t.amount);
  }
  return totals;
}

function sumByMerchant(transactions: Transaction[]): Map<string, number> {
  const totals = new Map<string, number>();
  for (const t of transactions.filter(isDebit)) {
    totals.set(t.normalizedMerchant, (totals.get(t.normalizedMerchant) ?? 0) + t.amount);
  }
  return totals;
}

/** "You spent 32% more on Food this month." (or less, whichever the data shows) */
function categoryMoMInsight(current: Transaction[], previous: Transaction[]): Insight | null {
  const currentTotals = sumByCategory(current);
  const previousTotals = sumByCategory(previous);
  let best: { category: string; pct: number; direction: 'more' | 'less' } | null = null;

  for (const [category, currentAmount] of currentTotals) {
    const previousAmount = previousTotals.get(category) ?? 0;
    if (previousAmount < 200) continue; // avoid noisy insights from a near-zero baseline
    const pct = ((currentAmount - previousAmount) / previousAmount) * 100;
    if (Math.abs(pct) < 15) continue;
    const direction = pct > 0 ? 'more' : 'less';
    if (!best || Math.abs(pct) > Math.abs(best.pct)) best = { category, pct, direction };
  }

  if (!best) return null;
  return {
    id: 'category-mom',
    type: 'category-mom',
    title: `${best.category} spending ${best.direction === 'more' ? 'up' : 'down'}`,
    description: `You spent ${Math.abs(Math.round(best.pct))}% ${best.direction} on ${best.category} this month.`,
    severity: best.direction === 'more' ? 'warning' : 'positive'
  };
}

/** "You visited Swiggy 18 times." */
function merchantVisitInsight(current: Transaction[]): Insight | null {
  const counts = new Map<string, number>();
  for (const t of current) counts.set(t.normalizedMerchant, (counts.get(t.normalizedMerchant) ?? 0) + 1);
  let top: { name: string; count: number } | null = null;
  for (const [name, count] of counts) {
    if (count < 3) continue;
    if (!top || count > top.count) top = { name, count };
  }
  if (!top) return null;
  return {
    id: 'merchant-visits',
    type: 'merchant-visits',
    title: 'Frequent merchant',
    description: `You visited ${top.name} ${top.count} times this month.`,
    severity: 'info'
  };
}

/** "Highest expense occurred on Friday." */
function highestExpenseDayInsight(current: Transaction[]): Insight | null {
  if (current.length < 5) return null;
  const totals = new Array(7).fill(0);
  for (const t of current.filter(isDebit)) {
    const day = new Date(t.date).getDay();
    totals[day] += t.amount;
  }
  const maxIndex = totals.indexOf(Math.max(...totals));
  if (totals[maxIndex] <= 0) return null;
  return {
    id: 'highest-expense-day',
    type: 'highest-expense-day',
    title: 'Spending pattern',
    description: `Highest expense this month occurred on ${WEEKDAY_NAMES[maxIndex]}.`,
    severity: 'info'
  };
}

/** "You usually spend most after 7 PM." — reports whichever time-of-day bracket actually dominates. */
function spendingTimePatternInsight(recentWindow: Transaction[]): Insight | null {
  const debitTx = recentWindow.filter(isDebit);
  if (debitTx.length < 8) return null;

  const brackets = [
    { label: 'before 10 AM', test: (h: number) => h < 10 },
    { label: 'between 10 AM and 7 PM', test: (h: number) => h >= 10 && h < 19 },
    { label: 'after 7 PM', test: (h: number) => h >= 19 }
  ];
  const totals = brackets.map(() => 0);
  for (const t of debitTx) {
    const hour = new Date(t.date).getHours();
    const idx = brackets.findIndex((b) => b.test(hour));
    if (idx >= 0) totals[idx] += t.amount;
  }
  const grand = totals.reduce((a, b) => a + b, 0);
  if (grand <= 0) return null;
  const maxIndex = totals.indexOf(Math.max(...totals));
  const share = totals[maxIndex] / grand;
  if (share < 0.4) return null; // no clear pattern

  return {
    id: 'spending-time-pattern',
    type: 'spending-time-pattern',
    title: 'Time-of-day pattern',
    description: `You usually spend most ${brackets[maxIndex].label}.`,
    severity: 'info'
  };
}

/** "Amazon purchases increased by 42%." */
function merchantTrendInsight(current: Transaction[], previous: Transaction[]): Insight | null {
  const currentTotals = sumByMerchant(current);
  const previousTotals = sumByMerchant(previous);
  let best: { merchant: string; pct: number } | null = null;

  for (const [merchant, currentAmount] of currentTotals) {
    const previousAmount = previousTotals.get(merchant) ?? 0;
    if (previousAmount < 200) continue;
    const pct = ((currentAmount - previousAmount) / previousAmount) * 100;
    if (pct < 25) continue; // only call out clear increases here
    if (!best || pct > best.pct) best = { merchant, pct };
  }

  if (!best) return null;
  return {
    id: 'merchant-trend',
    type: 'merchant-trend',
    title: `${best.merchant} trending up`,
    description: `${best.merchant} purchases increased by ${Math.round(best.pct)}% compared to last month.`,
    severity: 'warning'
  };
}

/** "You saved ₹2,300 compared to last month." (or the honest opposite, if spend went up) */
function monthOverMonthTotalInsight(current: Transaction[], previous: Transaction[]): Insight | null {
  if (previous.length === 0) return null;
  const currentTotal = current.filter(isDebit).reduce((s, t) => s + t.amount, 0);
  const previousTotal = previous.filter(isDebit).reduce((s, t) => s + t.amount, 0);
  const diff = previousTotal - currentTotal;
  if (Math.abs(diff) < 100) return null;

  if (diff > 0) {
    return {
      id: 'mom-total',
      type: 'mom-total',
      title: 'Spending down',
      description: `You saved ${formatCurrency(diff)} compared to last month.`,
      severity: 'positive'
    };
  }
  return {
    id: 'mom-total',
    type: 'mom-total',
    title: 'Spending up',
    description: `You've spent ${formatCurrency(Math.abs(diff))} more than last month so far.`,
    severity: 'warning'
  };
}

/** "Your subscriptions total ₹899/month." */
function subscriptionsInsight(current: Transaction[]): Insight | null {
  const subs = current.filter((t) => t.category === 'Subscription' && isDebit(t));
  if (subs.length === 0) return null;
  const total = subs.reduce((s, t) => s + t.amount, 0);
  return {
    id: 'subscriptions-total',
    type: 'subscriptions-total',
    title: 'Subscriptions',
    description: `Your subscriptions total ${formatCurrency(total)}/month.`,
    severity: 'info'
  };
}

export interface InsightInputs {
  currentMonth: Transaction[];
  previousMonth: Transaction[];
  /** A wider recent window (e.g. last 60-90 days) for patterns that need more samples. */
  recentWindow: Transaction[];
}

export function generateInsights({ currentMonth, previousMonth, recentWindow }: InsightInputs): Insight[] {
  const candidates = [
    categoryMoMInsight(currentMonth, previousMonth),
    merchantVisitInsight(currentMonth),
    highestExpenseDayInsight(currentMonth),
    spendingTimePatternInsight(recentWindow),
    merchantTrendInsight(currentMonth, previousMonth),
    monthOverMonthTotalInsight(currentMonth, previousMonth),
    subscriptionsInsight(currentMonth)
  ];
  return candidates.filter((i): i is Insight => i !== null);
}
