import { db } from '@/db/db';
import type { Category, Transaction } from '@/types';

/** Updates (or creates) the Merchants row for a transaction's normalized merchant. */
export async function upsertMerchantStats(
  t: Pick<Transaction, 'normalizedMerchant' | 'merchant' | 'amount' | 'type' | 'date' | 'category'>
): Promise<void> {
  const existing = await db.merchants.where('normalizedName').equals(t.normalizedMerchant).first();

  if (existing) {
    await db.merchants.update(existing.id!, {
      visitCount: existing.visitCount + 1,
      totalSpent: existing.totalSpent + (t.type === 'debit' ? t.amount : 0),
      lastVisit: t.date > existing.lastVisit ? t.date : existing.lastVisit
    });
    return;
  }

  await db.merchants.add({
    rawName: t.merchant,
    normalizedName: t.normalizedMerchant,
    category: t.category,
    visitCount: 1,
    totalSpent: t.type === 'debit' ? t.amount : 0,
    lastVisit: t.date
  });
}

/** Recomputes every merchant's stats from scratch — used after bulk edits/imports/deletes. */
export async function rebuildMerchantStats(): Promise<void> {
  const transactions = await db.transactions.toArray();
  await db.merchants.clear();

  const byMerchant = new Map<
    string,
    { rawName: string; visitCount: number; totalSpent: number; lastVisit: string; category?: Category }
  >();
  for (const t of transactions) {
    const entry = byMerchant.get(t.normalizedMerchant);
    if (entry) {
      entry.visitCount += 1;
      entry.totalSpent += t.type === 'debit' ? t.amount : 0;
      if (t.date > entry.lastVisit) entry.lastVisit = t.date;
    } else {
      byMerchant.set(t.normalizedMerchant, {
        rawName: t.merchant,
        visitCount: 1,
        totalSpent: t.type === 'debit' ? t.amount : 0,
        lastVisit: t.date,
        category: t.category
      });
    }
  }

  await db.merchants.bulkAdd(
    Array.from(byMerchant.entries()).map(([normalizedName, v]) => ({ normalizedName, ...v }))
  );
}
