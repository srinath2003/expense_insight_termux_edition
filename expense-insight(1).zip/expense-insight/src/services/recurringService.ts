import { addDays, differenceInDays } from 'date-fns';
import type { Category, RecurringGroup, Transaction } from '@/types';

const KNOWN_SUBSCRIPTIONS = [
  'netflix',
  'spotify',
  'amazon prime',
  'disney+ hotstar',
  'jiocinema',
  'youtube premium',
  'apple music',
  'sonyliv',
  'zee5'
];

const KNOWN_RECURRING_HINTS = [
  ...KNOWN_SUBSCRIPTIONS,
  'electricity',
  'broadband',
  'act fibernet',
  'insurance',
  'rent',
  'mobile recharge',
  'airtel',
  'jio',
  'vi'
];

/**
 * Groups transactions by merchant and flags ones that repeat roughly monthly
 * (25-35 day interval, at least twice) or that match a known
 * subscription/utility merchant even on a single occurrence so far.
 */
export function detectRecurring(transactions: Transaction[]): RecurringGroup[] {
  const debitTx = transactions.filter((t) => t.type === 'debit');
  const byMerchant = new Map<string, Transaction[]>();
  for (const t of debitTx) {
    const list = byMerchant.get(t.normalizedMerchant) ?? [];
    list.push(t);
    byMerchant.set(t.normalizedMerchant, list);
  }

  const groups: RecurringGroup[] = [];

  for (const [merchant, list] of byMerchant) {
    const sorted = [...list].sort((a, b) => (a.date < b.date ? -1 : 1));
    const nameLower = merchant.toLowerCase();
    const isKnownRecurring = KNOWN_RECURRING_HINTS.some((hint) => nameLower.includes(hint));

    if (sorted.length >= 2) {
      const intervals: number[] = [];
      for (let i = 1; i < sorted.length; i++) {
        intervals.push(differenceInDays(new Date(sorted[i].date), new Date(sorted[i - 1].date)));
      }
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const looksMonthly = avgInterval >= 25 && avgInterval <= 35;

      if (looksMonthly || isKnownRecurring) {
        const avgAmount = sorted.reduce((s, t) => s + t.amount, 0) / sorted.length;
        const last = sorted[sorted.length - 1];
        groups.push({
          normalizedMerchant: merchant,
          category: last.category,
          averageAmount: Math.round(avgAmount),
          intervalDays: Math.round(looksMonthly ? avgInterval : 30),
          occurrences: sorted.length,
          lastDate: last.date,
          nextPredictedDate: addDays(new Date(last.date), looksMonthly ? Math.round(avgInterval) : 30).toISOString(),
          transactionIds: sorted.map((t) => t.id!).filter(Boolean)
        });
      }
    } else if (sorted.length === 1 && isKnownRecurring) {
      const only = sorted[0];
      groups.push({
        normalizedMerchant: merchant,
        category: only.category,
        averageAmount: Math.round(only.amount),
        intervalDays: 30,
        occurrences: 1,
        lastDate: only.date,
        nextPredictedDate: addDays(new Date(only.date), 30).toISOString(),
        transactionIds: only.id ? [only.id] : []
      });
    }
  }

  return groups.sort((a, b) => b.averageAmount - a.averageAmount);
}

export function totalRecurringMonthly(groups: RecurringGroup[]): number {
  return groups.reduce((s, g) => s + g.averageAmount, 0);
}

export function isSubscriptionMerchant(normalizedMerchant: string, category?: Category): boolean {
  if (category === 'Subscription') return true;
  return KNOWN_SUBSCRIPTIONS.some((s) => normalizedMerchant.toLowerCase().includes(s));
}
