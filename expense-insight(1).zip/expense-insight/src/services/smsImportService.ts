import { db } from '@/db/db';
import type { RawSms, Transaction } from '@/types';
import { parseSms } from '@/engine/smsParser';
import { checkDuplicate, registerHash } from '@/engine/duplicateDetector';
import { upsertMerchantStats } from './merchantService';

export interface ReviewItem {
  smsLogId: number;
  raw: RawSms;
  candidate: Omit<Transaction, 'id' | 'createdAt'>;
  score: number;
  matchedTransaction?: Transaction;
}

export interface ImportSummary {
  total: number;
  inserted: number;
  autoSkippedDuplicates: number;
  failed: number;
  needsReview: ReviewItem[];
}

/** Inserts a fully-decided transaction (used both for clean imports and resolved review items). */
export async function insertTransaction(candidate: Omit<Transaction, 'id' | 'createdAt'>): Promise<number> {
  const id = await db.transactions.add({ ...candidate, createdAt: new Date().toISOString() } as Transaction);
  await registerHash(candidate.hash, id);
  await upsertMerchantStats(candidate);
  return id;
}

/**
 * Runs the full pipeline over a batch of raw SMS: parse -> de-duplicate ->
 * insert (or queue for review). Every message gets an SmsLogs row so the
 * import history is auditable even for skips and failures.
 */
export async function importSmsBatch(messages: RawSms[]): Promise<ImportSummary> {
  const summary: ImportSummary = {
    total: messages.length,
    inserted: 0,
    autoSkippedDuplicates: 0,
    failed: 0,
    needsReview: []
  };

  for (const raw of messages) {
    const result = await parseSms(raw);

    if (!result.success || !result.transaction) {
      await db.smsLogs.add({
        sender: raw.sender,
        body: raw.body,
        date: raw.date,
        processed: true,
        error: result.error ?? 'Could not parse this message.'
      });
      summary.failed += 1;
      continue;
    }

    const candidate = result.transaction;
    const dup = await checkDuplicate(candidate as Transaction & { hash: string });

    if (dup.isDuplicate) {
      await db.smsLogs.add({
        sender: raw.sender,
        body: raw.body,
        date: raw.date,
        processed: true,
        transactionId: dup.matchedTransaction?.id,
        error: 'Skipped — duplicate of an existing transaction.'
      });
      summary.autoSkippedDuplicates += 1;
      continue;
    }

    if (dup.needsReview) {
      const logId = await db.smsLogs.add({
        sender: raw.sender,
        body: raw.body,
        date: raw.date,
        processed: false
      });
      summary.needsReview.push({
        smsLogId: logId,
        raw,
        candidate,
        score: dup.score,
        matchedTransaction: dup.matchedTransaction
      });
      continue;
    }

    const txId = await insertTransaction(candidate);
    await db.smsLogs.add({
      sender: raw.sender,
      body: raw.body,
      date: raw.date,
      processed: true,
      transactionId: txId
    });
    summary.inserted += 1;
  }

  return summary;
}

/** Resolves one review-queue item after the person decides "keep" or "skip". */
export async function resolveReviewItem(item: ReviewItem, keep: boolean): Promise<void> {
  if (keep) {
    const txId = await insertTransaction(item.candidate);
    await db.smsLogs.update(item.smsLogId, { processed: true, transactionId: txId });
  } else {
    await db.smsLogs.update(item.smsLogId, {
      processed: true,
      error: 'Skipped by user — marked as duplicate.'
    });
  }
}
