import { create } from 'zustand';
import type { Category, PaymentMethod } from '@/types';

export type DatePreset = 'today' | 'yesterday' | 'thisWeek' | 'thisMonth' | 'lastMonth' | 'custom' | 'all';

interface FilterState {
  search: string;
  datePreset: DatePreset;
  customStart?: string;
  customEnd?: string;
  categories: Category[];
  banks: string[];
  paymentMethods: PaymentMethod[];
  setSearch: (search: string) => void;
  setDatePreset: (preset: DatePreset) => void;
  setCustomRange: (start: string, end: string) => void;
  toggleCategory: (category: Category) => void;
  toggleBank: (bank: string) => void;
  togglePaymentMethod: (method: PaymentMethod) => void;
  reset: () => void;
}

const initial = {
  search: '',
  datePreset: 'thisMonth' as DatePreset,
  customStart: undefined as string | undefined,
  customEnd: undefined as string | undefined,
  categories: [] as Category[],
  banks: [] as string[],
  paymentMethods: [] as PaymentMethod[]
};

export const useFilterStore = create<FilterState>((set) => ({
  ...initial,
  setSearch: (search) => set({ search }),
  setDatePreset: (datePreset) => set({ datePreset }),
  setCustomRange: (customStart, customEnd) => set({ customStart, customEnd, datePreset: 'custom' }),
  toggleCategory: (category) =>
    set((s) => ({
      categories: s.categories.includes(category)
        ? s.categories.filter((c) => c !== category)
        : [...s.categories, category]
    })),
  toggleBank: (bank) =>
    set((s) => ({
      banks: s.banks.includes(bank) ? s.banks.filter((b) => b !== bank) : [...s.banks, bank]
    })),
  togglePaymentMethod: (method) =>
    set((s) => ({
      paymentMethods: s.paymentMethods.includes(method)
        ? s.paymentMethods.filter((m) => m !== method)
        : [...s.paymentMethods, method]
    })),
  reset: () => set(initial)
}));
