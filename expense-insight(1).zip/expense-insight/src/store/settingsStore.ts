import { create } from 'zustand';
import { db } from '@/db/db';

interface AppSettings {
  currency: string;
  pinEnabled: boolean;
  pinHash?: string;
}

interface SettingsState extends AppSettings {
  hydrated: boolean;
  hydrate: () => Promise<void>;
  update: (partial: Partial<AppSettings>) => Promise<void>;
}

const SETTINGS_KEY = 'app-settings';
const DEFAULTS: AppSettings = { currency: 'INR', pinEnabled: false };

export const useSettingsStore = create<SettingsState>((set, get) => ({
  ...DEFAULTS,
  hydrated: false,
  hydrate: async () => {
    const row = await db.settings.where('key').equals(SETTINGS_KEY).first();
    if (row) set({ ...DEFAULTS, ...(row.value as Partial<AppSettings>), hydrated: true });
    else set({ hydrated: true });
  },
  update: async (partial) => {
    const next: AppSettings = {
      currency: get().currency,
      pinEnabled: get().pinEnabled,
      pinHash: get().pinHash,
      ...partial
    };
    set(next);
    const row = await db.settings.where('key').equals(SETTINGS_KEY).first();
    if (row) await db.settings.update(row.id!, { value: next });
    else await db.settings.add({ key: SETTINGS_KEY, value: next });
  }
}));

/** SHA-256 hash of a PIN, so the raw PIN itself is never stored. */
export async function hashPin(pin: string): Promise<string> {
  const enc = new TextEncoder().encode(pin);
  const digest = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}
