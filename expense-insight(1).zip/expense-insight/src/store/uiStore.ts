import { create } from 'zustand';

export type ThemeMode = 'light' | 'dark' | 'system';

interface UiState {
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  /** Whether the PIN lock (if enabled) has been unlocked for this session. Never persisted. */
  unlocked: boolean;
  setUnlocked: (unlocked: boolean) => void;
  addTransactionOpen: boolean;
  setAddTransactionOpen: (open: boolean) => void;
}

export const useUiStore = create<UiState>((set) => ({
  themeMode: 'system',
  setThemeMode: (themeMode) => set({ themeMode }),
  unlocked: false,
  setUnlocked: (unlocked) => set({ unlocked }),
  addTransactionOpen: false,
  setAddTransactionOpen: (addTransactionOpen) => set({ addTransactionOpen })
}));
