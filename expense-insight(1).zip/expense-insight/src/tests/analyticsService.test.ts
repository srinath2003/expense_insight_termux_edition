import { describe, it, expect } from 'vitest';
import {
  computeDashboardStats,
  groupByCategory,
  topMerchants,
  dailySeries,
  cashflowSeries,
  daysElapsedInMonth
} from '@/services/analyticsService';
import { makeTransaction } from './testFixtures';

const TODAY = '2026-06-15T18:00:00.000Z';
const WEEK_START = '2026-06-14T00:00:00.000Z';

describe('computeDashboardStats', () => {
  it('sums today, week, and month spending correctly and excludes credits from spend totals', () => {
    const transactions = [
      makeTransaction({ amount: 100, date: '2026-06-15T09:00:00.000Z', type: 'debit' }), // today
      makeTransaction({ amount: 50, date: '2026-06-14T09:00:00.000Z', type: 'debit' }), // this week
      makeTransaction({ amount: 200, date: '2026-06-01T09:00:00.000Z', type: 'debit' }), // earlier this month
      makeTransaction({ amount: 5000, date: '2026-06-15T09:00:00.000Z', type: 'credit' }) // credit, should not count
    ];

    const stats = computeDashboardStats(transactions, TODAY, WEEK_START);
    expect(stats.todaySpending).toBe(100);
    expect(stats.weekSpending).toBe(150); // today (100) + June 14 (50)
    expect(stats.monthSpending).toBe(350); // all three debits
    expect(stats.transactionCount).toBe(4);
  });

  it('finds the largest transaction among debits', () => {
    const transactions = [
      makeTransaction({ amount: 100, date: '2026-06-15T09:00:00.000Z' }),
      makeTransaction({ amount: 900, date: '2026-06-10T09:00:00.000Z' }),
      makeTransaction({ amount: 500, date: '2026-06-05T09:00:00.000Z' })
    ];
    const stats = computeDashboardStats(transactions, TODAY, WEEK_START);
    expect(stats.largestTransaction?.amount).toBe(900);
  });

  it('finds the most visited merchant across both debits and credits', () => {
    const transactions = [
      makeTransaction({ normalizedMerchant: 'Swiggy', date: '2026-06-15T09:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Swiggy', date: '2026-06-10T09:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Swiggy', date: '2026-06-05T09:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Uber', date: '2026-06-03T09:00:00.000Z' })
    ];
    const stats = computeDashboardStats(transactions, TODAY, WEEK_START);
    expect(stats.mostVisitedMerchant?.name).toBe('Swiggy');
    expect(stats.mostVisitedMerchant?.count).toBe(3);
  });

  it('returns null largest/most-visited for an empty set without throwing', () => {
    const stats = computeDashboardStats([], TODAY, WEEK_START);
    expect(stats.largestTransaction).toBeNull();
    expect(stats.mostVisitedMerchant).toBeNull();
    expect(stats.monthSpending).toBe(0);
  });
});

describe('groupByCategory', () => {
  it('sums debit amounts per category and sorts descending', () => {
    const transactions = [
      makeTransaction({ category: 'Food', amount: 300 }),
      makeTransaction({ category: 'Food', amount: 200 }),
      makeTransaction({ category: 'Travel', amount: 900 }),
      makeTransaction({ category: 'Travel', amount: 100, type: 'credit' }) // credit excluded
    ];
    const result = groupByCategory(transactions);
    expect(result[0]).toEqual({ name: 'Travel', value: 900 });
    expect(result[1]).toEqual({ name: 'Food', value: 500 });
  });
});

describe('topMerchants', () => {
  it('sums debit spend per merchant, sorts descending, and respects the limit', () => {
    const transactions = [
      makeTransaction({ normalizedMerchant: 'Amazon', amount: 1000 }),
      makeTransaction({ normalizedMerchant: 'Amazon', amount: 500 }),
      makeTransaction({ normalizedMerchant: 'Flipkart', amount: 2000 }),
      makeTransaction({ normalizedMerchant: 'Swiggy', amount: 300 })
    ];
    const result = topMerchants(transactions, 2);
    expect(result).toHaveLength(2);
    expect(result[0]).toEqual({ name: 'Flipkart', amount: 2000 });
    expect(result[1]).toEqual({ name: 'Amazon', amount: 1500 });
  });
});

describe('dailySeries', () => {
  it('produces one bucket per day in range, zero-filled where there is no spend', () => {
    const transactions = [makeTransaction({ amount: 100, date: '2026-06-15T09:00:00.000Z' })];
    const series = dailySeries(transactions, 3, '2026-06-15T23:59:00.000Z');
    expect(series).toHaveLength(3);
    expect(series[series.length - 1].amount).toBe(100);
    expect(series[0].amount).toBe(0);
  });
});

describe('cashflowSeries', () => {
  it('separates debit and credit totals per day', () => {
    const transactions = [
      makeTransaction({ amount: 100, type: 'debit', date: '2026-06-15T09:00:00.000Z' }),
      makeTransaction({ amount: 5000, type: 'credit', date: '2026-06-15T09:00:00.000Z' })
    ];
    const series = cashflowSeries(transactions, 1, '2026-06-15T23:59:00.000Z');
    expect(series[0].debit).toBe(100);
    expect(series[0].credit).toBe(5000);
  });
});

describe('daysElapsedInMonth', () => {
  it('returns the day-of-month and days-in-month', () => {
    const result = daysElapsedInMonth('2026-06-15T12:00:00.000Z');
    expect(result.elapsed).toBe(15);
    expect(result.total).toBe(30);
  });
});
