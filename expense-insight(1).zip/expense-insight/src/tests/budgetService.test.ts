import { describe, it, expect, beforeEach } from 'vitest';
import { db } from '@/db/db';
import { calculateBudgetStatus, deleteBudget, listBudgetsForMonth, suggestedCategories, upsertBudget } from '@/services/budgetService';
import { makeTransaction } from './testFixtures';
import type { Budget } from '@/types';

describe('calculateBudgetStatus', () => {
  const todayIso = '2026-06-10T12:00:00.000Z'; // 10 days elapsed of a 30-day June

  it('computes spend, remaining, and month-end prediction for a category budget', () => {
    const budget: Budget = { category: 'Food', monthlyLimit: 1000, month: '2026-06' };
    const monthTransactions = [
      makeTransaction({ category: 'Food', amount: 250, type: 'debit' }),
      makeTransaction({ category: 'Food', amount: 150, type: 'debit' }),
      makeTransaction({ category: 'Travel', amount: 500, type: 'debit' }), // different category, excluded
      makeTransaction({ category: 'Food', amount: 100, type: 'credit' }) // credit, excluded
    ];

    const status = calculateBudgetStatus(budget, monthTransactions, todayIso);
    expect(status.spent).toBe(400);
    expect(status.remaining).toBe(600);
    expect(status.percentUsed).toBe(40);
    expect(status.predictedMonthEnd).toBe(1200); // (400/10)*30
    expect(status.isOverBudget).toBe(false);
    expect(status.isPredictedOverBudget).toBe(true);
  });

  it('includes every category for an Overall budget', () => {
    const budget: Budget = { category: 'Overall', monthlyLimit: 1000, month: '2026-06' };
    const monthTransactions = [
      makeTransaction({ category: 'Food', amount: 250, type: 'debit' }),
      makeTransaction({ category: 'Travel', amount: 500, type: 'debit' })
    ];
    const status = calculateBudgetStatus(budget, monthTransactions, todayIso);
    expect(status.spent).toBe(750);
  });

  it('flags isOverBudget once spend exceeds the limit', () => {
    const budget: Budget = { category: 'Food', monthlyLimit: 100, month: '2026-06' };
    const monthTransactions = [makeTransaction({ category: 'Food', amount: 150, type: 'debit' })];
    const status = calculateBudgetStatus(budget, monthTransactions, todayIso);
    expect(status.isOverBudget).toBe(true);
    expect(status.remaining).toBe(-50);
  });
});

describe('budget persistence', () => {
  beforeEach(async () => {
    await db.budgets.clear();
  });

  it('creates a new budget row', async () => {
    await upsertBudget({ category: 'Food', monthlyLimit: 5000, month: '2026-06' });
    const budgets = await listBudgetsForMonth('2026-06');
    expect(budgets).toHaveLength(1);
    expect(budgets[0].monthlyLimit).toBe(5000);
  });

  it('updates rather than duplicates when the same category+month is upserted again', async () => {
    await upsertBudget({ category: 'Food', monthlyLimit: 5000, month: '2026-06' });
    await upsertBudget({ category: 'Food', monthlyLimit: 7000, month: '2026-06' });
    const budgets = await listBudgetsForMonth('2026-06');
    expect(budgets).toHaveLength(1);
    expect(budgets[0].monthlyLimit).toBe(7000);
  });

  it('keeps budgets for different months separate', async () => {
    await upsertBudget({ category: 'Food', monthlyLimit: 5000, month: '2026-06' });
    await upsertBudget({ category: 'Food', monthlyLimit: 6000, month: '2026-07' });
    expect(await listBudgetsForMonth('2026-06')).toHaveLength(1);
    expect(await listBudgetsForMonth('2026-07')).toHaveLength(1);
  });

  it('deletes a budget', async () => {
    const id = await upsertBudget({ category: 'Food', monthlyLimit: 5000, month: '2026-06' });
    await deleteBudget(id);
    expect(await listBudgetsForMonth('2026-06')).toHaveLength(0);
  });
});

describe('suggestedCategories', () => {
  it('excludes categories that already have a budget', () => {
    const existing: Budget[] = [{ category: 'Food', monthlyLimit: 1000, month: '2026-06' }];
    const suggestions = suggestedCategories(existing);
    expect(suggestions).not.toContain('Food');
    expect(suggestions).toContain('Overall');
  });
});
