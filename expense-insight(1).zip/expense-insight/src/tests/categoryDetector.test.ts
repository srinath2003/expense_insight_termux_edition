import { describe, it, expect, beforeEach } from 'vitest';
import { detectCategory, detectCategoryWithUserRules } from '@/engine/categoryDetector';
import { db } from '@/db/db';

describe('detectCategory', () => {
  it('categorizes well-known food delivery merchants as Food', () => {
    expect(detectCategory('Swiggy order')).toBe('Food');
    expect(detectCategory('Zomato Online')).toBe('Food');
  });

  it('categorizes grocery merchants as Groceries, even when "Fresh" overlaps with Food-adjacent terms', () => {
    expect(detectCategory('Reliance Fresh')).toBe('Groceries');
    expect(detectCategory('BigBasket order')).toBe('Groceries');
  });

  it('categorizes ride-hailing as Travel', () => {
    expect(detectCategory('Uber trip')).toBe('Travel');
    expect(detectCategory('Ola cab')).toBe('Travel');
  });

  it('categorizes streaming subscriptions as Subscription, not Entertainment', () => {
    expect(detectCategory('Netflix monthly')).toBe('Subscription');
    expect(detectCategory('Spotify Premium')).toBe('Subscription');
  });

  it('always categorizes ATM payment method as ATM regardless of text', () => {
    expect(detectCategory('some unrelated text', 'ATM')).toBe('ATM');
  });

  it('falls back to Others when nothing matches', () => {
    expect(detectCategory('a truly unrecognizable merchant blob')).toBe('Others');
  });

  it('categorizes salary credits correctly', () => {
    expect(detectCategory('towards Salary')).toBe('Salary');
  });
});

describe('detectCategoryWithUserRules', () => {
  beforeEach(async () => {
    await db.categoryRules.clear();
  });

  it('prefers a user-defined rule over the built-in keyword map', async () => {
    await db.categoryRules.add({ keyword: 'swiggy', category: 'Entertainment' });
    const result = await detectCategoryWithUserRules('Swiggy order');
    expect(result).toBe('Entertainment');
  });

  it('falls back to the built-in detector when no user rule matches', async () => {
    const result = await detectCategoryWithUserRules('Uber trip');
    expect(result).toBe('Travel');
  });
});
