import { describe, it, expect, beforeEach } from 'vitest';
import { db } from '@/db/db';
import { checkDuplicate, computeTransactionHash, registerHash } from '@/engine/duplicateDetector';
import type { Transaction } from '@/types';

const BASE = {
  amount: 250,
  currency: 'INR',
  bank: 'HDFC Bank',
  type: 'debit' as const,
  merchant: 'Amazon',
  normalizedMerchant: 'Amazon',
  paymentMethod: 'Credit Card' as const,
  date: '2026-06-25T14:30:00.000Z',
  time: '2026-06-25T14:30:00.000Z',
  narration: 'Rs.250 spent at Amazon',
  category: 'Shopping' as const,
  confidence: 95
};

async function insertFixture(overrides: Partial<Transaction> = {}): Promise<number> {
  const hash = await computeTransactionHash({ ...BASE, ...overrides });
  const id = await db.transactions.add({ ...BASE, ...overrides, hash, createdAt: new Date().toISOString() } as Transaction);
  await registerHash(hash, id);
  return id;
}

describe('computeTransactionHash', () => {
  it('is deterministic for identical inputs', async () => {
    const a = await computeTransactionHash(BASE);
    const b = await computeTransactionHash(BASE);
    expect(a).toBe(b);
  });

  it('changes when the amount changes', async () => {
    const a = await computeTransactionHash(BASE);
    const b = await computeTransactionHash({ ...BASE, amount: 999 });
    expect(a).not.toBe(b);
  });

  it('is stable across same-day time differences (uses date, not time)', async () => {
    const a = await computeTransactionHash({ ...BASE, date: '2026-06-25T14:30:00.000Z' });
    const b = await computeTransactionHash({ ...BASE, date: '2026-06-25T09:00:00.000Z' });
    expect(a).toBe(b);
  });
});

describe('checkDuplicate', () => {
  beforeEach(async () => {
    await db.transactions.clear();
    await db.duplicateHashes.clear();
  });

  it('flags an exact re-import (same hash) as a duplicate with 100% score', async () => {
    await insertFixture({ reference: 'REF001' });
    const hash = await computeTransactionHash({ ...BASE, reference: 'REF001' });
    const result = await checkDuplicate({ ...BASE, reference: 'REF001', hash });
    expect(result.isDuplicate).toBe(true);
    expect(result.score).toBe(100);
  });

  it('flags a same-day/bank/amount/reference match above 95% even with a different hash input', async () => {
    await insertFixture({ reference: 'REF001', time: '2026-06-25T14:30:00.000Z' });
    const differentHash = await computeTransactionHash({ ...BASE, reference: 'REF001-DUPE' });
    const result = await checkDuplicate({
      ...BASE,
      reference: 'REF001',
      time: '2026-06-25T14:30:00.000Z',
      hash: differentHash
    });
    expect(result.score).toBeGreaterThan(95);
    expect(result.isDuplicate).toBe(true);
  });

  it('sends a plausible-but-uncertain match to review rather than auto-skipping', async () => {
    await insertFixture({ reference: 'REF001', time: '2026-06-25T14:30:00.000Z' });
    const newHash = await computeTransactionHash({ ...BASE, reference: 'REF002' });
    // Same bank, same day, same amount, same merchant — but a different reference
    // number AND a different time, so it lands short of the auto-duplicate bar.
    const result = await checkDuplicate({
      ...BASE,
      reference: 'REF002',
      time: '2026-06-25T18:00:00.000Z',
      hash: newHash
    });
    expect(result.isDuplicate).toBe(false);
    expect(result.needsReview).toBe(true);
    expect(result.score).toBeGreaterThanOrEqual(60);
    expect(result.score).toBeLessThanOrEqual(95);
  });

  it('does not flag an unrelated transaction as a duplicate', async () => {
    await insertFixture();
    const newHash = await computeTransactionHash({
      ...BASE,
      amount: 4500,
      normalizedMerchant: 'Flipkart',
      date: '2026-07-10T10:00:00.000Z'
    });
    const result = await checkDuplicate({
      ...BASE,
      amount: 4500,
      normalizedMerchant: 'Flipkart',
      date: '2026-07-10T10:00:00.000Z',
      hash: newHash
    });
    expect(result.isDuplicate).toBe(false);
    expect(result.needsReview).toBe(false);
  });
});
