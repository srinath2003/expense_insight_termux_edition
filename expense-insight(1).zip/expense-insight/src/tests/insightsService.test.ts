import { describe, it, expect } from 'vitest';
import { generateInsights } from '@/services/insightsService';
import { makeTransaction } from './testFixtures';

describe('generateInsights', () => {
  it('detects a category spending increase month-over-month', () => {
    const currentMonth = [
      makeTransaction({ category: 'Food', normalizedMerchant: 'Swiggy', amount: 100, date: '2026-06-01T10:00:00.000Z' }),
      makeTransaction({ category: 'Food', normalizedMerchant: 'Swiggy', amount: 100, date: '2026-06-02T10:00:00.000Z' }),
      makeTransaction({ category: 'Food', normalizedMerchant: 'Swiggy', amount: 100, date: '2026-06-03T10:00:00.000Z' })
    ];
    const previousMonth = [makeTransaction({ category: 'Food', normalizedMerchant: 'Swiggy', amount: 200, date: '2026-05-01T10:00:00.000Z' })];

    const insights = generateInsights({ currentMonth, previousMonth, recentWindow: currentMonth });
    const categoryInsight = insights.find((i) => i.id === 'category-mom');
    expect(categoryInsight).toBeDefined();
    expect(categoryInsight?.description).toContain('Food');
    expect(categoryInsight?.description).toContain('50%');
    expect(categoryInsight?.severity).toBe('warning');
  });

  it('detects a frequent merchant (3+ visits)', () => {
    const currentMonth = [
      makeTransaction({ normalizedMerchant: 'Swiggy', amount: 100, date: '2026-06-01T10:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Swiggy', amount: 100, date: '2026-06-02T10:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Swiggy', amount: 100, date: '2026-06-03T10:00:00.000Z' })
    ];
    const insights = generateInsights({ currentMonth, previousMonth: [], recentWindow: currentMonth });
    const visitInsight = insights.find((i) => i.id === 'merchant-visits');
    expect(visitInsight?.description).toContain('Swiggy');
    expect(visitInsight?.description).toContain('3');
  });

  it('reports the correct weekday for the highest expense day', () => {
    const currentMonth = [
      makeTransaction({ amount: 50, date: '2026-06-15T10:00:00.000Z' }), // Monday
      makeTransaction({ amount: 50, date: '2026-06-16T10:00:00.000Z' }), // Tuesday
      makeTransaction({ amount: 50, date: '2026-06-17T10:00:00.000Z' }), // Wednesday
      makeTransaction({ amount: 50, date: '2026-06-18T10:00:00.000Z' }), // Thursday
      makeTransaction({ amount: 5000, date: '2026-06-19T10:00:00.000Z' }) // Friday — clear max
    ];
    const insights = generateInsights({ currentMonth, previousMonth: [], recentWindow: currentMonth });
    const dayInsight = insights.find((i) => i.id === 'highest-expense-day');
    expect(dayInsight?.description).toContain('Friday');
  });

  it('detects a merchant trending up month-over-month', () => {
    const currentMonth = [makeTransaction({ normalizedMerchant: 'Amazon', amount: 1420, date: '2026-06-05T10:00:00.000Z' })];
    const previousMonth = [makeTransaction({ normalizedMerchant: 'Amazon', amount: 1000, date: '2026-05-05T10:00:00.000Z' })];
    const insights = generateInsights({ currentMonth, previousMonth, recentWindow: currentMonth });
    const trendInsight = insights.find((i) => i.id === 'merchant-trend');
    expect(trendInsight?.description).toContain('Amazon');
    expect(trendInsight?.description).toContain('42%');
  });

  it('reports savings when this month spent less than last month', () => {
    const currentMonth = [makeTransaction({ amount: 200, date: '2026-06-05T10:00:00.000Z' })];
    const previousMonth = [makeTransaction({ amount: 500, date: '2026-05-05T10:00:00.000Z' })];
    const insights = generateInsights({ currentMonth, previousMonth, recentWindow: currentMonth });
    const momInsight = insights.find((i) => i.id === 'mom-total');
    expect(momInsight?.severity).toBe('positive');
    expect(momInsight?.description).toContain('300');
  });

  it('reports a subscriptions total when Subscription-category spend exists', () => {
    const currentMonth = [makeTransaction({ category: 'Subscription', normalizedMerchant: 'Netflix', amount: 199, date: '2026-06-05T10:00:00.000Z' })];
    const insights = generateInsights({ currentMonth, previousMonth: [], recentWindow: currentMonth });
    const subsInsight = insights.find((i) => i.id === 'subscriptions-total');
    expect(subsInsight?.description).toContain('199');
  });

  it('returns an empty array when there is nothing noteworthy to report', () => {
    const insights = generateInsights({ currentMonth: [], previousMonth: [], recentWindow: [] });
    expect(insights).toEqual([]);
  });
});
