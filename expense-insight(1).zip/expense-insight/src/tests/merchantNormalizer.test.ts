import { describe, it, expect } from 'vitest';
import { normalizeMerchant } from '@/engine/merchantNormalizer';

describe('normalizeMerchant', () => {
  it('collapses Amazon variants to a single canonical name', () => {
    expect(normalizeMerchant('AMAZON PAY')).toBe('Amazon');
    expect(normalizeMerchant('Amazon')).toBe('Amazon');
    expect(normalizeMerchant('Amazon India')).toBe('Amazon');
    expect(normalizeMerchant('AMAZON.IN')).toBe('Amazon');
  });

  it('collapses Swiggy variants', () => {
    expect(normalizeMerchant('Swiggy Instamart')).toBe('Swiggy');
    expect(normalizeMerchant('SWIGGY')).toBe('Swiggy');
  });

  it('collapses Uber variants', () => {
    expect(normalizeMerchant('Uber Trip')).toBe('Uber');
    expect(normalizeMerchant('UBER')).toBe('Uber');
  });

  it('collapses Zomato variants', () => {
    expect(normalizeMerchant('Zomato Online')).toBe('Zomato');
  });

  it('collapses Reliance variants to a single brand', () => {
    expect(normalizeMerchant('Reliance Fresh')).toBe('Reliance');
    expect(normalizeMerchant('RELIANCE DIGITAL')).toBe('Reliance');
    expect(normalizeMerchant('Reliance Trends')).toBe('Reliance');
  });

  it('falls back to title case for unknown merchants', () => {
    expect(normalizeMerchant('SOME RANDOM STORE')).toBe('Some Random Store');
  });

  it('handles empty or missing input gracefully', () => {
    expect(normalizeMerchant('')).toBe('Unknown Merchant');
    expect(normalizeMerchant('   ')).toBe('Unknown Merchant');
  });
});
