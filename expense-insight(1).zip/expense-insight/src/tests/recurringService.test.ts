import { describe, it, expect } from 'vitest';
import { detectRecurring, totalRecurringMonthly, isSubscriptionMerchant } from '@/services/recurringService';
import { makeTransaction } from './testFixtures';

describe('detectRecurring', () => {
  it('flags a known subscription merchant even on a single occurrence', () => {
    const transactions = [makeTransaction({ normalizedMerchant: 'Netflix', amount: 199, date: '2026-06-10T09:00:00.000Z' })];
    const groups = detectRecurring(transactions);
    const netflix = groups.find((g) => g.normalizedMerchant === 'Netflix');
    expect(netflix).toBeDefined();
    expect(netflix?.occurrences).toBe(1);
    expect(netflix?.averageAmount).toBe(199);
  });

  it('flags a non-subscription merchant that repeats roughly every 30 days', () => {
    const transactions = [
      makeTransaction({ normalizedMerchant: 'Landlord', amount: 20000, date: '2026-04-01T09:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Landlord', amount: 20000, date: '2026-05-01T09:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Landlord', amount: 20000, date: '2026-05-31T09:00:00.000Z' })
    ];
    const groups = detectRecurring(transactions);
    const landlord = groups.find((g) => g.normalizedMerchant === 'Landlord');
    expect(landlord).toBeDefined();
    expect(landlord?.occurrences).toBe(3);
    expect(landlord?.averageAmount).toBe(20000);
  });

  it('does not flag a one-off, non-subscription merchant', () => {
    const transactions = [makeTransaction({ normalizedMerchant: 'Random Cafe', amount: 250, date: '2026-06-10T09:00:00.000Z' })];
    const groups = detectRecurring(transactions);
    expect(groups.find((g) => g.normalizedMerchant === 'Random Cafe')).toBeUndefined();
  });

  it('does not flag two purchases at irregular (non-monthly) intervals from an unrecognized merchant', () => {
    const transactions = [
      makeTransaction({ normalizedMerchant: 'Random Cafe', amount: 250, date: '2026-06-01T09:00:00.000Z' }),
      makeTransaction({ normalizedMerchant: 'Random Cafe', amount: 250, date: '2026-06-04T09:00:00.000Z' }) // 3 days apart
    ];
    const groups = detectRecurring(transactions);
    expect(groups.find((g) => g.normalizedMerchant === 'Random Cafe')).toBeUndefined();
  });

  it('ignores credit transactions', () => {
    const transactions = [makeTransaction({ normalizedMerchant: 'Netflix', amount: 199, date: '2026-06-10T09:00:00.000Z', type: 'credit' })];
    const groups = detectRecurring(transactions);
    expect(groups.find((g) => g.normalizedMerchant === 'Netflix')).toBeUndefined();
  });
});

describe('totalRecurringMonthly', () => {
  it('sums the average amount across all groups', () => {
    const total = totalRecurringMonthly([
      { normalizedMerchant: 'Netflix', category: 'Subscription', averageAmount: 199, intervalDays: 30, occurrences: 1, lastDate: '', nextPredictedDate: '', transactionIds: [] },
      { normalizedMerchant: 'Spotify', category: 'Subscription', averageAmount: 119, intervalDays: 30, occurrences: 1, lastDate: '', nextPredictedDate: '', transactionIds: [] }
    ]);
    expect(total).toBe(318);
  });
});

describe('isSubscriptionMerchant', () => {
  it('recognizes known subscription brands by name', () => {
    expect(isSubscriptionMerchant('Netflix')).toBe(true);
    expect(isSubscriptionMerchant('Spotify')).toBe(true);
  });

  it('recognizes any merchant explicitly categorized as Subscription', () => {
    expect(isSubscriptionMerchant('Some Local App', 'Subscription')).toBe(true);
  });

  it('returns false for unrelated merchants', () => {
    expect(isSubscriptionMerchant('Amazon', 'Shopping')).toBe(false);
  });
});
