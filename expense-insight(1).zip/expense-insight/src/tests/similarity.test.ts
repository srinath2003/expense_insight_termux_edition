import { describe, it, expect } from 'vitest';
import { levenshteinDistance, levenshteinSimilarity } from '@/utils/similarity';

describe('levenshteinDistance', () => {
  it('returns 0 for identical strings', () => {
    expect(levenshteinDistance('swiggy', 'swiggy')).toBe(0);
  });

  it('handles empty strings', () => {
    expect(levenshteinDistance('', 'abc')).toBe(3);
    expect(levenshteinDistance('abc', '')).toBe(3);
  });

  it('counts a single substitution', () => {
    expect(levenshteinDistance('cat', 'bat')).toBe(1);
  });

  it('counts insertions and deletions', () => {
    expect(levenshteinDistance('swiggy', 'swiggyy')).toBe(1);
    expect(levenshteinDistance('amazon', 'amazn')).toBe(1);
  });
});

describe('levenshteinSimilarity', () => {
  it('is 1 for identical strings (case-insensitive)', () => {
    expect(levenshteinSimilarity('Amazon', 'amazon')).toBe(1);
  });

  it('is close to 1 for near-identical merchant strings', () => {
    expect(levenshteinSimilarity('Amazon Pay', 'Amazon pay')).toBeGreaterThan(0.9);
  });

  it('is low for very different strings', () => {
    expect(levenshteinSimilarity('Swiggy', 'Uber')).toBeLessThan(0.4);
  });
});
