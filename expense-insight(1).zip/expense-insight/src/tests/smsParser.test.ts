import { describe, it, expect, beforeEach } from 'vitest';
import { parseSms, extractAmount, extractMerchant, extractPaymentMethod, extractType } from '@/engine/smsParser';
import { db } from '@/db/db';

const NOW = new Date('2026-06-25T14:30:00.000Z').toISOString();

describe('smsParser — bank format coverage from the spec', () => {
  beforeEach(async () => {
    await db.categoryRules.clear();
  });

  it('parses HDFC credit card format', async () => {
    const result = await parseSms({
      sender: 'HDFCBK',
      body: 'Rs.250 spent on your HDFC Bank Credit Card at AMAZON on 25-06-2026.',
      date: NOW,
    });
    expect(result.success).toBe(true);
    expect(result.transaction?.amount).toBe(250);
    expect(result.transaction?.bank).toBe('HDFC Bank');
    expect(result.transaction?.paymentMethod).toBe('Credit Card');
    expect(result.transaction?.normalizedMerchant).toBe('Amazon');
    expect(result.transaction?.type).toBe('debit');
  });

  it('parses SBI UPI debit format with reference number', async () => {
    const result = await parseSms({
      sender: 'SBIINB',
      body: 'INR 580 debited A/C XX1234 via UPI to Swiggy. Ref No 302981123.',
      date: NOW,
    });
    expect(result.success).toBe(true);
    expect(result.transaction?.amount).toBe(580);
    expect(result.transaction?.bank).toBe('State Bank of India');
    expect(result.transaction?.paymentMethod).toBe('UPI');
    expect(result.transaction?.normalizedMerchant).toBe('Swiggy');
    expect(result.transaction?.reference).toBe('302981123');
    expect(result.transaction?.account).toMatch(/1234/);
  });

  it('parses ICICI debit card format with balance', async () => {
    const result = await parseSms({
      sender: 'ICICIB',
      body: 'Rs.1299 spent using Debit Card at Reliance Fresh. Avl Bal Rs.45210.',
      date: NOW,
    });
    expect(result.success).toBe(true);
    expect(result.transaction?.amount).toBe(1299);
    expect(result.transaction?.bank).toBe('ICICI Bank');
    expect(result.transaction?.paymentMethod).toBe('Debit Card');
    expect(result.transaction?.normalizedMerchant).toBe('Reliance');
    expect(result.transaction?.balance).toBe(45210);
    expect(result.transaction?.category).toBe('Groceries');
  });

  it('parses Axis UPI txn format', async () => {
    const result = await parseSms({
      sender: 'AXISBK',
      body: 'UPI Txn of Rs 230 to Uber successful.',
      date: NOW,
    });
    expect(result.success).toBe(true);
    expect(result.transaction?.amount).toBe(230);
    expect(result.transaction?.bank).toBe('Axis Bank');
    expect(result.transaction?.normalizedMerchant).toBe('Uber');
    expect(result.transaction?.category).toBe('Travel');
  });

  it('parses Kotak simple paid-to format', async () => {
    const result = await parseSms({ sender: 'KOTAKB', body: 'INR 899 paid to Flipkart.', date: NOW });
    expect(result.success).toBe(true);
    expect(result.transaction?.amount).toBe(899);
    expect(result.transaction?.bank).toBe('Kotak Mahindra Bank');
    expect(result.transaction?.normalizedMerchant).toBe('Flipkart');
    expect(result.transaction?.category).toBe('Shopping');
  });

  it('parses Canara ATM withdrawal format', async () => {
    const result = await parseSms({ sender: 'CANBNK', body: 'Rs.120 withdrawn using ATM.', date: NOW });
    expect(result.success).toBe(true);
    expect(result.transaction?.amount).toBe(120);
    expect(result.transaction?.bank).toBe('Canara Bank');
    expect(result.transaction?.paymentMethod).toBe('ATM');
    expect(result.transaction?.category).toBe('ATM');
  });

  it('identifies all remaining banks from the spec via sender ID', async () => {
    const cases: Array<[string, string]> = [
      ['INDBNK', 'Indian Bank'],
      ['FEDBNK', 'Federal Bank'],
      ['IDFCFB', 'IDFC First Bank'],
      ['YESBNK', 'Yes Bank'],
      ['UNIONB', 'Union Bank of India'],
      ['BOBIND', 'Bank of Baroda'],
      ['PNBSMS', 'Punjab National Bank'],
    ];
    for (const [sender, expectedBank] of cases) {
      const result = await parseSms({ sender, body: 'Rs.500 spent at Store using UPI.', date: NOW });
      expect(result.transaction?.bank).toBe(expectedBank);
    }
  });

  it('handles DLT-style sender prefixes/suffixes (e.g. AD-HDFCBK-S)', async () => {
    const result = await parseSms({
      sender: 'AD-HDFCBK-S',
      body: 'Rs.500 spent using Debit Card at Store.',
      date: NOW,
    });
    expect(result.transaction?.bank).toBe('HDFC Bank');
  });

  it('detects credit transactions from keywords', async () => {
    const result = await parseSms({
      sender: 'YESBNK',
      body: 'INR 3200 credited to A/C XX5521 towards Salary.',
      date: NOW,
    });
    expect(result.transaction?.type).toBe('credit');
    expect(result.transaction?.category).toBe('Salary');
  });

  it('falls back to the heuristic extractor for unrecognized formats', async () => {
    const result = await parseSms({
      sender: 'AD-SCBANK',
      body: 'Your account was debited 340 for a purchase at a local store.',
      date: NOW,
    });
    expect(result.success).toBe(true);
    expect(result.transaction?.amount).toBe(340);
    expect(result.transaction?.confidence).toBeLessThanOrEqual(55);
  });

  it('fails gracefully when no amount can be found at all', async () => {
    const result = await parseSms({ sender: 'HDFCBK', body: 'Your OTP is 445566. Do not share it.', date: NOW });
    expect(result.success).toBe(false);
  });

  it('assigns a higher confidence score to fully-matched messages than partial ones', async () => {
    const full = await parseSms({
      sender: 'HDFCBK',
      body: 'Rs.250 spent on your HDFC Bank Credit Card at AMAZON on 25-06-2026.',
      date: NOW,
    });
    const partial = await parseSms({ sender: 'UNKNOWNXYZ', body: 'Rs.250 debited.', date: NOW });
    expect(full.transaction!.confidence).toBeGreaterThan(partial.transaction!.confidence);
  });
});

describe('smsParser — field extractor units', () => {
  it('extractAmount handles Rs., INR, and ₹ prefixes with commas', () => {
    expect(extractAmount('Rs.1,299.50 spent')).toBe(1299.5);
    expect(extractAmount('INR 580 debited')).toBe(580);
    expect(extractAmount('₹99 spent')).toBe(99);
  });

  it('extractType prefers explicit keywords', () => {
    expect(extractType('Rs.100 credited to your account').type).toBe('credit');
    expect(extractType('Rs.100 debited from your account').type).toBe('debit');
    expect(extractType('Rs.100 at some store').explicit).toBe(false);
  });

  it('extractPaymentMethod recognizes all supported methods', () => {
    expect(extractPaymentMethod('paid via UPI')).toBe('UPI');
    expect(extractPaymentMethod('using Debit Card')).toBe('Debit Card');
    expect(extractPaymentMethod('on your Credit Card')).toBe('Credit Card');
    expect(extractPaymentMethod('using ATM')).toBe('ATM');
    expect(extractPaymentMethod('via NEFT')).toBe('NEFT');
    expect(extractPaymentMethod('via IMPS')).toBe('IMPS');
    expect(extractPaymentMethod('via RTGS')).toBe('RTGS');
  });

  it('extractMerchant picks up merchant after at/to/in', () => {
    expect(extractMerchant('Rs.250 spent at AMAZON on 25-06-2026.')).toBe('AMAZON');
    expect(extractMerchant('UPI Txn of Rs 230 to Uber successful.')).toBe('Uber');
  });
});
