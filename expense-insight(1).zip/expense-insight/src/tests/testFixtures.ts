import type { Transaction } from '@/types';

let counter = 0;

/** Builds a minimal-but-valid Transaction for pure-function unit tests (no DB involved). */
export function makeTransaction(overrides: Partial<Transaction> = {}): Transaction {
  counter += 1;
  return {
    id: counter,
    amount: 100,
    currency: 'INR',
    bank: 'HDFC Bank',
    type: 'debit',
    merchant: 'Test Merchant',
    normalizedMerchant: 'Test Merchant',
    paymentMethod: 'UPI',
    date: '2026-06-15T12:00:00.000Z',
    narration: 'Test transaction',
    category: 'Others',
    confidence: 90,
    hash: `hash-${counter}`,
    createdAt: '2026-06-15T12:00:00.000Z',
    ...overrides
  };
}
