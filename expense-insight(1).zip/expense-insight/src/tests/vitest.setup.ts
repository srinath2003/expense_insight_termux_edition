import 'fake-indexeddb/auto';
import { webcrypto } from 'node:crypto';

// Several services (dailySeries, cashflowSeries, heatmapSeries, budget month
// math) mix local-time Date methods with UTC-sliced ISO date strings. The two
// only agree when the process runs in UTC, so pin it for deterministic tests
// regardless of the machine/CI runner's default timezone.
process.env.TZ = 'UTC';

// Dexie needs a global IndexedDB (provided by fake-indexeddb/auto above).
// The duplicate-detector and PIN hashing use crypto.subtle, which Node's
// test environment doesn't expose by default.
if (!globalThis.crypto?.subtle) {
  // @ts-expect-error -- Node's webcrypto is a compatible superset for our usage (digest()).
  globalThis.crypto = webcrypto;
}
