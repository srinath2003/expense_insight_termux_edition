import { createTheme, alpha, type ThemeOptions } from '@mui/material/styles';

// --- Design tokens -----------------------------------------------------
// Subject: an Indian bank-SMS ledger, so the palette leans into paper/ink
// and a warm "temple gold" accent rather than a generic fintech blue.
const gold = '#C99A3E';
const goldLight = '#E4B563';
const ink = '#12141C';
const inkElevated = '#1B1E2B';
const paper = '#FAF7F1';
const paperElevated = '#FFFFFF';
const positive = '#2F9E6E'; // credits / savings
const negative = '#C2542C'; // debits (a muted rust, not alarm-red)

const displayFont = '"Fraunces", "Georgia", serif';
const bodyFont = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

const sharedTypography: ThemeOptions['typography'] = {
  fontFamily: bodyFont,
  h1: { fontFamily: displayFont, fontWeight: 600, letterSpacing: '-0.01em' },
  h2: { fontFamily: displayFont, fontWeight: 600, letterSpacing: '-0.01em' },
  h3: { fontFamily: displayFont, fontWeight: 600 },
  h4: { fontFamily: displayFont, fontWeight: 600 },
  h5: { fontFamily: displayFont, fontWeight: 600 },
  h6: { fontFamily: displayFont, fontWeight: 600 },
  button: { textTransform: 'none', fontWeight: 600 }
};

const shape = { borderRadius: 16 };

function buildTheme(mode: 'light' | 'dark') {
  const isDark = mode === 'dark';

  return createTheme({
    palette: {
      mode,
      primary: { main: gold, light: goldLight, contrastText: '#12141C' },
      secondary: { main: positive },
      error: { main: negative },
      success: { main: positive },
      background: {
        default: isDark ? ink : paper,
        paper: isDark ? inkElevated : paperElevated
      },
      text: {
        primary: isDark ? '#F3EFE7' : '#1C1B18',
        secondary: isDark ? alpha('#F3EFE7', 0.68) : alpha('#1C1B18', 0.64)
      },
      divider: isDark ? alpha('#FFFFFF', 0.08) : alpha('#12141C', 0.09)
    },
    shape,
    typography: sharedTypography,
    components: {
      MuiCssBaseline: {
        styleOverrides: {
          body: {
            backgroundImage: isDark
              ? 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.035) 1px, transparent 0)'
              : 'radial-gradient(circle at 1px 1px, rgba(18,20,28,0.045) 1px, transparent 0)',
            backgroundSize: '22px 22px'
          },
          '.tabular-nums': {
            fontVariantNumeric: 'tabular-nums'
          }
        }
      },
      MuiPaper: {
        styleOverrides: {
          root: { backgroundImage: 'none' }
        }
      },
      MuiButton: {
        styleOverrides: {
          root: { borderRadius: 12 }
        }
      },
      MuiChip: {
        styleOverrides: {
          root: { borderRadius: 8, fontWeight: 600 }
        }
      },
      MuiAppBar: {
        styleOverrides: {
          root: {
            backgroundImage: 'none',
            backgroundColor: isDark ? alpha(inkElevated, 0.86) : alpha(paperElevated, 0.86),
            backdropFilter: 'blur(12px)',
            boxShadow: 'none',
            borderBottom: `1px solid ${isDark ? alpha('#FFFFFF', 0.08) : alpha('#12141C', 0.08)}`
          }
        }
      }
    }
  });
}

export const lightTheme = buildTheme('light');
export const darkTheme = buildTheme('dark');

// A couple of tokens components reach for directly (glass cards, amount coloring).
export const tokens = {
  gold,
  goldLight,
  ink,
  inkElevated,
  paper,
  paperElevated,
  positive,
  negative,
  displayFont
};

export function glassSurfaceSx(isDark: boolean) {
  return {
    background: isDark ? alpha(inkElevated, 0.6) : alpha('#FFFFFF', 0.7),
    backdropFilter: 'blur(16px)',
    border: `1px solid ${isDark ? alpha('#FFFFFF', 0.08) : alpha('#12141C', 0.06)}`,
    borderTop: `2px solid ${alpha(gold, isDark ? 0.5 : 0.4)}`
  };
}
