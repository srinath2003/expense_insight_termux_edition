// Core domain types for Expense Insight.
// Keeping these in one place makes the parser, database, and UI layers agree
// on a single shape for a transaction and its related records.

export type TransactionType = 'debit' | 'credit';

export type PaymentMethod =
  | 'UPI'
  | 'Debit Card'
  | 'Credit Card'
  | 'Net Banking'
  | 'ATM'
  | 'Cash'
  | 'IMPS'
  | 'NEFT'
  | 'RTGS'
  | 'Other';

export const CATEGORIES = [
  'Food',
  'Groceries',
  'Fuel',
  'Medical',
  'Shopping',
  'Travel',
  'Bills',
  'Recharge',
  'Entertainment',
  'Investment',
  'Transfer',
  'ATM',
  'Salary',
  'Cashback',
  'Refund',
  'Subscription',
  'Education',
  'Others'
] as const;

export type Category = (typeof CATEGORIES)[number];

/** A transaction extracted from SMS (or entered manually) and stored in IndexedDB. */
export interface Transaction {
  id?: number;
  amount: number;
  currency: string;
  bank: string;
  account?: string;
  type: TransactionType;
  merchant: string;
  normalizedMerchant: string;
  paymentMethod: PaymentMethod;
  /** ISO 8601 datetime string. */
  date: string;
  time?: string;
  reference?: string;
  upiId?: string;
  balance?: number;
  location?: string;
  narration: string;
  category: Category;
  /** True once a person has explicitly changed the category, so future re-categorization leaves it alone. */
  categoryManuallySet?: boolean;
  /** 0-100 confidence score produced by the parser. */
  confidence: number;
  /** Hash used for duplicate detection (bank + amount + date + reference + merchant + type). */
  hash: string;
  rawSms?: string;
  createdAt: string;
  isRecurring?: boolean;
  recurringGroupId?: string;
  /** True when this row was entered by hand rather than parsed from SMS. */
  isManual?: boolean;
}

export interface Merchant {
  id?: number;
  rawName: string;
  normalizedName: string;
  category?: Category;
  visitCount: number;
  totalSpent: number;
  lastVisit: string;
}

export interface Budget {
  id?: number;
  /** A specific category, or 'Overall' for a total monthly budget. */
  category: Category | 'Overall';
  monthlyLimit: number;
  /** 'YYYY-MM' */
  month: string;
}

/** A user-defined keyword -> category override, checked before the built-in keyword map. */
export interface CategoryRule {
  id?: number;
  keyword: string;
  category: Category;
}

export interface SettingsRecord {
  id?: number;
  key: string;
  value: unknown;
}

export interface SmsLog {
  id?: number;
  sender: string;
  body: string;
  date: string;
  processed: boolean;
  transactionId?: number;
  error?: string;
}

export interface DuplicateHashEntry {
  id?: number;
  hash: string;
  transactionId: number;
}

/** A raw, unparsed SMS message — the parser's input. */
export interface RawSms {
  sender: string;
  body: string;
  /** ISO 8601 datetime the SMS was received. Used as a date/time fallback. */
  date: string;
}

export interface ParsedSmsResult {
  success: boolean;
  transaction?: Omit<Transaction, 'id' | 'createdAt'>;
  error?: string;
}

export interface Insight {
  id: string;
  type: string;
  title: string;
  description: string;
  severity: 'info' | 'positive' | 'warning';
}

export interface RecurringGroup {
  normalizedMerchant: string;
  category: Category;
  averageAmount: number;
  intervalDays: number;
  occurrences: number;
  lastDate: string;
  nextPredictedDate: string;
  transactionIds: number[];
}

export interface BudgetStatus {
  budget: Budget;
  spent: number;
  remaining: number;
  predictedMonthEnd: number;
  percentUsed: number;
  isOverBudget: boolean;
  isPredictedOverBudget: boolean;
}
