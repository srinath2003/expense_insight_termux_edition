import { format, parseISO } from 'date-fns';

const currencyFormatters: Record<string, Intl.NumberFormat> = {};

function getFormatter(currency: string) {
  if (!currencyFormatters[currency]) {
    currencyFormatters[currency] = new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency,
      maximumFractionDigits: 0
    });
  }
  return currencyFormatters[currency];
}

/** Formats a number as currency, defaulting to Indian Rupee grouping (e.g. ₹1,23,456). */
export function formatCurrency(amount: number, currency = 'INR'): string {
  try {
    return getFormatter(currency).format(amount);
  } catch {
    return `₹${amount.toFixed(0)}`;
  }
}

export function formatDate(iso: string, pattern = 'd MMM yyyy'): string {
  try {
    return format(parseISO(iso), pattern);
  } catch {
    return iso;
  }
}

export function formatDateTime(iso: string): string {
  return formatDate(iso, 'd MMM yyyy, h:mm a');
}

export function formatTime(iso: string): string {
  return formatDate(iso, 'h:mm a');
}

export function toTitleCase(input: string): string {
  return input
    .toLowerCase()
    .split(' ')
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join(' ');
}
