#!/data/data/com.termux/files/usr/bin/bash
#
# sms-bridge.sh — polls the phone's SMS inbox via Termux:API and writes new
# messages to a JSON file that the app's "Sync now" button reads over
# localhost. Nothing leaves the phone; there's no network call at all.
#
# Requirements:
#   pkg install termux-api jq
#   Termux:API app installed (from the same source as Termux itself)
#   Grant Termux the SMS permission when Android prompts you
#
# Usage:
#   ./sms-bridge.sh              # one-time sync
#   ./sms-bridge.sh --watch      # re-syncs every 15s while left running
#
# State file (~/.sms-bridge-state) remembers the last message _id seen, so
# re-runs only pick up new messages instead of re-reading the whole inbox.

set -euo pipefail

OUT_DIR="$HOME/expense-insight-bridge"
OUT_FILE="$OUT_DIR/messages.json"
STATE_FILE="$HOME/.sms-bridge-state"
LIMIT=200 # how many recent messages to scan each poll

mkdir -p "$OUT_DIR"
[ -f "$STATE_FILE" ] || echo "0" > "$STATE_FILE"

sync_once() {
  local last_id
  last_id=$(cat "$STATE_FILE")

  # termux-sms-list returns newest-first JSON: [{_id, number, body, received, ...}, ...]
  local all
  all=$(termux-sms-list -l "$LIMIT" -t inbox)

  # Keep only messages newer than the last one we've already synced.
  local new_messages
  new_messages=$(echo "$all" | jq --argjson last "$last_id" '[.[] | select(._id > $last)]')

  local count
  count=$(echo "$new_messages" | jq 'length')

  if [ "$count" -gt 0 ]; then
    # Map into the shape the app expects: {sender, body, date (ISO)}.
    echo "$new_messages" | jq '[.[] | {
      sender: .number,
      body: .body,
      date: (.received_ts / 1000 | strftime("%Y-%m-%dT%H:%M:%S.000Z"))
    }]' > "$OUT_FILE.tmp"
    mv "$OUT_FILE.tmp" "$OUT_FILE"

    local newest_id
    newest_id=$(echo "$new_messages" | jq 'map(._id) | max')
    echo "$newest_id" > "$STATE_FILE"

    echo "[sms-bridge] wrote $count new message(s) to $OUT_FILE"
  else
    # Still write an empty array so the app can tell "synced, nothing new"
    # apart from "server not running".
    echo "[]" > "$OUT_FILE"
    echo "[sms-bridge] no new messages"
  fi
}

if [ "${1:-}" = "--watch" ]; then
  echo "[sms-bridge] watching for new SMS every 15s. Ctrl+C to stop."
  while true; do
    sync_once
    sleep 15
  done
else
  sync_once
fi
