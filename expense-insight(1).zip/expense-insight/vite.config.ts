import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import path from 'node:path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      // Terser-minifying the generated service worker (the default,
      // triggered by workbox's `mode: 'production'`) spins up Rollup's
      // worker-thread pool. On resource-constrained devices — e.g. building
      // directly on a phone under Termux — that pool can stall and crash the
      // build with "Unexpected early exit ... (terser) renderChunk". Setting
      // workbox's mode to 'development' below skips that optimization step;
      // the earlier top-level `minify` option only affects the
      // `injectManifest` strategy, not the `generateSW` strategy used here,
      // so it did nothing.
      includeAssets: ['favicon.svg', 'icons/*.png'],
      manifest: {
        name: 'Expense Insight',
        short_name: 'ExpenseInsight',
        description:
          'Automatic expense tracking and analytics from bank SMS messages — 100% offline, on-device.',
        theme_color: '#C99A3E',
        background_color: '#12141C',
        display: 'standalone',
        orientation: 'portrait',
        start_url: '/',
        scope: '/',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          {
            src: 'icons/icon-maskable-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable'
          }
        ]
      },
      workbox: {
        mode: 'development',
        globPatterns: ['**/*.{js,css,html,svg,png,ico,woff,woff2}'],
        navigateFallback: '/index.html'
      },
      devOptions: { enabled: false }
    })
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  },
  server: { port: 5173 },
  build: {
    sourcemap: false,
    target: 'es2022',
    rollupOptions: {
      output: {
        // Splitting these out keeps any single chunk (and the memory Rollup
        // needs to process it) smaller — helpful in general, and especially
        // on constrained build environments like a phone.
        manualChunks: {
          xlsx: ['xlsx'],
          pdf: ['jspdf', 'jspdf-autotable'],
          charts: ['recharts'],
          mui: ['@mui/material', '@mui/icons-material']
        }
      }
    }
  },
  test: {
    environment: 'node',
    globals: true,
    setupFiles: ['./src/tests/vitest.setup.ts']
  }
});
