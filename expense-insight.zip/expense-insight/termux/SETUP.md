# Running Expense Insight fully offline on your phone, with SMS auto-sync

This sets up two things side-by-side in Termux:

1. **The app itself**, served from `localhost` on your phone — no internet needed after setup.
2. **A small bridge** that reads your SMS inbox (something a browser can never do) and hands new messages to the app when you tap "Sync now" (or automatically every 15s if you enable auto-sync).

Everything below runs *on the phone*, in Termux. Nothing calls out to the internet at any point — the app and the bridge only ever talk to each other over `127.0.0.1`.

## 1. Install Termux and Termux:API

Use **F-Droid**, not the Play Store — the Play Store version of Termux is outdated and broken for this kind of thing.

1. Install F-Droid: https://f-droid.org
2. In F-Droid, install **Termux** and **Termux:API** (two separate apps, same developer)
3. Open Termux once so it finishes setting itself up

## 2. Install packages

In Termux:

```bash
pkg update
pkg install nodejs git jq termux-api
```

## 3. Grant SMS permission

```bash
termux-sms-list -l 1
```

Android will pop up a permission prompt the first time — allow it. If you don't see a prompt, go to **Android Settings → Apps → Termux:API → Permissions → SMS → Allow**.

Re-run the command above; you should see one JSON message printed. If you get an empty `[]` and you do have SMS on the phone, permission likely wasn't granted — check the setting above.

## 4. Get the project onto your phone

Easiest: use Termux's storage access to copy the extracted `expense-insight` folder from your Downloads.

```bash
termux-setup-storage      # one-time, allows Termux to see your phone's files
cp -r /sdcard/Download/expense-insight ~/expense-insight
cd ~/expense-insight
```

(Adjust the path if you extracted the zip somewhere else. If you'd rather use `git`, push the project to a repo first and `git clone` it here instead.)

## 5. Build and serve the app

```bash
npm install
npm run build
npm run preview
```

Leave that running. It'll print something like `http://localhost:4173/`.

## 6. Start the SMS bridge (in a second Termux session)

Open a new Termux session — swipe from the left edge of the screen, or use the Termux notification, and tap "New session".

```bash
cd ~/expense-insight
chmod +x termux/sms-bridge.sh
./termux/sms-bridge.sh --watch &
node termux/bridge-server.cjs
```

The first command polls your SMS inbox every 15 seconds and writes new messages to `~/expense-insight-bridge/messages.json`. The second serves that file on `http://127.0.0.1:8787`.

(You can run these as two separate sessions instead of backgrounding the first with `&`, if you'd rather watch their output separately.)

## 7. Open the app and sync

On your phone, open **`http://localhost:4173`** in Chrome.

Go to **More → Import & export**. At the top you'll see **"Sync from this phone (offline)"**:
- Port should already default to `8787` (matches `bridge-server.cjs` above)
- Tap **Sync now** — it pulls whatever's new from the bridge and parses/imports it through the normal pipeline (categorization, duplicate detection, everything)
- Flip on **Auto-sync every 15s** if you want it to keep checking automatically while that page is open

To install it as a proper home-screen app: Chrome menu (⋮) → **Add to Home screen**. It'll then behave like a normal app icon, and everything still runs locally.

## Keeping it running

Termux sessions stop if the app gets killed by Android's battery optimization. To keep the bridge alive in the background:

- In Termux, go to Settings (the hamburger menu) → **Acquire wakelock**, or run:
  ```bash
  termux-wake-lock
  ```
- In Android's battery settings, exclude Termux from battery optimization ("Unrestricted" / "Don't optimize")

## Troubleshooting

- **"Couldn't reach the bridge server"** in the app → `bridge-server.cjs` isn't running, or the port doesn't match. Check the second Termux session is still alive.
- **Sync succeeds but finds 0 new messages** → check `~/expense-insight-bridge/messages.json` directly (`cat` it). If it's empty even though you have new SMS, re-check the SMS permission (step 3) and that `sms-bridge.sh --watch` is still running.
- **Messages come in but a lot fail to parse** → that's normal for senders that aren't a recognized bank format; check the SMS log in Settings for specifics, and note the app still has a generic fallback for unrecognized formats.
