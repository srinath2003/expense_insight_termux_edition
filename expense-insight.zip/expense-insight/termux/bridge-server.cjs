/**
 * bridge-server.cjs — a tiny, dependency-free local HTTP server that exposes
 * the SMS messages sms-bridge.sh has collected, so the app (also running on
 * this same phone, e.g. via `npm run preview`) can fetch them over
 * localhost. No internet access is used or required anywhere in this file.
 *
 * Run alongside sms-bridge.sh --watch:
 *   node termux/bridge-server.cjs
 *
 * Endpoints:
 *   GET  /messages   -> current batch of unsynced messages (JSON array)
 *   POST /ack         -> clears the batch after the app has imported it
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.BRIDGE_PORT || 8787;
const OUT_FILE = path.join(os.homedir(), 'expense-insight-bridge', 'messages.json');

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    // The app is served from a different origin (localhost:4173 vs this
    // server's own port), so CORS needs to be open for localhost-to-localhost.
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(payload);
}

function readMessages() {
  try {
    const raw = fs.readFileSync(OUT_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    sendJson(res, 204, {});
    return;
  }

  if (req.method === 'GET' && req.url === '/messages') {
    sendJson(res, 200, readMessages());
    return;
  }

  if (req.method === 'POST' && req.url === '/ack') {
    fs.writeFileSync(OUT_FILE, '[]');
    sendJson(res, 200, { ok: true });
    return;
  }

  sendJson(res, 404, { error: 'Not found. Try GET /messages or POST /ack.' });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[bridge-server] listening on http://127.0.0.1:${PORT}`);
  console.log(`[bridge-server] serving ${OUT_FILE}`);
});
