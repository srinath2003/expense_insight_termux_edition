import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import path from 'node:path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      // Terser-minifying the generated service worker (the default) spins up
      // Rollup's worker-thread pool. On resource-constrained devices — e.g.
      // building directly on a phone under Termux — those worker threads can
      // stall and crash the build with "Unexpected early exit ... (terser)
      // renderChunk". The service worker itself is tiny either way, so
      // there's no real downside to leaving it unminified.
      minify: false,
      includeAssets: ['favicon.svg', 'icons/*.png'],
      manifest: {
        name: 'Expense Insight',
        short_name: 'ExpenseInsight',
        description:
          'Automatic expense tracking and analytics from bank SMS messages — 100% offline, on-device.',
        theme_color: '#C99A3E',
        background_color: '#12141C',
        display: 'standalone',
        orientation: 'portrait',
        start_url: '/',
        scope: '/',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          {
            src: 'icons/icon-maskable-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable'
          }
        ]
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png,ico,woff,woff2}'],
        navigateFallback: '/index.html'
      },
      devOptions: { enabled: false }
    })
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  },
  server: { port: 5173 },
  build: {
    sourcemap: false,
    target: 'es2022',
    rollupOptions: {
      output: {
        // Splitting these out keeps any single chunk (and the memory Rollup
        // needs to process it) smaller — helpful in general, and especially
        // on constrained build environments like a phone.
        manualChunks: {
          xlsx: ['xlsx'],
          pdf: ['jspdf', 'jspdf-autotable'],
          charts: ['recharts'],
          mui: ['@mui/material', '@mui/icons-material']
        }
      }
    }
  },
  test: {
    environment: 'node',
    globals: true,
    setupFiles: ['./src/tests/vitest.setup.ts']
  }
});
